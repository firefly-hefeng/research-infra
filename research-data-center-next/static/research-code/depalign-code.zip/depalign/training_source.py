"""Bounded train/validation-only selection of richer IC-EDF voice residuals.

The entry point does not load official development or ESD test rows for scoring.
Evaluation is a separate command after SELECTION_FROZEN.json is written.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from depression_lab.edf_query_anchor import regression_metrics
from depression_lab.ic_edf_joint import fit_representation, slot_features, voice_features, prepare_head, fit_joint_head, predict_slots
from scripts.run_ic_edf import align, esd_groups, load_npz, SEEDS
from scripts.run_edf_symptom_query_svr import make_model


ROOT = Path(__file__).resolve().parents[1]
FEATURES = Path('D:/depression-lab/runtime/edf-v1/subject-features')
RUNS = ROOT / 'data/edf-runs'
CONFIGS = [(a, w, s) for a in (0.1, 1., 10.) for w in (0., 0.1, 1.) for s in (0.5, 1.)]
COMPONENTS = 8
POSITIVE = False


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def subset(data, indices):
    return {k: (v[indices] if isinstance(v, np.ndarray) and len(v) == len(data['target']) else v)
            for k, v in data.items()}


def load_train():
    return align(load_npz(FEATURES/'DAIC_SYMPTOM_QUERY_FEATURES_SPARSE.npz'),
                 load_npz(FEATURES/'DAIC_QUERY_EMOTION2VEC_LARGE_TOP20.npz'),
                 load_npz(FEATURES/'DAIC_IC_EDF_STRUCTURED_EVIDENCE.npz'))


def expression_selection(esd):
    mask = (esd['split'] == 'train') & np.isin(esd['emotion'], ['Neutral', 'Sad', 'Happy'])
    ix = np.flatnonzero(mask)
    vg = esd_groups(esd, 'validation')
    vi = np.array([[g[e] for e in ('Neutral', 'Sad', 'Happy')] for g in vg])
    records, models = [], []
    for c in (0.01, 0.1, 1.):
        model = make_pipeline(StandardScaler(), LogisticRegression(C=c, max_iter=500))
        model.fit(esd['mean'][ix], esd['emotion'][ix])
        p = model.predict_proba(esd['mean'][vi.reshape(-1)])
        cls = list(model[-1].classes_)
        z = (p[:, cls.index('Sad')] - p[:, cls.index('Happy')]).reshape(-1, 3)
        margin = np.stack([z[:, 1] - z[:, 0], z[:, 0] - z[:, 2]], axis=1)
        record = {'C': c, 'validation_direction': float((margin > 0).mean()),
                  'validation_pair_logistic_loss': float(np.logaddexp(0, -margin).mean())}
        records.append(record)
        models.append(model)
    selected = min(range(len(records)), key=lambda i: (-records[i]['validation_direction'],
                                                       records[i]['validation_pair_logistic_loss'], records[i]['C']))
    return models[selected], {'candidates': records, 'selected': records[selected]}


def text_fit(data, indices, spec, seed):
    y, x = data['target'], data['text']
    oof = np.empty(len(indices))
    for a, b in KFold(4, shuffle=True, random_state=seed).split(indices):
        m = make_model(spec).fit(x[indices[a]], y[indices[a]])
        oof[b] = m.predict(x[indices[b]])
    m = make_model(spec).fit(x[indices], y[indices])
    return m, y[indices] - oof


def pair_data(esd, split, contexts, rep, limit=None):
    groups = esd_groups(esd, split)
    if limit is not None:
        # Uniform deterministic coverage of the ordered group inventory, label independent.
        groups = [groups[i] for i in np.linspace(0, len(groups)-1, min(limit, len(groups)), dtype=int)]
    ix = np.array([[g[e] for e in ('Neutral', 'Sad', 'Happy')] for g in groups])
    feat = voice_features(esd['mean'][ix.reshape(-1)].astype(float),
                          esd['native_probability'][ix.reshape(-1)].astype(float), contexts, rep)
    feat = feat.reshape(len(groups), 3, *feat.shape[1:])
    signed = np.stack([feat[:, 1] - feat[:, 0], feat[:, 0] - feat[:, 2]], axis=1)
    return signed.reshape(-1, *feat.shape[-2:]), feat


def materialize(data, train, spec, seed, expr, axis, esd):
    rep = fit_representation(data, train, expr, axis, components=COMPONENTS)
    feat = slot_features(data, rep)
    tm, residual = text_fit(data, train, spec, seed)
    ctx_ids = train[np.linspace(0, len(train)-1, min(8, len(train)), dtype=int)]
    context = subset(data, ctx_ids)
    pairs, _ = pair_data(esd, 'train', context, rep, limit=200)
    _, validation = pair_data(esd, 'validation', context, rep)
    prepared = prepare_head(feat[train], residual, pairs)
    return rep, feat, tm, residual, pairs, validation, prepared


def validation_direction(features, head, shrink):
    score = predict_slots(features, head, shrink).sum(-1)
    margin = np.stack([score[:, 1]-score[:, 0], score[:, 0]-score[:, 2]], axis=1)
    return float((margin > 0).mean())


def main():
    global CONFIGS, COMPONENTS, POSITIVE
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--compact', action='store_true', help='Three expression coordinates, positive head, weak pair penalties')
    args = parser.parse_args()
    if args.compact:
        COMPONENTS, POSITIVE = 0, True
        CONFIGS = [(a,w,s) for a in (0.01,0.1,1.) for w in (0.,0.001,0.01,0.1) for s in (0.5,1.)]
    out = args.output_root.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out/'SELECTION_FROZEN.json').exists():
        raise RuntimeError('frozen output already exists; use a new run directory')
    protocol = ROOT/'docs/MSIA_JOINT_PROTOCOL_20260918.md'
    data = load_train()
    fit = np.flatnonzero(data['split'] == 'fit')
    esd_full = load_npz(FEATURES/'ESD_EMOTION2VEC_LARGE_FEATURES.npz')
    allowed = esd_full['split'] != 'test'
    esd = {k: v[allowed] for k, v in esd_full.items()}
    del esd_full
    expr, expr_record = expression_selection(esd)
    # The existing axis was trained only on ESD train; no old test statistic enters selection.
    old = joblib.load(RUNS/'R18-adaptive-simplex-robust-consensus/model.joblib')
    axis = np.asarray(old['esd_axis']['raw_weight'])
    linear = json.loads((RUNS/'R7-symptom-conditioned-emotion-residual/REPORT.json').read_text())
    spec_final = old['text_spec']
    by_seed, all_records = {}, []
    chosen = {'rich_only': [], 'joint': []}
    for seed in SEEDS:
        old_seed = linear['repeated_nested_fit']['by_seed'][str(seed)]
        pred = {k: np.full(len(fit), np.nan) for k in chosen}
        text_pred = np.full(len(fit), np.nan)
        for fr in old_seed['fold_records']:
            outer_train = fit[np.asarray(fr['train_indices'])]
            outer_val_local = np.asarray(fr['validation_indices'])
            outer_val = fit[outer_val_local]
            spec = fr['selected_text_spec']
            errors, valdirs = [[] for _ in CONFIGS], [[] for _ in CONFIGS]
            for j, (it, iv) in enumerate(KFold(4, shuffle=True, random_state=seed*100+fr['fold']).split(outer_train)):
                tr, va = outer_train[it], outer_train[iv]
                rep, feat, tm, residual, pairs, vfeat, prep = materialize(
                    data, tr, spec, seed*1000+fr['fold']*10+j, expr, axis, esd)
                base = tm.predict(data['text'][va])
                for k, (alpha, pw, shrink) in enumerate(CONFIGS):
                    head = fit_joint_head(feat[tr], residual, pairs, alpha, pw, prepared=prep, positive=POSITIVE)
                    pp = np.clip(base+predict_slots(feat[va], head, shrink).sum(-1), 0, 24)
                    errors[k].extend(np.abs(pp-data['target'][va]).tolist())
                    valdirs[k].append(validation_direction(vfeat, head, shrink))
            scores = [{'config': list(c), 'inner_mae': float(np.mean(errors[k])),
                       'esd_validation_msia': float(np.mean(valdirs[k]))} for k, c in enumerate(CONFIGS)]
            rep, feat, tm, residual, pairs, vfeat, prep = materialize(
                data, outer_train, spec, seed*100+fr['fold'], expr, axis, esd)
            base = tm.predict(data['text'][outer_val])
            text_pred[outer_val_local] = np.clip(base, 0, 24)
            selections = {}
            for kind in chosen:
                possible = [k for k, c in enumerate(CONFIGS) if (kind=='joint' or c[1]==0)]
                # A validation-only directional floor; if infeasible, disclose and use the
                # best validation direction before MAE. Never consult ESD test here.
                eligible = ([k for k in possible if scores[k]['esd_validation_msia'] >= 0.95]
                            if kind == 'joint' else possible)
                selected = min(eligible or possible,
                    key=lambda k: ((0 if eligible else -scores[k]['esd_validation_msia']),
                                   scores[k]['inner_mae'], CONFIGS[k][1], -CONFIGS[k][0]))
                c = CONFIGS[selected]
                chosen[kind].append(c)
                h = fit_joint_head(feat[outer_train], residual, pairs, c[0], c[1], prepared=prep, positive=POSITIVE)
                pred[kind][outer_val_local] = np.clip(base+predict_slots(feat[outer_val], h, c[2]).sum(-1), 0, 24)
                selections[kind] = {'config': list(c), 'validation_floor_feasible': bool(eligible)}
            all_records.append({'seed': seed, 'fold': fr['fold'], 'candidates': scores, 'selected': selections})
            print(json.dumps({'seed': seed, 'fold': fr['fold'], 'selected': selections}), flush=True)
            (out/'SELECTION_PROGRESS.json').write_text(json.dumps(all_records, indent=2)+'\n')
        by_seed[str(seed)] = {'text': regression_metrics(data['target'][fit], text_pred),
                             'text_prediction': text_pred.tolist()}
        for kind in chosen:
            by_seed[str(seed)][kind] = regression_metrics(data['target'][fit], pred[kind])
            by_seed[str(seed)][kind+'_prediction'] = pred[kind].tolist()
        print(json.dumps({'seed_complete': seed, 'scores': {k: by_seed[str(seed)][k] for k in ['text',*chosen]}}), flush=True)
    all_indices = np.arange(len(data['target']))
    rep, feat, tm, residual, pairs, vfeat, prep = materialize(data, all_indices, spec_final, 17, expr, axis, esd)
    models, final_configs = {}, {}
    for kind in chosen:
        counts = Counter(chosen[kind])
        c = min(counts, key=lambda c: (-counts[c], c[1], -c[0], c[2]))
        h = fit_joint_head(feat, residual, pairs, c[0], c[1], prepared=prep, positive=POSITIVE)
        path = out/(kind+'.joblib')
        joblib.dump({'version': 'ic-edf-msia-joint-v1', 'representation': rep, 'head': h,
                     'text_model': tm, 'shrinkage': c[2], 'cap': 2., 'kind': kind}, path)
        models[kind] = {'path': str(path), 'sha256': sha(path)}
        final_configs[kind] = {'config': list(c), 'selection_count': counts[c],
                               'esd_validation_direction': validation_direction(vfeat, h, c[2])}
    report = {'version': 'ic-edf-msia-joint-selection-v1', 'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
              'protocol_sha256': sha(protocol), 'script_sha256': sha(__file__),
              'esd_test_used_for_selection': False, 'official_dev_used_for_selection': False,
              'scope': 'Exploratory on reused DAIC fit; historical test cohorts require external confirmation.',
              'configs': CONFIGS, 'expression_selection': expr_record,
              'compact': args.compact, 'positive_head': POSITIVE,
              'control_selection': 'No-pair control minimizes inner MAE without a direction floor',
              'gate': 'frozen symmetric four-simplex from previous run; dynamic context inputs, no new gate search',
              'auxiliary': 'ESD signed pair feature differences target +1 in a separate weighted least-squares term',
              'selection_records': all_records, 'final_configs': final_configs, 'models': models,
              'by_seed': by_seed, 'fit_subject_ids': [data['ids'][i] for i in fit],
              'fit_target': data['target'][fit].tolist(),
              'mean_mae': {k: float(np.mean([v[k]['mae'] for v in by_seed.values()])) for k in ['text',*chosen]}}
    (out/'SELECTION_FROZEN.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'mean_mae': report['mean_mae'], 'final_configs': final_configs}), flush=True)


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
