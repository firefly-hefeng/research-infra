"""Frozen expression representation and a paired-intervention residual head."""
from __future__ import annotations

import numpy as np
from scipy.linalg import solve, cholesky, solve_triangular
from scipy.optimize import nnls
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from depression_lab.ic_edf import expression_features, intervention_score, reliability_gate, adaptive_reliability_gate


def expression_coordinates(embedding, probability, expression_model, pca):
    posterior = expression_model.predict_proba(np.asarray(embedding).reshape(-1, 1024))
    # A supervised 3-D expression posterior plus native cues and a train-only
    # low-rank voice state. Restoring leading axes permits identical subject/voice inference.
    posterior = posterior.reshape(*embedding.shape[:-1], 3)
    if pca is None:
        cls = list(expression_model[-1].classes_)
        contrast = posterior[..., cls.index('Sad')] - posterior[..., cls.index('Happy')]
        return np.concatenate([expression_features(probability), contrast[..., None]], axis=-1)
    latent = pca.transform(np.asarray(embedding).reshape(-1, 1024)).reshape(*embedding.shape[:-1], -1)
    return np.concatenate([probability, expression_features(probability), posterior, latent], axis=-1)


def fit_representation(data, indices, expression_model, axis_weight, components=8):
    samples = np.concatenate([data['global_embedding'][indices, None], data['slot_embedding'][indices]], axis=1)
    pca = (PCA(n_components=components, svd_solver='randomized', random_state=17).fit(samples.reshape(-1, 1024))
           if components else None)
    axis = intervention_score(data['slot_embedding'][indices], expression_features(data['slot_probability'][indices]), axis_weight)
    return {'pca': pca, 'expression_model': expression_model, 'axis_weight': axis_weight,
            'scale': max(float(axis.std()), 1e-8), 'gate_weights': np.ones(4) / 4}


def slot_features(data, rep):
    slot = expression_coordinates(data['slot_embedding'], data['slot_probability'], rep['expression_model'], rep['pca'])
    glob = expression_coordinates(data['global_embedding'], data['global_probability'], rep['expression_model'], rep['pca'])
    axis = intervention_score(data['slot_embedding'], expression_features(data['slot_probability']), rep['axis_weight'])
    _, c = reliability_gate(data['slot_probability'], data['explicitness'], data['support'], data['counter'], axis, rep['scale'])
    gate = adaptive_reliability_gate(c['audio_quality'], c['text_clarity'], c['cross_modal_consistency'], rep['gate_weights'])
    global_slots = np.broadcast_to(glob[:, None, :] / 8, slot.shape)
    return np.concatenate([global_slots, slot - glob[:, None, :]], axis=-1) * gate[..., None]


def voice_features(embedding, probability, context, rep):
    """Return [voice, fixed text context, slot, feature] without averaging."""
    z = expression_coordinates(embedding, probability, rep['expression_model'], rep['pca'])
    n, r = len(z), len(context['explicitness'])
    axis = intervention_score(embedding, expression_features(probability), rep['axis_weight'])
    p = np.broadcast_to(probability[:, None, None, :], (n, r, 8, 9))
    av = np.broadcast_to(axis[:, None, None], (n, r, 8))
    _, c = reliability_gate(p, np.broadcast_to(context['explicitness'], (n, r, 8)),
                            np.broadcast_to(context['support'], (n, r, 8)),
                            np.broadcast_to(context['counter'], (n, r, 8)), av, rep['scale'])
    gate = adaptive_reliability_gate(c['audio_quality'], c['text_clarity'], c['cross_modal_consistency'], rep['gate_weights'])
    glob = np.broadcast_to(z[:, None, None, :] / 8, (n, r, 8, z.shape[-1]))
    return np.concatenate([glob, np.zeros_like(glob)], axis=-1) * gate[..., None]


def prepare_head(features, residual, pair_features):
    x = features.reshape(len(features), -1)
    scaler = StandardScaler().fit(x)
    x = scaler.transform(x)
    # Differences do not contain a scaler offset or model intercept.
    d = pair_features.reshape(len(pair_features), -1) / scaler.scale_
    ym = float(np.mean(residual))
    gram = x.T @ x / len(x)
    rhs = x.T @ (residual - ym) / len(x)
    return {'scaler': scaler, 'intercept': ym, 'gram': gram, 'rhs': rhs,
            'pair_gram': d.T @ d / len(d), 'pair_rhs': d.mean(axis=0)}


def fit_joint_head(features, residual, pair_features, alpha, pair_weight, prepared=None, positive=False):
    state = prepared if prepared is not None else prepare_head(features, residual, pair_features)
    gram = state['gram'] + pair_weight * state['pair_gram']
    rhs = state['rhs'] + pair_weight * state['pair_rhs']
    width = len(rhs)
    system = gram + alpha * np.eye(width)
    if positive:
        upper = cholesky(system, lower=False)
        transformed_rhs = solve_triangular(upper.T, rhs, lower=True)
        coef, _ = nnls(upper, transformed_rhs)
    else:
        coef = solve(system, rhs, assume_a='pos')
    return {'scaler': state['scaler'], 'coef': coef, 'intercept': state['intercept'],
            'alpha': float(alpha), 'pair_weight': float(pair_weight), 'positive': positive}


def predict_slots(features, head, shrinkage=0.5, cap=2.0):
    shape = features.shape[:-2]
    flat = features.reshape(-1, np.prod(features.shape[-2:]))
    components = (head['scaler'].transform(flat) * head['coef']).reshape(*shape, *features.shape[-2:]).sum(-1)
    components = shrinkage * (components + head['intercept'] / 8)
    raw = components.sum(-1)
    # Smooth bounded correction avoids hard-cap ties; total-score clipping is
    # separately reported and is not silently allocated to either modality.
    bounded = cap * np.tanh(raw / cap)
    factor = np.divide(bounded, raw, out=np.ones_like(raw), where=np.abs(raw) > 1e-12)
    return components * factor[..., None]
