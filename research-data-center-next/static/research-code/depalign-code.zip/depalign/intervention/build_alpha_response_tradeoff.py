from __future__ import annotations
import csv, hashlib, json, math
from pathlib import Path
import numpy as np

OUT=Path(r"D:\depression-lab\runtime\edf-v1\depalign-full-path-intervention-20260922\v1")
ROUTE=Path(r"D:\depression-lab\runtime\edf-v1\depalign-route-audit-20260922\v1")
WEIGHTS=(0.0,0.25,0.5,0.75,1.0)

def sha256(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  while c:=f.read(1024*1024): h.update(c)
 return h.hexdigest()

def wilson(k,n,z=1.959963984540054):
 if n==0:return [None,None]
 p=k/n; den=1+z*z/n
 center=(p+z*z/(2*n))/den
 half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return [center-half,center+half]

rows=list(csv.DictReader((OUT/"FULL_PATH_INTERVENTION_RESULTS.csv").open(encoding="utf-8")))
perf=list(csv.DictReader((ROUTE/"ALPHA_SCAN.csv").open(encoding="utf-8")))
perf_lookup={(r["split"],float(r["alpha_fixed_C"])):r for r in perf}
out=[]
for alpha in WEIGHTS:
 valid=[r for r in rows if int(r["valid_delta_C"])]
 delta=np.asarray([
  alpha*float(r["delta_C"])+(1-alpha)*float(r["delta_P"]) for r in valid
 ])
 reversal=np.asarray([
  d*float(r["delta_C"])<0 for d,r in zip(delta,valid,strict=True)
 ])
 k=int(reversal.sum());n=len(valid)
 row={
  "alpha_fixed_C":alpha,
  "prediction_path_weight":1-alpha,
  "valid_interventions":n,
  "response_reversals":k,
  "response_reversal_rate":k/n,
  "response_reversal_wilson_low":wilson(k,n)[0],
  "response_reversal_wilson_high":wilson(k,n)[1],
  "mean_absolute_delta_A":float(np.abs(delta).mean()),
  "dev_mae":float(perf_lookup[("dev",alpha)]["mae"]),
  "test_mae_retrospective":float(perf_lookup[("test",alpha)]["mae"]),
 }
 for condition in ("pitch_down_2st","pitch_up_2st"):
  vr=[r for r in valid if r["condition"]==condition]
  rr=sum(
   (alpha*float(r["delta_C"])+(1-alpha)*float(r["delta_P"]))*float(r["delta_C"])<0
   for r in vr
  )
  row[f"{condition}_valid"]=len(vr)
  row[f"{condition}_reversal_rate"]=rr/len(vr) if vr else None
 out.append(row)
with (OUT/"ALPHA_RESPONSE_TRADEOFF.csv").open("w",newline="",encoding="utf-8") as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
report={
 "version":"depalign-alpha-response-tradeoff-v1",
 "delta_C_tolerance":0.01,
 "intervention_unit":"participant x pitch direction",
 "valid_interventions":len([r for r in rows if int(r["valid_delta_C"])]),
 "rows":out,
 "interpretation":"Development MAE is protocol-valid; test MAE is retrospective sensitivity. Reversal is a behavioral consistency diagnostic and has no clinical direction label.",
}
(OUT/"ALPHA_RESPONSE_TRADEOFF.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n",encoding="utf-8")
audit={
 "passed":True,
 "artifact_sha256":{
  "FULL_PATH_INTERVENTION_RESULTS.csv":sha256(OUT/"FULL_PATH_INTERVENTION_RESULTS.csv"),
  "ALPHA_SCAN.csv":sha256(ROUTE/"ALPHA_SCAN.csv"),
  "ALPHA_RESPONSE_TRADEOFF.csv":sha256(OUT/"ALPHA_RESPONSE_TRADEOFF.csv"),
  "ALPHA_RESPONSE_TRADEOFF.json":sha256(OUT/"ALPHA_RESPONSE_TRADEOFF.json"),
 },
}
(OUT/"ALPHA_RESPONSE_AUDIT.json").write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n",encoding="utf-8")
print(json.dumps(report,indent=2,sort_keys=True))
