from __future__ import annotations
import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

PYDEPS = Path(r"D:\depression-lab\runtime\edf-v1\depalign-full-path-intervention-20260922\v1\pydeps312")
if str(PYDEPS) not in sys.path:
    sys.path.append(str(PYDEPS))
import librosa

ROOT = Path(r"C:\Users\Administrator\Documents\ChatGPT\抑郁症")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from depression_lab.edf_multiview_acoustics import load_segment

OUT = Path(r"D:\depression-lab\runtime\edf-v1\depalign-full-path-intervention-20260922\v1")
MANIFEST = Path(r"D:\depression-lab\runtime\edf-v1\phase-a\DAIC_WINDOWS_AUDITED.jsonl")
CACHE = Path(r"D:\depression-lab\runtime\edf-v1\subject-features\DAIC_OFFICIAL_DEV_BASE_UNIT_CACHE.pt")
INPUTS = Path(r"D:\depression-lab\runtime\edf-v1\subject-features\DAIC_OFFICIAL_DEV_INPUTS.jsonl")
SELECTED = ("406", "490", "302", "388", "417", "476", "403", "436", "472", "382")
CONDITIONS = {"control_0st": 0.0, "pitch_down_2st": -2.0, "pitch_up_2st": 2.0}
SR = 16000


def read_jsonl(path):
    with Path(path).open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    with Path(path).open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def acoustic_summary(y: np.ndarray) -> dict:
    y = np.asarray(y, dtype=np.float32)
    duration = len(y) / SR
    if len(y) < 512:
        return {"duration_seconds": duration, "f0_median_hz": None, "f0_iqr_hz": None, "rms": float(np.sqrt(np.mean(y*y)))}
    frame_length = 1024
    hop = 256
    rms = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop, center=True)[0]
    f0 = librosa.yin(y, fmin=60.0, fmax=500.0, sr=SR, frame_length=frame_length, hop_length=hop)
    n = min(len(rms), len(f0))
    gate = rms[:n] > max(float(np.quantile(rms[:n], 0.2)), 1e-4)
    voiced = f0[:n][gate & np.isfinite(f0[:n])]
    return {
        "duration_seconds": duration,
        "f0_median_hz": float(np.median(voiced)) if len(voiced) else None,
        "f0_iqr_hz": float(np.quantile(voiced, .75)-np.quantile(voiced, .25)) if len(voiced) else None,
        "rms": float(np.sqrt(np.mean(y*y))),
    }


def main():
    existing = [p for p in OUT.iterdir() if p.name not in {"prepare_audio_intervention.py", "pydeps", "pydeps312", "uv-cache"}]
    if existing:
        raise RuntimeError(f"output not empty: {existing}")
    rows = [
        r for r in read_jsonl(MANIFEST)
        if str(r["subject_id"]) in SELECTED and r.get("audio_usable", True)
    ]
    counts = defaultdict(int)
    for r in rows:
        counts[str(r["subject_id"])] += 1
    if set(counts) != set(SELECTED):
        raise AssertionError((set(SELECTED)-set(counts), counts))

    condition_rows = {name: [] for name in CONDITIONS}
    acoustic_rows = []
    for index, row in enumerate(rows, 1):
        original = load_segment(
            Path(row["audio_path"]), float(row["start_time"]), float(row["end_time"])
        ).astype(np.float32)
        original_summary = acoustic_summary(original)
        transcript_hash = hash_text(str(row.get("transcript", "")))
        for condition, steps in CONDITIONS.items():
            transformed = librosa.effects.pitch_shift(
                original, sr=SR, n_steps=steps, bins_per_octave=12, res_type="soxr_hq"
            ).astype(np.float32)
            if len(transformed) != len(original):
                transformed = librosa.util.fix_length(transformed, size=len(original))
            if not np.isfinite(transformed).all():
                raise AssertionError(f"non-finite audio: {row['window_id']} {condition}")
            wav_dir = OUT / "audio" / condition / str(row["subject_id"])
            wav_dir.mkdir(parents=True, exist_ok=True)
            wav_path = wav_dir / f"{row['window_id']}.wav"
            sf.write(wav_path, transformed, SR, subtype="PCM_16")
            derived = dict(row)
            derived["audio_path"] = str(wav_path.resolve())
            derived["start_time"] = 0.0
            derived["end_time"] = len(transformed) / SR
            derived["duration_seconds"] = len(transformed) / SR
            derived["intervention_condition"] = condition
            derived["pitch_shift_semitones"] = steps
            derived["source_audio_path"] = row["audio_path"]
            derived["source_start_time"] = row["start_time"]
            derived["source_end_time"] = row["end_time"]
            derived["transcript_sha256"] = transcript_hash
            condition_rows[condition].append(derived)
            summary = acoustic_summary(transformed)
            acoustic_rows.append({
                "subject_id": str(row["subject_id"]),
                "window_id": str(row["window_id"]),
                "answer_id": str(row["answer_id"]),
                "condition": condition,
                "pitch_shift_semitones": steps,
                "transcript_sha256": transcript_hash,
                "original_duration_seconds": original_summary["duration_seconds"],
                "modified_duration_seconds": summary["duration_seconds"],
                "duration_delta_seconds": summary["duration_seconds"]-original_summary["duration_seconds"],
                "original_f0_median_hz": original_summary["f0_median_hz"],
                "modified_f0_median_hz": summary["f0_median_hz"],
                "f0_log2_ratio": (
                    float(np.log2(summary["f0_median_hz"]/original_summary["f0_median_hz"]))
                    if summary["f0_median_hz"] and original_summary["f0_median_hz"] else None
                ),
                "original_rms": original_summary["rms"],
                "modified_rms": summary["rms"],
            })
        if index % 100 == 0 or index == len(rows):
            print(json.dumps({"prepared": index, "total": len(rows)}), flush=True)

    for condition, values in condition_rows.items():
        write_jsonl(OUT / f"{condition}_MANIFEST.jsonl", values)
    with (OUT / "ACOUSTIC_WINDOW_CHECKS.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(acoustic_rows[0]))
        w.writeheader(); w.writerows(acoustic_rows)

    cache = torch.load(CACHE, map_location="cpu", weights_only=True)
    lookup = {str(v): i for i, v in enumerate(cache["target_ids"])}
    indices = [lookup[pid] for pid in SELECTED]
    subset_cache = {
        "queries": cache["queries"],
        "target": [cache["target"][i] for i in indices],
        "target_ids": [cache["target_ids"][i] for i in indices],
    }
    torch.save(subset_cache, OUT / "SELECTED_BASE_UNIT_CACHE.pt")
    input_rows = [r for r in read_jsonl(INPUTS) if str(r["participant_id"]) in SELECTED]
    order = {pid: i for i, pid in enumerate(SELECTED)}
    input_rows.sort(key=lambda r: order[str(r["participant_id"])])
    write_jsonl(OUT / "SELECTED_INPUTS.jsonl", input_rows)

    protocol = {
        "version": "depalign-full-path-audio-preparation-v1",
        "selection_rule": "ten dual-path-active official-dev participants with the smallest audited window counts; selected before observing intervention responses",
        "selected_participants": list(SELECTED),
        "window_counts": dict(sorted(counts.items())),
        "total_windows_per_condition": len(rows),
        "conditions": CONDITIONS,
        "audio_operation": "duration-preserving librosa phase-vocoder pitch shift on each audited participant-only speech window; all conditions, including zero-semitone control, use the same function and PCM16 write/read path",
        "clinical_labeling": "none; pitch edits are behavioral diagnostics only",
        "text_check": "source transcript strings and hashes are copied unchanged; no ASR-based semantic equivalence claim",
        "source_manifest": str(MANIFEST),
    }
    (OUT / "PREPARATION_PROTOCOL.json").write_text(
        json.dumps(protocol, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(protocol, indent=2, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()




