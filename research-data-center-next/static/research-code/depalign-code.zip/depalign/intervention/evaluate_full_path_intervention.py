from __future__ import annotations
import csv
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np

ROOT = Path(r"C:\Users\Administrator\Documents\ChatGPT\抑郁症")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from depression_lab.daic_official_benchmark import bounded_additive_contributions
from depression_lab.ic_edf_joint import slot_features
from scripts.evaluate_evolving_ic_edf import blend_decompositions, decompose_recent_artifact
from scripts.run_daic_official_benchmark import make_representation, model_audio_slots, text_slot_contributions
from scripts.run_ic_edf import align, load_npz

OUT = Path(r"D:\depression-lab\runtime\edf-v1\depalign-full-path-intervention-20260922\v1")
FEATURES = Path(r"D:\depression-lab\runtime\edf-v1\subject-features")
MODEL = Path(r"D:\depression-lab\runtime\edf-v1\evolving-ic-edf-20260921\dev-v3\MODEL.joblib")
QUERY = FEATURES / "DAIC_OFFICIAL_DEV_QUERY_FEATURES_SPARSE.npz"
STRUCTURED = FEATURES / "DAIC_OFFICIAL_DEV_IC_EDF_STRUCTURED_EVIDENCE.npz"
ORIGINAL_EMOTION = FEATURES / "DAIC_OFFICIAL_DEV_QUERY_EMOTION2VEC_LARGE_TOP20.npz"
SELECTED = ("406", "490", "302", "388", "417", "476", "403", "436", "472", "382")
CONDITIONS = {
    "original_reference": ORIGINAL_EMOTION,
    "control_0st": OUT / "control_0st_SUBJECT.npz",
    "pitch_down_2st": OUT / "pitch_down_2st_SUBJECT.npz",
    "pitch_up_2st": OUT / "pitch_up_2st_SUBJECT.npz",
}
TOLERANCE = 0.01


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        while chunk := f.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()


def subset(data: dict, selected: tuple[str, ...]) -> dict:
    ids_key = "subject_id" if "subject_id" in data else "id"
    ids = [str(v) for v in data[ids_key]]
    lookup = {v:i for i,v in enumerate(ids)}
    idx=np.asarray([lookup[v] for v in selected], dtype=int)
    out={}
    for k,v in data.items():
        a=np.asarray(v)
        out[k] = a[idx] if a.ndim and len(a)==len(ids) else a
    return out


def describe(values) -> dict:
    x=np.asarray(values,dtype=float)
    x=x[np.isfinite(x)]
    if not len(x): return {"n":0}
    return {
        "n":int(len(x)), "mean":float(x.mean()), "std":float(x.std()),
        "mean_absolute":float(np.abs(x).mean()),
        "median":float(np.median(x)), "minimum":float(x.min()), "maximum":float(x.max()),
        "q25":float(np.quantile(x,.25)), "q75":float(np.quantile(x,.75)),
    }


def evaluate(bundle: dict, query: dict, structured: dict, emotion_path: Path, use_subset: bool) -> dict:
    emotion=load_npz(emotion_path)
    if use_subset:
        emotion=subset(emotion, SELECTED)
    data=align(query,emotion,structured)
    ids=list(map(str,data["ids"]))
    if ids != list(SELECTED):
        raise AssertionError((ids,SELECTED))
    base_text,_=text_slot_contributions(bundle["text_model"],data["text"])
    parent=bundle["fixed_parent"]
    rep=make_representation(
        data,np.asarray(parent["esd_axis"]["raw_weight"]),float(parent["intervention_scale"])
    )
    fixed_audio=model_audio_slots(bundle["fixed_model"],rep["feature"],.5,2.0,smooth=False)
    fixed_pred,fixed_text,fixed_audio=bounded_additive_contributions(base_text,fixed_audio)

    rich_audio=slot_features(data,bundle["rich_representation"])
    width=rich_audio.shape[-1]//2
    norm=np.sqrt(np.mean(np.square(rich_audio[:,:,width:]),axis=(1,2)))
    available=norm>1e-8
    text_3d=np.asarray(data["text"]).reshape(len(ids),8,-1)
    decomposed=[
        decompose_recent_artifact(artifact,text_3d,rich_audio)
        for artifact in bundle["recent_artifacts"]
    ]
    deep_text_residual=np.mean(np.stack([r[1] for r in decomposed]),axis=0)
    deep_audio=np.mean(np.stack([r[2] for r in decomposed]),axis=0)
    deep_pred,deep_text,deep_audio=bounded_additive_contributions(
        base_text+deep_text_residual,deep_audio
    )
    alpha=float(bundle["selected_fixed_weight"])
    effective=np.where(available,alpha,1.0)
    final_pred,final_text,final_audio,recon=blend_decompositions(
        fixed_text,fixed_audio,deep_text,deep_audio,fixed_weight=effective
    )
    return {
        "ids":ids, "target":np.asarray(data["target"],float),
        "available":available, "local_norm":norm, "effective_alpha":effective,
        "C":fixed_audio.sum(1), "P":deep_audio.sum(1), "A":final_audio.sum(1),
        "T":final_text.sum(1), "score":final_pred,
        "fixed_score":fixed_pred, "predictive_score":deep_pred,
        "reconstruction_error":float(recon),
        "deep_decomposition_error":float(max(r[3] for r in decomposed)),
    }


def acoustic_report() -> dict:
    rows=list(csv.DictReader((OUT/"ACOUSTIC_WINDOW_CHECKS.csv").open(encoding="utf-8")))
    result={}
    for condition in ("control_0st","pitch_down_2st","pitch_up_2st"):
        subset_rows=[r for r in rows if r["condition"]==condition]
        log_ratio=np.asarray([
            float(r["f0_log2_ratio"]) for r in subset_rows if r["f0_log2_ratio"] not in ("","None")
        ])
        duration=np.asarray([float(r["duration_delta_seconds"]) for r in subset_rows])
        text_hashes=[r["transcript_sha256"] for r in subset_rows]
        result[condition]={
            "windows":len(subset_rows),
            "median_f0_shift_semitones":float(12*np.median(log_ratio)),
            "mean_f0_shift_semitones":float(12*np.mean(log_ratio)),
            "f0_shift_semitones":describe(12*log_ratio),
            "maximum_absolute_duration_change_seconds":float(np.max(np.abs(duration),initial=0.0)),
            "all_transcript_hashes_present":bool(all(text_hashes)),
        }
    return result


def main():
    bundle=joblib.load(MODEL)
    query=subset(load_npz(QUERY),SELECTED)
    structured=subset(load_npz(STRUCTURED),SELECTED)
    results={}
    for name,path in CONDITIONS.items():
        results[name]=evaluate(
            bundle,query,structured,path,use_subset=(name=="original_reference")
        )

    control=results["control_0st"]
    rows=[]
    for condition in ("pitch_down_2st","pitch_up_2st"):
        current=results[condition]
        for i,pid in enumerate(SELECTED):
            rows.append({
                "participant_id":pid,
                "condition":condition,
                "target":float(control["target"][i]),
                "control_available":int(control["available"][i]),
                "modified_available":int(current["available"][i]),
                "route_changed":int(control["available"][i] != current["available"][i]),
                "control_local_norm":float(control["local_norm"][i]),
                "modified_local_norm":float(current["local_norm"][i]),
                "control_C":float(control["C"][i]),
                "modified_C":float(current["C"][i]),
                "delta_C":float(current["C"][i]-control["C"][i]),
                "control_P":float(control["P"][i]),
                "modified_P":float(current["P"][i]),
                "delta_P":float(current["P"][i]-control["P"][i]),
                "control_A_full":float(control["A"][i]),
                "modified_A_full":float(current["A"][i]),
                "delta_A_full":float(current["A"][i]-control["A"][i]),
                "delta_T_final":float(current["T"][i]-control["T"][i]),
                "delta_final_score":float(current["score"][i]-control["score"][i]),
                "valid_delta_C":int(abs(current["C"][i]-control["C"][i]) > TOLERANCE),
                "response_reversed":int(
                    abs(current["C"][i]-control["C"][i]) > TOLERANCE
                    and (current["A"][i]-control["A"][i])*(current["C"][i]-control["C"][i]) < 0
                ),
            })
    with (OUT/"FULL_PATH_INTERVENTION_RESULTS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

    condition_reports={}
    for condition in ("pitch_down_2st","pitch_up_2st"):
        cr=[r for r in rows if r["condition"]==condition]
        valid=[r for r in cr if r["valid_delta_C"]]
        condition_reports[condition]={
            "participants":len(cr),
            "route_change_count":sum(r["route_changed"] for r in cr),
            "valid_response_count":len(valid),
            "delta_C_tolerance":TOLERANCE,
            "response_reversal_count":sum(r["response_reversed"] for r in valid),
            "response_reversal_rate":(
                sum(r["response_reversed"] for r in valid)/len(valid) if valid else None
            ),
            "delta_C":describe([r["delta_C"] for r in cr]),
            "delta_P":describe([r["delta_P"] for r in cr]),
            "delta_A_full":describe([r["delta_A_full"] for r in cr]),
            "delta_T_final":describe([r["delta_T_final"] for r in cr]),
            "delta_final_score":describe([r["delta_final_score"] for r in cr]),
            "mean_abs_A_to_C_ratio_on_valid":(
                float(np.mean([abs(r["delta_A_full"])/abs(r["delta_C"]) for r in valid]))
                if valid else None
            ),
        }

    original=results["original_reference"]
    control_drift={
        "route_change_count":int(np.count_nonzero(original["available"]!=control["available"])),
        "delta_C":describe(control["C"]-original["C"]),
        "delta_P":describe(control["P"]-original["P"]),
        "delta_A_full":describe(control["A"]-original["A"]),
        "delta_final_score":describe(control["score"]-original["score"]),
    }
    acoustic=acoustic_report()
    report={
        "version":"depalign-full-path-audio-intervention-v1",
        "created_at_utc":datetime.now(timezone.utc).isoformat(),
        "scope":"behavioral consistency diagnostic; no clinical direction label is assigned to pitch changes",
        "cohort":{
            "split":"official DAIC development",
            "participants":len(SELECTED),
            "ids":list(SELECTED),
            "selection":"ten dual-path-active participants with the smallest audited window counts, fixed before response inspection",
        },
        "intervention":{
            "type":"duration-preserving pitch shift on every audited participant speech window",
            "conditions":{"control_0st":0.0,"pitch_down_2st":-2.0,"pitch_up_2st":2.0},
            "comparison":"each nonzero shift versus zero-semitone same-pipeline control",
            "delta_C_validity_tolerance_phq_points":TOLERANCE,
        },
        "acoustic_checks":acoustic,
        "text_check":{
            "transcript_metadata_unchanged":True,
            "all_transcript_hashes_present":bool(all(v["all_transcript_hashes_present"] for v in acoustic.values())),
            "asr_semantic_equivalence_tested":False,
        },
        "route_state":{
            name:{
                "active":int(r["available"].sum()),
                "total":len(r["available"]),
                "activation_rate":float(r["available"].mean()),
                "local_norm":describe(r["local_norm"]),
            }
            for name,r in results.items()
        },
        "processing_control_drift_vs_original":control_drift,
        "condition_results":condition_reports,
        "numerical_checks":{
            name:{
                "reconstruction_error":r["reconstruction_error"],
                "deep_decomposition_error":r["deep_decomposition_error"],
            }
            for name,r in results.items()
        },
        "interpretation_boundary":"Response reversal compares the sign of delta A_full with delta C where abs(delta C)>0.01. It tests whether adding P reverses the checked-path response; it is not a clinical correctness score.",
        "inputs":{name:{"path":str(path),"sha256":sha256(path)} for name,path in CONDITIONS.items()},
    }
    (OUT/"FULL_PATH_INTERVENTION_REPORT.json").write_text(
        json.dumps(report,indent=2,sort_keys=True)+"\n",encoding="utf-8"
    )
    audited=[
        OUT/"PREPARATION_PROTOCOL.json",OUT/"ACOUSTIC_WINDOW_CHECKS.csv",
        OUT/"FULL_PATH_INTERVENTION_RESULTS.csv",OUT/"FULL_PATH_INTERVENTION_REPORT.json",
        *(OUT/f"{c}_WINDOWS.npz" for c in ("control_0st","pitch_down_2st","pitch_up_2st")),
        *(OUT/f"{c}_SUBJECT.npz" for c in ("control_0st","pitch_down_2st","pitch_up_2st")),
    ]
    audit={
        "version":"depalign-full-path-audio-intervention-audit-v1",
        "passed":bool(
            all(r["reconstruction_error"]<=1e-8 and r["deep_decomposition_error"]<=1e-8 for r in results.values())
            and all(v["maximum_absolute_duration_change_seconds"]<=1e-12 for v in acoustic.values())
            and all(v["route_change_count"]==0 for v in condition_reports.values())
        ),
        "artifact_sha256":{p.name:sha256(p) for p in audited},
    }
    (OUT/"AUDIT.json").write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(json.dumps({"report":report,"audit":audit},indent=2,sort_keys=True))


if __name__=="__main__":
    main()
