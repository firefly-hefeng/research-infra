# DepAlign 相关研究代码快照

本包来自服务器已保存的 DepAlign / IC-EDF 相关源码快照，用于阅读模型、训练和干预评估方法。

## 内容

- `model_source.py`、`training_source.py`：R22 compact MSIA 模型与训练源码快照。
- `intervention/`：DepAlign 全路径干预的准备、评估与权衡分析代码。
- `route_audit/`：DepAlign 路径审计代码。

## 边界

这不是已经整理完成的独立推理 SDK，也不包含最终 `MODEL.joblib`、DAIC 数据、特征、预测结果或运行环境。最终模型文件位于服务器：

`/data/users/luyonghua/projects/depression-local-assets-20261028/runtime/edf-v1/evolving-ic-edf-20260921/test-v3/MODEL.joblib`

这些脚本保留原研究环境中的路径和依赖。复现前需由研究者核对源码、输入特征协议及依赖，不应把本包当作一键部署接口。
