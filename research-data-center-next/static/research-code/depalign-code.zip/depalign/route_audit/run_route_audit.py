from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np

ROOT = Path(r"C:\Users\Administrator\Documents\ChatGPT\抑郁症")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from depression_lab.daic_official_benchmark import bounded_additive_contributions, regression_metrics
from depression_lab.ic_edf_joint import slot_features
from scripts.evaluate_evolving_ic_edf import blend_decompositions, decompose_recent_artifact
from scripts.evaluate_evolving_interventions import _fixed_bundle, deliver_with_invariant_text
from scripts.evaluate_ra_ic_edf_interventions import _triplets, _voice_arrays, _voice_slot_matrix
from scripts.run_daic_official_benchmark import (
    load_aligned,
    make_representation,
    model_audio_slots,
    text_slot_contributions,
)
from scripts.run_ic_edf import align, load_npz

OUT = Path(r"D:\depression-lab\runtime\edf-v1\depalign-route-audit-20260922\v1")
RUNTIME = Path(r"D:\depression-lab\runtime\edf-v1")
EVOLVING = RUNTIME / "evolving-ic-edf-20260921"
OFFICIAL = RUNTIME / "official-benchmark-20260921"
FEATURES = RUNTIME / "subject-features"
WEIGHTS = (0.0, 0.25, 0.5, 0.75, 1.0)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def finite_float(x):
    x = float(x)
    return x if math.isfinite(x) else None


def describe(x: np.ndarray) -> dict:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if not len(x):
        return {"n": 0}
    qs = np.quantile(x, [0, .05, .25, .5, .75, .95, 1])
    return {
        "n": int(len(x)),
        "mean": float(x.mean()),
        "std": float(x.std()),
        "minimum": float(qs[0]),
        "q05": float(qs[1]),
        "q25": float(qs[2]),
        "median": float(qs[3]),
        "q75": float(qs[4]),
        "q95": float(qs[5]),
        "maximum": float(qs[6]),
        "mean_absolute": float(np.abs(x).mean()),
    }


def load_split(split: str) -> dict:
    if split == "dev":
        model_root = EVOLVING / "dev-v3"
        query = FEATURES / "DAIC_OFFICIAL_DEV_QUERY_FEATURES_SPARSE.npz"
        emotion = FEATURES / "DAIC_OFFICIAL_DEV_QUERY_EMOTION2VEC_LARGE_TOP20.npz"
        structured = FEATURES / "DAIC_OFFICIAL_DEV_IC_EDF_STRUCTURED_EVIDENCE.npz"
    elif split == "test":
        model_root = EVOLVING / "test-v3"
        f = OFFICIAL / "features"
        query = f / "DAIC_OFFICIAL_TEST_QUERY_FEATURES_SPARSE.npz"
        emotion = f / "DAIC_OFFICIAL_TEST_QUERY_EMOTION2VEC_LARGE_TOP20.npz"
        structured = f / "DAIC_OFFICIAL_TEST_IC_EDF_STRUCTURED_EVIDENCE.npz"
    else:
        raise ValueError(split)

    bundle = joblib.load(model_root / "MODEL.joblib")
    data = load_aligned([query], [emotion], [structured])
    saved = np.load(model_root / "CONTRIBUTIONS.npz", allow_pickle=False)
    base_text, _ = text_slot_contributions(bundle["text_model"], data["text"])

    parent = bundle["fixed_parent"]
    fixed_rep = make_representation(
        data,
        np.asarray(parent["esd_axis"]["raw_weight"]),
        float(parent["intervention_scale"]),
    )
    fixed_audio = model_audio_slots(
        bundle["fixed_model"], fixed_rep["feature"], 0.5, 2.0, smooth=False
    )
    fixed_pred, fixed_text, fixed_audio = bounded_additive_contributions(base_text, fixed_audio)
    # Preserve the immutable benchmark predictions used by the released result.
    fixed_delta = np.asarray(saved["fixed_prediction"], float) - fixed_pred
    fixed_audio = fixed_audio + fixed_delta[:, None] / 8.0
    fixed_pred = np.asarray(saved["fixed_prediction"], float)

    rich_audio = slot_features(data, bundle["rich_representation"])
    local_width = rich_audio.shape[-1] // 2
    local_norm = np.sqrt(
        np.mean(np.square(rich_audio[:, :, local_width:]), axis=(1, 2))
    )
    available = local_norm > 1e-8
    text_3d = np.asarray(data["text"]).reshape(len(data["target"]), 8, -1)
    rows = [
        decompose_recent_artifact(artifact, text_3d, rich_audio)
        for artifact in bundle["recent_artifacts"]
    ]
    deep_text_residual = np.mean(np.stack([row[1] for row in rows]), axis=0)
    deep_audio = np.mean(np.stack([row[2] for row in rows]), axis=0)
    deep_pred, deep_text, deep_audio = bounded_additive_contributions(
        base_text + deep_text_residual, deep_audio
    )
    deep_delta = np.asarray(saved["deep_prediction"], float) - deep_pred
    deep_audio = deep_audio + deep_delta[:, None] / 8.0
    deep_pred = np.asarray(saved["deep_prediction"], float)

    alpha = float(bundle["selected_fixed_weight"])
    effective = np.where(available, alpha, 1.0)
    final_pred, final_text, final_audio, recon = blend_decompositions(
        fixed_text, fixed_audio, deep_text, deep_audio, fixed_weight=effective
    )
    saved_pred = np.asarray(saved["prediction"], float)
    saved_text = np.asarray(saved["text_slots"], float)
    saved_audio = np.asarray(saved["audio_slots"], float)
    errors = {
        "fixed_exact_prediction_error": float(np.max(np.abs(fixed_pred - saved["fixed_prediction"]))),
        "deep_exact_prediction_error": float(np.max(np.abs(deep_pred - saved["deep_prediction"]))),
        "final_prediction_vs_saved": float(np.max(np.abs(final_pred - saved_pred))),
        "final_text_vs_saved": float(np.max(np.abs(final_text - saved_text))),
        "final_audio_vs_saved": float(np.max(np.abs(final_audio - saved_audio))),
        "reconstruction_error": float(recon),
    }
    saved.close()
    return {
        "split": split,
        "model_root": model_root,
        "query": query,
        "emotion": emotion,
        "structured": structured,
        "bundle": bundle,
        "data": data,
        "base_text": base_text,
        "fixed_pred": fixed_pred,
        "fixed_text": fixed_text,
        "fixed_audio": fixed_audio,
        "deep_pred": deep_pred,
        "deep_text": deep_text,
        "deep_audio": deep_audio,
        "available": available,
        "local_norm": local_norm,
        "alpha": alpha,
        "effective": effective,
        "final_pred": final_pred,
        "final_text": final_text,
        "final_audio": final_audio,
        "errors": errors,
    }


def write_daic_table(result: dict) -> Path:
    split = result["split"]
    path = OUT / f"DAIC_{split.upper()}_PATHS.csv"
    c = result["fixed_audio"].sum(1)
    p = result["deep_audio"].sum(1)
    a = result["final_audio"].sum(1)
    t = result["final_text"].sum(1)
    weighted_p = (1.0 - result["effective"]) * p
    net = a - c
    rows = []
    for i, pid in enumerate(map(str, result["data"]["ids"])):
        rows.append({
            "participant_id": pid,
            "target": float(result["data"]["target"][i]),
            "availability_mask": int(result["available"][i]),
            "local_residual_norm": float(result["local_norm"][i]),
            "pp_enabled": int(result["available"][i]),
            "fallback": int(not result["available"][i]),
            "selected_alpha": float(result["alpha"]),
            "effective_alpha": float(result["effective"][i]),
            "C_audio_contribution": float(c[i]),
            "P_audio_contribution": float(p[i]),
            "weighted_P_term": float(weighted_p[i]),
            "A_final_audio_contribution": float(a[i]),
            "P_net_effect_vs_fallback": float(net[i]),
            "T_final_text_contribution": float(t[i]),
            "final_score": float(result["final_pred"][i]),
        })
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    np.savez_compressed(
        OUT / f"DAIC_{split.upper()}_PATH_SLOTS.npz",
        participant_id=np.asarray(result["data"]["ids"]),
        target=np.asarray(result["data"]["target"], float),
        availability_mask=np.asarray(result["available"], bool),
        local_residual_norm=np.asarray(result["local_norm"], float),
        fixed_text_slots=result["fixed_text"],
        fixed_audio_slots=result["fixed_audio"],
        predictive_text_slots=result["deep_text"],
        predictive_audio_slots=result["deep_audio"],
        final_text_slots=result["final_text"],
        final_audio_slots=result["final_audio"],
        final_score=result["final_pred"],
    )
    return path


def esd_paths() -> dict:
    model_root = EVOLVING / "dev-v3"
    bundle = joblib.load(model_root / "MODEL.joblib")
    context = align(
        load_npz(FEATURES / "DAIC_SYMPTOM_QUERY_FEATURES_SPARSE.npz"),
        load_npz(FEATURES / "DAIC_QUERY_EMOTION2VEC_LARGE_TOP20.npz"),
        load_npz(FEATURES / "DAIC_IC_EDF_STRUCTURED_EVIDENCE.npz"),
    )
    esd = load_npz(FEATURES / "ESD_EMOTION2VEC_LARGE_FEATURES.npz")
    indices = _triplets(esd, dataset="esd", split="test")
    flat = indices.reshape(-1)
    embedding, probability = _voice_arrays(esd, dataset="esd")
    fixed_audio = _voice_slot_matrix(
        _fixed_bundle(bundle), embedding[flat], probability[flat], context
    )
    base_text, _ = text_slot_contributions(bundle["text_model"], context["text"])
    delivered_text, delivered_audio, score, error = deliver_with_invariant_text(
        base_text, fixed_audio
    )
    c = delivered_audio.sum(-1)
    t = delivered_text.sum(-1)
    voices, contexts = c.shape
    voice_ids = np.asarray(esd["id"])[flat]
    voice_emotion = np.asarray(esd["emotion"])[flat]
    voice_speaker = np.asarray(esd["speaker_id"])[flat]
    voice_text_id = np.asarray(esd["text_id"])[flat]
    context_ids = np.asarray(context["ids"])
    path = OUT / "ESD_TEST_PATHS.csv"
    fieldnames = [
        "utterance_id", "speaker_id", "text_id", "emotion", "context_participant_id",
        "availability_mask", "pp_enabled", "fallback", "C_audio_contribution",
        "P_audio_contribution", "weighted_P_term", "A_final_audio_contribution",
        "P_net_effect_vs_fallback", "T_final_text_contribution", "final_score",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for i in range(voices):
            for j in range(contexts):
                w.writerow({
                    "utterance_id": str(voice_ids[i]),
                    "speaker_id": str(voice_speaker[i]),
                    "text_id": int(voice_text_id[i]),
                    "emotion": str(voice_emotion[i]),
                    "context_participant_id": str(context_ids[j]),
                    "availability_mask": 0,
                    "pp_enabled": 0,
                    "fallback": 1,
                    "C_audio_contribution": float(c[i, j]),
                    "P_audio_contribution": "",
                    "weighted_P_term": 0.0,
                    "A_final_audio_contribution": float(c[i, j]),
                    "P_net_effect_vs_fallback": 0.0,
                    "T_final_text_contribution": float(t[i, j]),
                    "final_score": float(score[i, j]),
                })
    np.savez_compressed(
        OUT / "ESD_TEST_PATH_ARRAYS.npz",
        triplet_indices=indices,
        utterance_id=voice_ids,
        speaker_id=voice_speaker,
        text_id=voice_text_id,
        emotion=voice_emotion,
        context_participant_id=context_ids,
        availability_mask=np.zeros((voices, contexts), dtype=bool),
        C_audio_contribution=c,
        A_final_audio_contribution=c,
        T_final_text_contribution=t,
        final_score=score,
    )
    return {
        "rows": int(voices * contexts),
        "utterances": int(voices),
        "contexts": int(contexts),
        "activation_rate": 0.0,
        "fallback_rate": 1.0,
        "E_fallback": 0.0,
        "reconstruction_error": float(error),
        "identity": "fallback-path evaluation",
        "path": path,
    }


def alpha_scan(result: dict) -> list[dict]:
    rows = []
    y = np.asarray(result["data"]["target"], float)
    active = np.asarray(result["available"], bool)
    for alpha in WEIGHTS:
        effective = np.where(active, alpha, 1.0)
        pred, _, _, error = blend_decompositions(
            result["fixed_text"], result["fixed_audio"],
            result["deep_text"], result["deep_audio"],
            fixed_weight=effective,
        )
        row = {
            "split": result["split"],
            "analysis_status": "development protocol" if result["split"] == "dev" else "retrospective test sensitivity",
            "alpha_fixed_C": alpha,
            "prediction_path_weight": 1.0 - alpha,
            "active_n": int(active.sum()),
            "fallback_n": int((~active).sum()),
            "selected_on_dev": int(alpha == result["alpha"]),
            "reconstruction_error": error,
            **regression_metrics(y, pred),
        }
        if active.any():
            am = regression_metrics(y[active], pred[active])
            row.update({f"active_{k}": v for k, v in am.items()})
        if (~active).any():
            fm = regression_metrics(y[~active], pred[~active])
            row.update({f"fallback_{k}": v for k, v in fm.items()})
        rows.append(row)
    return rows


def single_path_rows(results: list[dict]) -> list[dict]:
    rows = []
    for result in results:
        split = result["split"]
        y = np.asarray(result["data"]["target"], float)
        official_metrics = json.loads(
            (OFFICIAL / f"{split}-run-v2" / "METRICS.json").read_text(encoding="utf-8")
        )
        text = official_metrics["methods"]["strong_text"]["regression"]
        rows.append({"split": split, "variant": "T", "source": "official strong_text", **text})
        rows.append({
            "split": split, "variant": "T+C", "source": "released fixed path",
            **regression_metrics(y, result["fixed_pred"]),
        })
        rows.append({
            "split": split, "variant": "T+P", "source": "released predictive path",
            **regression_metrics(y, result["deep_pred"]),
        })
        rows.append({
            "split": split, "variant": "T+0.5C+0.5P with availability fallback",
            "source": "released DepAlign",
            **regression_metrics(y, result["final_pred"]),
        })
    return rows


def main():
    existing = [p for p in OUT.iterdir() if p.name != "run_route_audit.py"]
    if existing:
        raise RuntimeError(f"output must be empty except script: {existing}")
    dev = load_split("dev")
    test = load_split("test")
    for result in (dev, test):
        write_daic_table(result)
    esd = esd_paths()

    scan = [*alpha_scan(dev), *alpha_scan(test)]
    with (OUT / "ALPHA_SCAN.csv").open("w", newline="", encoding="utf-8") as f:
        keys = list(dict.fromkeys(k for r in scan for k in r))
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(scan)

    singles = single_path_rows([dev, test])
    with (OUT / "SINGLE_PATH_CONTROLS.csv").open("w", newline="", encoding="utf-8") as f:
        keys = list(dict.fromkeys(k for r in singles for k in r))
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(singles)

    coverage = {}
    pp_distribution = {}
    for result in (dev, test):
        key = result["split"]
        active = result["available"]
        c = result["fixed_audio"].sum(1)
        p = result["deep_audio"].sum(1)
        a = result["final_audio"].sum(1)
        fallback = ~active
        coverage[key] = {
            "inputs": int(len(active)),
            "prediction_path_active": int(active.sum()),
            "prediction_path_activation_rate": float(active.mean()),
            "fallback_inputs": int(fallback.sum()),
            "fallback_rate": float(fallback.mean()),
            "E_fallback": float(np.max(np.abs(a[fallback] - c[fallback]), initial=0.0)),
            "selected_alpha": float(result["alpha"]),
            "numerical_checks": result["errors"],
        }
        pp_distribution[key] = {
            "raw_P": describe(p[active]),
            "weighted_P_term": describe((1.0 - result["alpha"]) * p[active]),
            "net_effect_on_A_vs_fallback": describe((a - c)[active]),
            "C_on_active": describe(c[active]),
            "A_full_on_active": describe(a[active]),
        }
    coverage["esd_test"] = {k: v for k, v in esd.items() if k != "path"}

    report = {
        "version": "depalign-route-audit-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "definitions": {
            "C": "post-bound checked/calibration-path audio contribution",
            "P": "post-bound predictive-path audio contribution",
            "A_full": "audio contribution after availability-gated convex blend",
            "weighted_P_term": "(1-effective_alpha)*P",
            "P_net_effect_vs_fallback": "A_full-C=(1-effective_alpha)*(P-C)",
            "E_fallback": "max over unavailable inputs of abs(A_full-C)",
        },
        "coverage": coverage,
        "predictive_path_contribution_distribution": pp_distribution,
        "single_path_controls": singles,
        "alpha_scan": scan,
        "interpretation": {
            "esd": "The released ESD protocol has no symptom-conditioned local audio residual; availability is false for every ESD utterance-context input. Its MSIA is therefore fallback-path evidence for C, not a validation of the full C/P blend.",
            "test_scan": "All test alpha rows are retrospective sensitivity analyses and were not used for selection.",
        },
        "inputs": {
            "dev_model": str(dev["model_root"] / "MODEL.joblib"),
            "test_model": str(test["model_root"] / "MODEL.joblib"),
            "esd_features": str(FEATURES / "ESD_EMOTION2VEC_LARGE_FEATURES.npz"),
        },
    }
    (OUT / "REPORT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    artifacts = sorted(p for p in OUT.iterdir() if p.is_file())
    audit = {
        "version": "depalign-route-audit-artifacts-v1",
        "passed": bool(
            all(v["E_fallback"] <= 1e-12 for v in coverage.values())
            and all(
                result["errors"]["final_prediction_vs_saved"] <= 5e-3
                for result in (dev, test)
            )
        ),
        "artifact_sha256": {p.name: sha256(p) for p in artifacts},
    }
    (OUT / "AUDIT.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"report": report, "audit": audit}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()



