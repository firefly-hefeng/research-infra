# 中文声音表达融合头 v2 源码快照

`source_snapshot.py` 是训练分层情绪分类头的源码快照。它将冻结的 emotion2vec 1024 维 embedding 与 9 维原生概率拼接，标准化后训练 valence、negative、positive 三个 Logistic Regression 分支。

## 输入与输出

- 训练输入：speaker-isolated train/dev manifests，以及对应 NPZ 中的 `embeddings`、`probabilities`、`ids` 和情绪标签。
- 模型工件：`valence-head.npz`、`negative-head.npz`、`positive-head.npz`。
- 输出类别：`neutral`、`happy`、`sad`、`angry`、`fear`、`surprise` 的概率及最大概率类别。

## 边界

本包只包含训练源码快照，不包含 emotion2vec、音频、特征、依赖模块或完整独立推理入口。它属于声音情绪辅助模块，不预测抑郁严重度；目前只有开发集结果，尚未完成测试和生产批准。
