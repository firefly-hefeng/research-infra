"""Train a fused emotion2vec representation + native-probability fine-emotion head.

The acoustic encoder is frozen.  The fitted heads use only the speaker-isolated
train/dev manifests and keep the sealed test split unavailable to this script.
"""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from depression_lab.distillation_data import atomic_json, read_jsonl, sha256
from depression_lab.fine_emotion import (
    FINE_LABELS,
    NEGATIVE_LABELS,
    POSITIVE_LABELS,
    VALENCE_LABELS,
    combine_hierarchical_probabilities,
)

DATA = Path("D:/depression-lab/runtime/voice-specialist-cse-large")
OUT = Path("D:/depression-lab/runtime/voice-specialist-cse-large-fused-head")
VALENCE_MAP = {
    "happy": "positive", "surprise": "positive", "neutral": "neutral",
    "sad": "negative", "angry": "negative", "fear": "negative",
}


def metric(gold: np.ndarray, predicted: np.ndarray) -> dict:
    from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

    return {
        "n": int(len(gold)),
        "accuracy": float(accuracy_score(gold, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(gold, predicted)),
        "macro_f1": float(f1_score(gold, predicted, labels=list(FINE_LABELS), average="macro")),
    }


def fused(features: np.lib.npyio.NpzFile) -> np.ndarray:
    """Append the frozen encoder's native probabilities to its embedding.

    Standardization is fitted on the training partition, so the bounded
    native probabilities contribute as a separate calibrated evidence block.
    """
    embedding = features["embeddings"].astype(np.float64)
    native = features["probabilities"].astype(np.float64)
    return np.concatenate([embedding, native], axis=1)


def save_classifier(path: Path, scaler, classifier) -> None:
    np.savez_compressed(
        path,
        mean=scaler.mean_, scale=scaler.scale_, coef=classifier.coef_,
        intercept=classifier.intercept_, classes=classifier.classes_,
    )


def main() -> None:
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler

    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    shutil.copyfile(__file__, OUT / "source_snapshot.py")
    protocol = json.loads((DATA / "protocol.json").read_text(encoding="utf-8"))
    train = read_jsonl(DATA / "train.jsonl")
    dev = read_jsonl(DATA / "dev.jsonl")
    if any(row.get("split") != "train" for row in train) or any(row.get("split") != "dev" for row in dev):
        raise ValueError("only train/dev rows are allowed")
    for name in ("train.jsonl", "dev.jsonl"):
        if sha256(DATA / name) != protocol["manifest_hashes"][name]:
            raise ValueError(f"manifest changed: {name}")
    train_features = np.load(DATA / "features" / "train.npz")
    dev_features = np.load(DATA / "features" / "dev.npz")
    if train_features["ids"].tolist() != [row["id"] for row in train]:
        raise ValueError("train feature ids do not match manifest")
    if dev_features["ids"].tolist() != [row["id"] for row in dev]:
        raise ValueError("dev feature ids do not match manifest")

    x_train, x_dev = fused(train_features), fused(dev_features)
    fine_train = np.array([row["emotion"] for row in train])
    fine_dev = np.array([row["emotion"] for row in dev])
    valence_train = np.array([VALENCE_MAP[label] for label in fine_train])
    scaler = StandardScaler().fit(x_train)
    x_train, x_dev = scaler.transform(x_train), scaler.transform(x_dev)

    # Fixed after a train/dev-only sweep.  The low valence C regularizes the
    # coarse branch while the conditional branches preserve fine distinctions.
    valence = LogisticRegression(C=0.001, class_weight="balanced", max_iter=10000, solver="lbfgs")
    negative = LogisticRegression(C=1.0, class_weight="balanced", max_iter=10000, solver="lbfgs")
    positive = LogisticRegression(C=1.0, class_weight="balanced", max_iter=10000, solver="lbfgs")
    valence.fit(x_train, valence_train)
    negative_mask = np.isin(fine_train, NEGATIVE_LABELS)
    positive_mask = np.isin(fine_train, POSITIVE_LABELS)
    negative.fit(x_train[negative_mask], fine_train[negative_mask])
    positive.fit(x_train[positive_mask], fine_train[positive_mask])
    negative_probs = negative.predict_proba(x_dev)
    positive_probs = positive.predict_proba(x_dev)
    probabilities = combine_hierarchical_probabilities(
        valence.predict_proba(x_dev),
        negative_probs[:, [list(negative.classes_).index(label) for label in NEGATIVE_LABELS]],
        positive_probs[:, [list(positive.classes_).index(label) for label in POSITIVE_LABELS]],
    )
    predicted = np.array(FINE_LABELS)[probabilities.argmax(axis=1)]
    confidence = probabilities.max(axis=1)
    gates = {}
    for threshold in (0.25, 0.35, 0.45, 0.55, 0.65):
        mask = confidence >= threshold
        gates[str(threshold)] = {
            "threshold": threshold,
            "coverage": float(mask.mean()),
            "deferred": int((~mask).sum()),
            "metrics": metric(fine_dev[mask], predicted[mask]) if mask.any() else None,
        }

    save_classifier(OUT / "valence-head.npz", scaler, valence)
    save_classifier(OUT / "negative-head.npz", scaler, negative)
    save_classifier(OUT / "positive-head.npz", scaler, positive)
    np.savez_compressed(OUT / "dev-probabilities.npz", probabilities=probabilities, ids=dev_features["ids"])
    atomic_json(OUT / "feature-spec.json", {
        "type": "emotion2vec_embedding_plus_native_probabilities",
        "embedding_dim": int(train_features["embeddings"].shape[1]),
        "native_probability_dim": int(train_features["probabilities"].shape[1]),
        "standardized": True,
    })
    atomic_json(OUT / "result.json", {
        "version": "cse-fused-hierarchical-fine-emotion-v1",
        "class_order": list(FINE_LABELS),
        "valence_order": list(VALENCE_LABELS),
        "negative_order": list(NEGATIVE_LABELS),
        "positive_order": list(POSITIVE_LABELS),
        "label_map": VALENCE_MAP,
        "train_n": len(train), "dev_n": len(dev),
        "test_evaluated": False, "production_approved": False,
        "classifier": {
            "type": "hierarchical_logistic_regression",
            "valence_C": 0.001, "negative_C": 1.0, "positive_C": 1.0,
            "class_weight": "balanced",
        },
        "full_dev": metric(fine_dev, predicted),
        "confidence_gates": gates,
        "feature_sha256": {
            "train": sha256(DATA / "features" / "train.npz"),
            "dev": sha256(DATA / "features" / "dev.npz"),
        },
        "source_manifest_sha256": {
            "train": sha256(DATA / "train.jsonl"),
            "dev": sha256(DATA / "dev.jsonl"),
        },
    })
    print(json.dumps({"full_dev": metric(fine_dev, predicted), "gate_0.55": gates["0.55"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
