# MMPsy v3 相关研究代码快照

本包包含服务器 `mmpsy-v2/frozen_source` 中冻结的 Python 源码，以及解释 LoRA 的原始 README。v3 模型清单指向这套运行时代码。

## 已确认的接口

`depression_lab.mmpsy_runtime.MMPsyRuntime(artifact)` 加载模型工件；`predict(row, explain=True)` 返回来源绑定的评估报告。

输入记录需要：

- `audio_paths`：原始录音路径列表；
- `audio_sha256`：与录音逐一对应的 SHA-256 列表；
- `turns`：对话轮次及文本；
- `transcript`：与 turns 一致的转写；
- 可选 `audio_transcript`、`aligned_segments` 等对应对齐信息。

主要输出包括 `score_0_100`、严重度分布、来源证据、解释和模型版本信息。分数定义为 `100 * PHQ9_raw / 27`，不是与 SDS 或 DepAlign 可直接比较的同一量表。

## 边界

本包不包含模型权重、语义编码器、Qwen 模型、录音、数据清单、预测结果或 Python 依赖环境。源码保留研究环境中的绝对路径，复现前必须改为实际服务器路径并核对依赖。当前 v3 只有开发集结果，测试未完成，不能作为临床或已验证生产接口。
