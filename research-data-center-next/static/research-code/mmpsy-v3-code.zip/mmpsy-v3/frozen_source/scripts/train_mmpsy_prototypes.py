"""Hard, source-grounded semantic prototype bottleneck feasibility (dev only).

Unsupervised transcript prototypes are language patterns, NOT clinical symptoms.
Only discrete assignments/counts and measured mel facts reach the fitted scorer.
This experimental route is deliberately separate from the nine-symptom model.
"""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
from depression_lab.source_prototypes import SourcePrototypes
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from scipy.stats import spearmanr
from threadpoolctl import threadpool_limits
from scripts.prepare_mmpsy_v2 import ROOT, sha


def features(assignments, bounds, k):
    counts = np.stack([np.bincount(assignments[a:b], minlength=k) for a, b in zip(bounds[:-1], bounds[1:], strict=True)])
    # Finite bins; no embedding, continuous similarity, or confidence bypass.
    return np.stack([counts > 0, counts > 1, counts > 3], axis=-1).reshape(len(counts), -1).astype(float)


def main():
    out = ROOT / 'prototype-feasibility'
    out.mkdir(exist_ok=True)
    config = {'clusters': [32, 64, 128, 256], 'alphas': [.1, 1, 10, 100, 1000], 'seed': 20260909,
              'algorithm': 'train-only deterministic Lloyd20 random source initialization; hard nearest assignments; count thresholds 0,1,3',
              'score_definition': 'mmpsy-phq-severity-index-v2', 'clinical_concepts': False,
              'test_access': False, 'protocol_sha256': sha(ROOT / 'protocol.json')}
    (out / 'configuration.json').write_text(json.dumps(config, indent=2))
    # Materialize arrays once; NpzFile lookup decompresses on EVERY access.
    data = {s: dict(np.load(ROOT / f'{s}.features.npz')) for s in ['train', 'dev']}
    targets = {s: json.loads((ROOT / f'{s}.targets.json').read_text()) for s in data}
    y = {s: np.array([targets[s][uid] for uid in data[s]['participant_ids']]) for s in data}
    scaler = StandardScaler().fit(data['train']['mel'])
    mel = {s: scaler.transform(data[s]['mel']) / np.sqrt(160) for s in data}
    segments = json.loads((ROOT / 'train.segments.json').read_text(encoding='utf8'))
    results = []
    for k in config['clusters']:
        km = SourcePrototypes(k, config['seed']).fit(data['train']['segment_vectors'])
        assignment = {s: km.predict(data[s]['segment_vectors']) for s in data}
        x = {s: features(assignment[s], data[s]['bounds'], k) for s in data}
        examples = []
        for c in range(k):
            ix = np.flatnonzero(assignment['train'] == c)
            chosen = sorted(ix, key=lambda i: np.square(data['train']['segment_vectors'][i] - km.cluster_centers_[c]).sum())[:3]
            examples.append({'prototype_id': c, 'training_source_examples': [segments[i] for i in chosen],
                             'clinical_interpretation': None})
        for modality in ['semantic', 'semantic_audio']:
            model_x = {s: x[s] if modality == 'semantic' else np.concatenate([x[s], mel[s]], axis=1) for s in data}
            trials = []
            for alpha in config['alphas']:
                model = Ridge(alpha=alpha).fit(model_x['train'], y['train'])
                pred = np.clip(model.predict(model_x['dev']), 0, 100)
                trials.append((float(np.abs(pred-y['dev']).mean()), alpha, model, pred))
            mae, alpha, model, pred = min(trials, key=lambda t: t[0])
            name = f'{modality}-{k}'
            record = {'name': name, 'mae': mae, 'alpha': alpha, 'rho': float(spearmanr(pred, y['dev']).statistic),
                      'prediction_std': float(pred.std()), 'all_trials': [{'mae': m, 'alpha': a} for m, a, _, _ in trials]}
            print(json.dumps(record), flush=True)
            results.append(record)
            joblib.dump({'kind': name, 'clusterer': km, 'mel_scaler': scaler, 'regressor': model,
                         'prototypes': examples, 'no_hidden_bypass': True}, out / f'{name}.joblib')
            (out / f'{name}.dev.json').write_text(json.dumps(pred.tolist()))
        (out / 'results.json').write_text(json.dumps(results, indent=2))


if __name__ == '__main__':
    with threadpool_limits(4):
        main()
