"""Development-only MMPsy PHQ-9 baselines; separate from the SDS product index."""

import argparse
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits


def read(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf8").splitlines()]


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf8")


def split_for(uid):
    value = int(hashlib.sha256(f"mmpsy-expansion-v1:{uid}".encode()).hexdigest()[:8], 16) % 10
    return "dev" if value == 8 else "test" if value == 9 else "train"


def pooled_mel(folder):
    """Preserve all released frames, removing published overlap and zero padding."""
    paths = sorted(folder.glob("*.npy"), key=lambda p: int(p.stem))
    if not paths:
        raise ValueError(f"Missing author mel features: {folder}")
    frames = []
    for index, path in enumerate(paths):
        data = np.load(path, allow_pickle=False)
        if data.shape != (80, 1800) or not np.isfinite(data).all():
            raise ValueError(f"Invalid author mel shape/values: {path}")
        # Authors publish 1800-frame windows with stride1500; do not count
        # the first300 frames of later windows twice. Only trailing all-zero
        # columns are documented padding, not symptom observations.
        data = data[:, 300:] if index else data
        nonzero = np.flatnonzero(np.any(data != 0, axis=0))
        if len(nonzero):
            frames.append(data[:, :nonzero[-1] + 1])
    if not frames:
        raise ValueError("All released mel frames are padding")
    merged = np.concatenate(frames, axis=1)
    return np.concatenate([merged.mean(axis=1), merged.std(axis=1)])


def main(data, out):
    out.mkdir(parents=True, exist_ok=True)
    if (out / "dev_results.json").exists():
        print((out / "dev_results.json").read_text(encoding="utf8"))
        return
    config = {
        "dataset": "MMPsy", "target": "independent PHQ-9 raw total 0..27; not SDS product index",
        "modalities": ["median", "text", "author_mel", "text_author_mel"],
        "alphas": [0.1, 1, 10, 100, 1000], "max_text_features": 12000,
        "split": "stable participant hash, 80/10/10 buckets", "test_evaluated": False,
        "excluded_participants": ["user_632", "user_1264"],
        "exclusion_reason": "Label-blind source audit: discussion of questionnaire answer options; audio offsets unavailable",
        "text": "Full released answer text; no author BERT512 truncation; unavailable questions not invented",
        "audio": "160 pooled band mean/std from all non-overlapping released normalized mel frames; not raw waveforms",
        "input_sha256": hashlib.sha256((data / "semantic_inputs.label_blind.jsonl").read_bytes()).hexdigest(),
        "target_sha256": hashlib.sha256((data / "independent_targets.jsonl").read_bytes()).hexdigest(),
        "used_in_unified_v3": False, "product_model_replaced": False,
    }
    config_path = out / "config.json"
    if config_path.exists() and json.loads(config_path.read_text(encoding="utf8")) != config:
        raise ValueError("Configuration changed; use a new experiment version")
    write(config_path, config)
    rows = read(data / "semantic_inputs.label_blind.jsonl")
    targets = {r["participant_id"]: r["phq9_raw"] for r in read(data / "independent_targets.jsonl")}
    if len({r["participant_id"] for r in rows}) != len(rows) or len(rows) != 1275:
        raise ValueError("Unexpected or duplicate MMPsy participant IDs")
    assignments = {r["participant_id"]: split_for(r["participant_id"]) for r in rows}
    write(out / "participant_splits.json", assignments)
    active = [r for r in rows if r["participant_id"] not in config["excluded_participants"]]
    selected = {s: [r for r in active if assignments[r["participant_id"]] == s] for s in ["train", "dev"]}
    xtext = {s: ["\n".join(t["text"] for t in r["turns"]) for r in group] for s, group in selected.items()}
    y = {s: np.array([targets[r["participant_id"]] for r in group], dtype=float) for s, group in selected.items()}
    if any(np.any((values < 0) | (values > 27)) for values in y.values()):
        raise ValueError("PHQ9 target out of range")
    vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(1, 3), max_features=12000, sublinear_tf=True)
    text = {"train": vectorizer.fit_transform(xtext["train"])}
    text["dev"] = vectorizer.transform(xtext["dev"])
    audio = {}
    for split, group in selected.items():
        audio[split] = np.stack([pooled_mel(data / "np_data" / r["participant_id"] / "mel-spectrogram") for r in group])
    scaler = StandardScaler().fit(audio["train"])
    audio = {s: csr_matrix(scaler.transform(x) / np.sqrt(x.shape[1])) for s, x in audio.items()}
    value = float(np.median(y["train"]))
    joblib.dump({"kind": "constant", "value": value, "target_definition": config["target"]}, out / "median.joblib")
    result = [{"name": "median", "dev_mae_phq9": float(np.abs(y["dev"] - value).mean())}]
    for modality in ["text", "author_mel", "text_author_mel"]:
        x = {s: text[s] if modality == "text" else audio[s] if modality == "author_mel"
             else hstack([text[s], audio[s]]).tocsr() for s in ["train", "dev"]}
        trials = []
        for alpha in config["alphas"]:
            model = Ridge(alpha=alpha, solver="lsqr").fit(x["train"], y["train"])
            prediction = np.clip(model.predict(x["dev"]), 0, 27)
            trials.append((float(np.abs(prediction - y["dev"]).mean()), alpha, model))
        mae, alpha, model = min(trials, key=lambda r: (r[0], r[1]))
        joblib.dump({"kind": modality, "vectorizer": vectorizer, "scaler": scaler, "regressor": model,
                     "target_definition": config["target"], "raw_audio_available": False}, out / f"{modality}.joblib")
        result.append({"name": modality, "dev_mae_phq9": mae, "alpha": alpha,
                       "all_dev_trials": [{"mae": m, "alpha": a} for m, a, _ in trials]})
    result = {"results": result, "counts": {s: sum(assignments[r["participant_id"]] == s for r in active)
                                           for s in ["train", "dev", "test"]},
              "test_evaluated": False, "target_definition": config["target"],
              "status": "development_only_not_efficacy_validation"}
    write(out / "dev_results.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("D:/depression-lab/datasets/expansion-20260909/audio-research/mmpsy"))
    parser.add_argument("--out", type=Path, default=Path("D:/depression-lab/runtime/expansion-v1/mmpsy-baselines"))
    args = parser.parse_args()
    with threadpool_limits(limits=2):
        main(args.data, args.out)
