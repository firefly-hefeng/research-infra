"""Batched local weak evidence labels; input objects never contain scores."""
# ruff: noqa: E402
import argparse
import gc
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import torch
from transformers import AutoTokenizer, Qwen2_5_VLForConditionalGeneration
from depression_lab.compact_evidence import SYSTEM, VERSION, prompt, decode
from scripts.cache_mmpsy_v2 import sentences
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.run_unified_experiments import reserve


def main(limit=0):
    out = ROOT / 'compact-evidence'
    out.mkdir(exist_ok=True)
    config = {'version': VERSION, 'system': SYSTEM, 'model': 'local/Qwen2.5-VL-7B-Instruct',
              'human_verified': False, 'teacher_sees_labels': False, 'protocol_sha256': sha(ROOT / 'protocol.json')}
    cp = out / 'configuration.json'
    if cp.exists() and json.loads(cp.read_text(encoding='utf8')) != config:
        raise ValueError('Teacher changed; new version required')
    cp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf8')
    reserve_path = reserve(ROOT)
    try:
        torch.set_num_threads(4)
        path = 'D:/speech-cognition-4090/models/Qwen2.5-VL-7B-Instruct'
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, padding_side='left')
        model = Qwen2_5_VLForConditionalGeneration.from_pretrained(path, torch_dtype=torch.bfloat16,
            attn_implementation='sdpa', local_files_only=True).to('cuda').eval()
        for split in ['train', 'dev']:
            output = out / f'{split}.jsonl'
            done = {r['participant_id'] for r in map(json.loads, output.read_text(encoding='utf8').splitlines())} if output.exists() else set()
            rows = [json.loads(line) for line in (ROOT / f'{split}.inputs.jsonl').read_text(encoding='utf8').splitlines()]
            rows = [r for r in rows if r['participant_id'] not in done]
            if limit:
                rows = rows[:limit]
            # Sort batches by source length to avoid padding long sources together with tiny ones.
            rows.sort(key=lambda r: sum(len(t['text']) for t in r['turns']))
            for begin in range(0, len(rows), 6):
                batch = rows[begin:begin+6]
                sources = [sentences(r) for r in batch]
                chats = [tokenizer.apply_chat_template([{'role': 'system', 'content': SYSTEM},
                    {'role': 'user', 'content': prompt(s)}], tokenize=False, add_generation_prompt=True) for s in sources]
                enc = tokenizer(chats, return_tensors='pt', padding=True, truncation=False).to('cuda')
                if enc.input_ids.shape[1] > 11000:
                    raise ValueError('Source too long for batch; must group all segments explicitly')
                with torch.inference_mode():
                    generated = model.generate(**enc, max_new_tokens=850, do_sample=False, use_cache=True)
                outputs = tokenizer.batch_decode(generated[:, enc.input_ids.shape[1]:], skip_special_tokens=True)
                for row, source, answer in zip(batch, sources, outputs, strict=True):
                    turns = [{'id': t['turn_id'], 'text': t['text'], 'role': 'user'} for t in row['turns']]
                    try:
                        bundle = decode(answer, source, turns)
                        error = None
                    except (ValueError, TypeError, KeyError) as exc:
                        bundle, error = None, str(exc)
                    record = {'participant_id': row['participant_id'], 'split': split, 'evidence': bundle,
                              'raw': answer, 'error': error, 'input_only_sha256': __import__('hashlib').sha256(prompt(source).encode()).hexdigest()}
                    with output.open('a', encoding='utf8') as file:
                        file.write(json.dumps(record, ensure_ascii=False) + '\n')
                print(json.dumps({'split': split, 'done': begin+len(batch), 'total': len(rows),
                                  'seconds_gpu_model': 'local_only'}), flush=True)
                del enc, generated
        del model
        gc.collect()
        torch.cuda.empty_cache()
    finally:
        reserve_path.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--limit', type=int, default=0)
    main(parser.parse_args().limit)
