"""One-time locked participant evaluation; CPU environment matches baseline artifacts."""
# ruff: noqa: E402
import argparse
import json
import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from scipy.sparse import hstack, csr_matrix
from threadpoolctl import threadpool_limits
from depression_lab.mmpsy_scorer import MMPsyScorer
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, DATA, sha
from scripts.train_mmpsy_evidence_heads import metrics, write
from scripts.train_mmpsy_joint_selector import JointSelector, eligibility


def verify():
    lock = json.loads((ROOT / 'selection_lock.json').read_text(encoding='utf8'))
    for path, expected in lock['hashes'].items():
        if sha(path) != expected:
            raise ValueError('Frozen artifact/source changed: '+path)
    return lock


def records(split, student=False):
    folder = 'student-evidence' if student else 'entailment-evidence'
    return {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / folder / f'{split}.jsonl').read_text(encoding='utf8').splitlines())}


def prediction_rows(scorer, split):
    features = dict(np.load(ROOT / f'{split}.features.npz'))
    evidence = records(split)
    result = [scorer.predict(evidence[uid], acoustic) for uid, acoustic in zip(features['participant_ids'], features['mel'], strict=True)]
    return features, evidence, result


def main(dev_replay=False):
    torch.set_num_threads(2)
    scorer = MMPsyScorer(ROOT / 'release-candidate')
    if dev_replay:
        _, _, rows = prediction_rows(scorer, 'dev')
        actual = np.array([r['distribution'] for r in rows])
        expected = np.load(ROOT / 'audio-residual/audio-tilt-l2-1.0.dev.npy')
        maximum = float(np.abs(actual-expected).max())
        write(ROOT / 'release-candidate/dev_replay.json', {'max_distribution_difference': maximum, 'passed': maximum < 1e-5})
        if maximum >= 1e-5:
            raise ValueError('Portable scorer does not match development predictions')
        print(json.dumps({'development_replay_passed': True, 'max_distribution_difference': maximum}))
        return
    lock = verify()
    final = ROOT / 'final_results.json'
    if final.exists():
        print('Evaluation already completed; returning saved result without rereading predictions')
        return
    if not (ROOT / 'holdout_inference_complete.json').exists():
        raise ValueError('Holdout inference incomplete')
    # Independent labels are first consumed by this evaluation stage, after model inference.
    targets = {r['participant_id']: 100*r['phq9_raw']/27 for r in map(json.loads, (DATA / 'independent_targets.jsonl').read_text().splitlines())}
    selected = {}
    for split in ['calibration', 'test']:
        f, source, results = prediction_rows(scorer, split)
        y = np.array([targets[uid] for uid in f['participant_ids']])
        pred = np.array([r['score_0_100'] for r in results])
        selected[split] = {'features': f, 'source': source, 'rows': results, 'y': y, 'prediction': pred}
    cal = selected['calibration']
    residual = np.sort(np.abs(cal['prediction']-cal['y']))
    rank = min(len(residual), math.ceil((len(residual)+1)*.9))
    radius = float(residual[rank-1])
    calibration = {'method': 'split_conformal_absolute_residual', 'n': len(residual), 'coverage_target': .9,
                   'radius_0_100': radius, 'scorer_sha256': scorer.weights_sha256,
                   'population': scorer.manifest['interval_population'], 'free_chat_validated': False,
                   'distribution_mass_calibrated': False}
    write(ROOT / 'release-candidate/calibration.json', calibration)
    test = selected['test']
    f, source, y = test['features'], test['source'], test['y']
    ids = list(f['participant_ids'])
    x_evidence = np.stack([vector(source[uid])[0] for uid in ids])
    student = records('test', student=True)
    x_student = np.stack([vector(student[uid])[0] for uid in ids])
    strings = {r['participant_id']: '\n'.join(t['text'] for t in r['turns']) for r in map(json.loads, (ROOT / 'test.inputs.jsonl').read_text(encoding='utf8').splitlines())}
    text = [strings[uid] for uid in ids]
    predictions = {'selected': test['prediction']}
    for path in sorted((ROOT / 'controls').glob('*.joblib')):
        artifact = joblib.load(path)
        kind = artifact['kind']
        if kind == 'constant':
            pred = np.full(len(y), artifact['value'])
        else:
            mel = artifact['mel_scaler'].transform(f['mel'])/np.sqrt(160)
            semantic = artifact['mean_scaler'].transform(f['text_mean'])/np.sqrt(768)
            terms = artifact['vectorizer'].transform(text) if 'vectorizer' in artifact else None
            inputs = {'text': terms, 'audio': csr_matrix(mel), 'fusion': hstack([terms, mel]) if terms is not None else None,
                      'e5': semantic, 'e5_audio': hstack([semantic, mel]),
                      'text_e5': hstack([terms, semantic]) if terms is not None else None,
                      'text_e5_audio': hstack([terms, semantic, mel]) if terms is not None else None,
                      'e5_rbf': semantic, 'e5_audio_rbf': np.concatenate([semantic, mel], axis=1)}
            pred = artifact['regressor'].predict(inputs[kind])
        predictions['baseline_'+path.stem] = np.clip(pred, 0, 100)
    for path in sorted((ROOT / 'dense-control').glob('*.joblib')):
        a = joblib.load(path)
        x = np.concatenate([a['semantic_scaler'].transform(f['text_mean'])/np.sqrt(768),
                            x_evidence*a['evidence_weight'], a['audio_scaler'].transform(f['mel'])/np.sqrt(160)*a['audio_scale']], axis=1)
        predictions['dense_control_'+path.stem] = np.clip(a['regressor'].predict(x), 0, 100)
    for folder, evidence in [('evidence-heads', x_evidence), ('student-heads', x_student)]:
        scaler = joblib.load(ROOT / folder / 'audio_scaler.joblib')
        mel = scaler.transform(f['mel'])/np.sqrt(160)
        for path in sorted((ROOT / folder).glob('*.pt')):
            state = torch.load(path, weights_only=True)
            mode = state['mode']
            x = evidence[:, :153] if mode.startswith('symptoms') else evidence
            if 'audio' in mode:
                x = np.concatenate([x, mel], axis=1)
            head = nn.Sequential(nn.Linear(state['input_dim'], 128), nn.GELU(), nn.Linear(128, 101))
            head.load_state_dict(state['state_dict'])
            with torch.no_grad():
                predictions[folder+'_'+path.stem] = (head(torch.tensor(x, dtype=torch.float32)).softmax(-1)*torch.arange(101)).sum(-1).numpy()
    scales = joblib.load(ROOT / 'joint-selector/scalers.joblib')
    h = torch.tensor(scales['semantic'].transform(f['text_mean'])/np.sqrt(768), dtype=torch.float32)
    a = torch.tensor(scales['audio'].transform(f['mel'])*.1/np.sqrt(160), dtype=torch.float32)
    e = torch.tensor(x_evidence)
    masks = eligibility(e)
    for path in sorted((ROOT / 'joint-selector').glob('*.pt')):
        model = JointSelector()
        model.load_state_dict(torch.load(path, weights_only=True)['state_dict'])
        with torch.no_grad():
            p, _, _, _ = model(h, e, a, *masks)
            predictions['A_lite_'+path.stem] = (p*torch.arange(101)).sum(-1).numpy()
    grpo_scales = joblib.load(ROOT / 'selection-grpo/scalers.joblib')
    h = torch.tensor(grpo_scales['semantic'].transform(f['text_mean'])/np.sqrt(768), dtype=torch.float32)
    acoustic = torch.tensor(grpo_scales['audio'].transform(f['mel'])/np.sqrt(160), dtype=torch.float32)
    for branch in ['outcome', 'outcome_evidence']:
        model = JointSelector()
        model.selector.load_state_dict(torch.load(ROOT / 'selection-grpo' / f'{branch}.pt', weights_only=True)['state_dict'])
        with torch.no_grad():
            _, _, _, features = model(h, e, acoustic*.1, *masks)
            p = torch.stack([head(features).softmax(-1) for head in scorer.heads]).mean(0)
            p = (p.clamp_min(1e-8).log()+(acoustic@scorer.beta)[:, None]*(torch.arange(101)-50)/100).softmax(-1)
            predictions['GRPO_'+branch] = (p*torch.arange(101)).sum(-1).numpy()
    summary = {name: metrics(pred, y) for name, pred in predictions.items()}
    rng = np.random.default_rng(lock['bootstrap_seed'])
    samples = rng.integers(0, len(y), (lock['bootstrap_iterations'], len(y)))
    baseline = predictions['baseline_e5']
    comparisons = {}
    for name, pred in predictions.items():
        difference = np.abs(pred-y)-np.abs(baseline-y)
        values = difference[samples].mean(-1)
        comparisons[name] = {'mae_difference_vs_preselected_e5': float(difference.mean()),
                             'paired_bootstrap_95': np.quantile(values, [.025, .975]).tolist()}
    criterion = comparisons['selected']['paired_bootstrap_95'][1] < 0 and summary['selected']['mae'] < summary['baseline_e5']['mae']
    evidence_gate = [sum(s[0] != 0 for s in r['slots']) >= 3 and not r['conflicts'] for r in test['rows']]
    interval_coverage = float((np.abs(test['prediction']-y) <= radius).mean())
    result = {'dataset': 'MMPsy', 'score_definition': scorer.manifest['score_definition'], 'n': len(y),
              'metrics': summary, 'comparisons': comparisons, 'research_prediction_criterion_passed': bool(criterion),
              'preselected_strongest_simple_baseline': 'E5 frozen semantic encoder + Ridge',
              'calibration': {**calibration, 'test_empirical_coverage': interval_coverage},
              'evidence_only_gate_coverage': float(np.mean(evidence_gate)),
              'public_report_coverage': 0., 'public_report_coverage_reason': 'no original MMPsy waveforms released; only feature-input research predictions',
              'free_chat_validated': False, 'clinical_validated': False,
              'test_was_not_used_for_selection': True, 'old_EATD_test_reused': False}
    write(ROOT / 'test_predictions.json', {'participant_ids': ids, 'targets_0_100': y.tolist(),
                                          'predictions': {k: v.tolist() for k, v in predictions.items()},
                                          'selected_distributions': [r['distribution'] for r in test['rows']],
                                          'evidence_only_gate': evidence_gate})
    status = {'prediction_criterion': 'passed' if criterion else 'failed', 'scorer_sha256': scorer.weights_sha256,
              'population': 'MMPsy participant holdout; feature input', 'test_n': len(y), 'calibration_n': len(residual),
              'report_coverage': 0., 'evidence_only_gate_coverage': float(np.mean(evidence_gate)),
              'clinical_validated': False, 'free_chat_validated': False}
    write(ROOT / 'release-candidate/research_validation.json', status)
    write(final, result)
    print(json.dumps({'selected': summary['selected'], 'baseline': summary['baseline_e5'],
                      'comparison': comparisons['selected'], 'criterion_passed': bool(criterion), 'n': len(y)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dev-replay', action='store_true')
    with threadpool_limits(2):
        main(parser.parse_args().dev_replay)
