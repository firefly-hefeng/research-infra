"""Frozen E5 sentence representations and deterministic source mel measurements."""
# ruff: noqa: E402
import json
import os
import re
import sys
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer
from scripts.prepare_mmpsy_v2 import ROOT, DATA, sha
from scripts.train_mmpsy_baselines import pooled_mel
from scripts.run_unified_experiments import reserve


def sentences(row):
    output = []
    for turn in row['turns']:
        # Character offsets bind every segment back to its exact original turn.
        for match in re.finditer(r'[^。！？\n]+[。！？\n]?', turn['text']):
            for offset in range(0, len(match[0]), 160):
                text = match[0][offset:offset + 160]
                if text.strip():
                    output.append({'turn_id': turn['turn_id'], 'start': match.start() + offset,
                                   'end': match.start() + offset + len(text), 'text': text})
    return output


def main():
    reservation = reserve(ROOT)
    try:
        torch.set_num_threads(4)
        path = 'D:/speech-cognition-4090/models/multilingual-e5-base'
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
        model = AutoModel.from_pretrained(path, local_files_only=True).to('cuda').eval()
        for split in ['train', 'dev']:
            output = ROOT / f'{split}.features.npz'
            if output.exists():
                continue
            rows = [json.loads(line) for line in (ROOT / f'{split}.inputs.jsonl').read_text(encoding='utf8').splitlines()]
            segments, owners, bounds = [], [], [0]
            for i, row in enumerate(rows):
                chunks = sentences(row)
                segments.extend(chunks)
                owners.extend([i] * len(chunks))
                bounds.append(len(segments))
            vectors = []
            for offset in range(0, len(segments), 48):
                text = ['passage: ' + s['text'] for s in segments[offset:offset + 48]]
                encoded = tokenizer(text, padding=True, truncation=False, return_tensors='pt').to('cuda')
                if encoded.input_ids.shape[1] > 512:
                    raise ValueError('Segment exceeds encoder limit; no silent truncation allowed')
                with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
                    hidden = model(**encoded).last_hidden_state.float()
                    mask = encoded.attention_mask.unsqueeze(-1)
                    pooled = (hidden * mask).sum(1) / mask.sum(1)
                    vectors.append(torch.nn.functional.normalize(pooled, dim=1).cpu().numpy())
                if offset % 960 == 0:
                    print(json.dumps({'stage': 'e5', 'split': split, 'done': offset, 'total': len(segments)}), flush=True)
            vectors = np.concatenate(vectors)
            means = np.stack([vectors[bounds[i]:bounds[i+1]].mean(0) for i in range(len(rows))])
            deviations = np.stack([vectors[bounds[i]:bounds[i+1]].std(0) for i in range(len(rows))])
            audio = np.stack([pooled_mel(DATA / 'np_data' / r['participant_id'] / 'mel-spectrogram') for r in rows])
            np.savez_compressed(output, participant_ids=[r['participant_id'] for r in rows],
                                segment_vectors=vectors, segment_owners=owners, bounds=bounds,
                                text_mean=means, text_std=deviations, mel=audio)
            (ROOT / f'{split}.segments.json').write_text(json.dumps(segments, ensure_ascii=False), encoding='utf8')
            print(json.dumps({'stage': 'saved', 'split': split, 'people': len(rows), 'sha256': sha(output)}), flush=True)
    finally:
        reservation.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
