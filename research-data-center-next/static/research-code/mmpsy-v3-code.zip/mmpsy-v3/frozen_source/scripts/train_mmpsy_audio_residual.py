"""Freeze semantic evidence ensemble, learn a regularized acoustic distribution tilt."""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.train_mmpsy_evidence_heads import write, metrics


def main():
    out = ROOT / 'audio-residual'
    out.mkdir(exist_ok=True)
    config = {'head': 'frozen three-seed semantic evidence distribution, exponential acoustic tilt over 101 bins',
              'l2': [.001, .01, .1, 1.], 'lr': .01, 'epochs': 300, 'patience': 30,
              'audio_input': '160 source measured normalized mel moments; no latent features',
              'test_access': False, 'protocol_sha256': sha(ROOT / 'protocol.json'),
              'development_selection': 'include zero-tilt reference, report whether learned audio improves it'}
    write(out / 'configuration.json', config)
    torch.set_num_threads(2)
    base, audio, y = {}, {}, {}
    heads = []
    for seed in [20260909, 20260910, 20260911]:
        state = torch.load(ROOT / 'evidence-heads' / f'evidence-{seed}.pt', weights_only=True)
        model = nn.Sequential(nn.Linear(177, 128), nn.GELU(), nn.Linear(128, 101))
        model.load_state_dict(state['state_dict'])
        model.eval()
        heads.append(model)
    for s in ['train', 'dev']:
        f = dict(np.load(ROOT / f'{s}.features.npz'))
        records = {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / 'entailment-evidence' / f'{s}.jsonl').read_text(encoding='utf8').splitlines())}
        e = torch.tensor(np.stack([vector(records[uid])[0] for uid in f['participant_ids']]))
        with torch.no_grad():
            base[s] = torch.stack([model(e).softmax(-1) for model in heads]).mean(0)
        audio[s] = f['mel']
        targets = json.loads((ROOT / f'{s}.targets.json').read_text())
        y[s] = torch.tensor([targets[uid] for uid in f['participant_ids']])
    scaler = StandardScaler().fit(audio['train'])
    joblib.dump(scaler, out / 'audio_scaler.joblib')
    audio = {s: torch.tensor(scaler.transform(x)/np.sqrt(160), dtype=torch.float32) for s, x in audio.items()}
    grid = torch.arange(101)
    low, high = y['train'].floor().long(), y['train'].ceil().long()
    weight = y['train'] - low
    cdf = (nn.functional.one_hot(low, 101)*(1-weight[:, None]) + nn.functional.one_hot(high, 101)*weight[:, None]).cumsum(-1)
    reference = metrics((base['dev']*grid).sum(-1).numpy(), y['dev'].numpy())
    results = [{'name': 'zero_audio', **reference}]
    print(json.dumps(results[0]), flush=True)
    for l2 in config['l2']:
        beta = nn.Parameter(torch.zeros(160))
        opt = torch.optim.Adam([beta], lr=config['lr'])
        best, stale, best_beta, best_p = reference['mae'], 0, beta.detach().clone(), base['dev'].numpy()
        best_metrics = reference
        history = []
        for epoch in range(config['epochs']):
            delta = audio['train'] @ beta
            p = (base['train'].clamp_min(1e-8).log() + delta[:, None]*(grid-50)/100).softmax(-1)
            score = (p*grid).sum(-1)
            loss = (p.cumsum(-1)-cdf).square().mean() + .5*((score-y['train'])/100).square().mean() + l2*beta.square().mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
            with torch.no_grad():
                delta = audio['dev'] @ beta
                p = (base['dev'].clamp_min(1e-8).log() + delta[:, None]*(grid-50)/100).softmax(-1)
                pred = (p*grid).sum(-1).numpy()
            evaluation = metrics(pred, y['dev'].numpy())
            history.append({'epoch': epoch+1, **evaluation})
            if evaluation['mae'] < best-1e-6:
                best, stale, best_beta, best_p, best_metrics = evaluation['mae'], 0, beta.detach().clone(), p.numpy(), evaluation
            else:
                stale += 1
            if stale >= config['patience']:
                break
        name = f'audio-tilt-l2-{l2}'
        torch.save({'family': 'evidence-ensemble-audio-tilt', 'beta': best_beta,
                    'heads': [model.state_dict() for model in heads], 'score_definition': 'mmpsy-phq-severity-index-v2'}, out / f'{name}.pt')
        np.save(out / f'{name}.dev.npy', best_p)
        write(out / f'{name}.history.json', history)
        result = {'name': name, 'epochs': len(history), 'nonzero_audio_weights': int(torch.count_nonzero(best_beta)),
                  'dev_mae_change_from_semantic_ensemble': best_metrics['mae']-reference['mae'], **best_metrics}
        print(json.dumps(result), flush=True)
        results.append(result)
    write(out / 'results.json', results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
