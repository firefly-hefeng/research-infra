"""Freeze a larger, independent severity experiment without touching old EATD tests."""
import hashlib
import json
from pathlib import Path

ROOT = Path('D:/depression-lab/runtime/mmpsy-v2')
DATA = Path('D:/depression-lab/datasets/expansion-20260909/audio-research/mmpsy')
BASE = Path('D:/depression-lab/runtime/expansion-v1/mmpsy-baselines')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare():
    ROOT.mkdir(parents=True, exist_ok=True)
    original = json.loads((BASE / 'participant_splits.json').read_text())
    excluded = {'user_632', 'user_1264'}
    train = [uid for uid, split in original.items() if split == 'train' and uid not in excluded]
    calibration = set(sorted(train, key=lambda uid: hashlib.sha256(('mmpsy-v2-cal:' + uid).encode()).hexdigest())[:100])
    splits = {uid: 'excluded' if uid in excluded else 'calibration' if uid in calibration else split
              for uid, split in original.items()}
    config = {
        'version': 'mmpsy-v2', 'score_definition': 'mmpsy-phq-severity-index-v2',
        'target': '100 * independent PHQ9 raw / 27; severity index, not probability; incompatible with SDS v1',
        'input_sha256': sha(DATA / 'semantic_inputs.label_blind.jsonl'),
        'target_sha256': sha(DATA / 'independent_targets.jsonl'),
        'previous_split_sha256': sha(BASE / 'participant_splits.json'),
        'splits': splits, 'counts': {s: list(splits.values()).count(s) for s in set(splits.values())},
        'calibration_selection': '100 lowest SHA256 mmpsy-v2-cal:uid among previous training participants; labels unused',
        'old_eatd_test': 'sealed; never used for this version training or selection',
        'test_policy': '101 original MMPsy heldout participants; no test inference before selection lock',
        'calibration_policy': 'not used in v2 fitting or model selection; earlier pilot baseline saw these participants',
        'comparison': 'refit simple baselines on the same 940 training participants; select strongest on dev',
        'acceptance': 'all-participant MAE lower than preselected strongest simple baseline and paired bootstrap 95% difference upper < 0',
        'audio': 'author normalized mel features; no raw audio in MMPsy release; live waveform frontend must reproduce source recipe',
        'seeds': [20260909, 20260910, 20260911],
        'research_only': True, 'clinical_validated': False,
    }
    dest = ROOT / 'protocol.json'
    if dest.exists() and json.loads(dest.read_text(encoding='utf8')) != config:
        raise ValueError('Protocol already frozen; create a new version')
    dest.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf8')
    # Export model inputs separately. A future holdout command must explicitly unlock.
    rows = [json.loads(line) for line in (DATA / 'semantic_inputs.label_blind.jsonl').read_text(encoding='utf8').splitlines()]
    targets = {r['participant_id']: r['phq9_raw'] for r in map(json.loads, (DATA / 'independent_targets.jsonl').read_text().splitlines())}
    for split in ['train', 'dev']:
        selected = [r for r in rows if splits[r['participant_id']] == split]
        (ROOT / f'{split}.inputs.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in selected), encoding='utf8')
        (ROOT / f'{split}.targets.json').write_text(json.dumps({r['participant_id']: targets[r['participant_id']] * 100 / 27 for r in selected}), encoding='utf8')
    print(json.dumps({'counts': config['counts'], 'protocol': str(dest), 'test_exported': False}))


if __name__ == '__main__':
    prepare()
