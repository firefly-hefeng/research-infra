"""Synthetic numerical parity against Transformers' independent Slaney/STFT implementation."""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.signal.windows import hann
from transformers.audio_utils import mel_filter_bank, spectrogram
from depression_lab.mmpsy_audio import normalized_mel, mel_bank

t = np.arange(16000*4)/16000
wave = .17*np.sin(2*np.pi*173*t) + .06*np.sin(2*np.pi*719*t) + np.random.default_rng(17).normal(0, .001, len(t))
bank = mel_filter_bank(1025, 80, 0, 8000, 16000, norm='slaney', mel_scale='slaney')
reference = spectrogram(wave*32768, hann(2048, sym=False), 2048, 533, power=2., center=True,
                        pad_mode='constant', mel_filters=bank, log_mel='dB', db_range=80, dtype=np.float64)
reference = (reference-reference.mean())/reference.std()
actual = normalized_mel(wave)
result = {'synthetic': True, 'clinical_validation': False,
          'bank_max_absolute_difference': float(np.max(np.abs(mel_bank()[0].T-bank))),
          'normalized_mel_max_absolute_difference': float(np.max(np.abs(reference-actual))),
          'author_unreleased_raw_parity_verified': False}
assert result['bank_max_absolute_difference'] < 1e-8
assert result['normalized_mel_max_absolute_difference'] < 1e-5
Path('D:/depression-lab/runtime/mmpsy-v2/audio_frontend_check.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
