"""Omni LoRA evidence-decision + short structured-rationale SFT (no severity labels)."""
# ruff: noqa: E402
import argparse
import json
import os
import random
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import torch
from depression_lab.evidence_entailment import SYSTEM, prompt
from depression_lab.unified_model import OmniEncoder
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.cache_mmpsy_v2 import sentences
from scripts.run_unified_experiments import reserve

OUT = ROOT / 'reasoner-sft'
KINDS = {'A': 'insufficient', 'B': 'support', 'C': 'denial', 'D': 'historical', 'E': 'other_subject', 'F': 'conflict'}
REASONS = {
    'A': '原话不足以确定这个概念，未提到不等于否认。',
    'B': '原话支持本人所述情况，频率、持续时间和功能影响需要分别核对。',
    'C': '原话明确否认本人所述情况，否认与没有信息分别记录。',
    'D': '原话指向本人过去的经历，不能直接作为现在的状态。',
    'E': '原话涉及其他主体，不能作为说话者本人的当前症状。',
    'F': '原话同时含支持和否认，需要澄清后再确定状态。',
}


def training_prompt(text, concept):
    return SYSTEM + '\n' + prompt(text, concept) + '\n先输出一个判断字母；换行后输出JSON，包含concept、relation、source_quote、reason，不输出分数。'


def target(row):
    return row['action'] + '\n' + json.dumps({'concept': row['concept'], 'relation': KINDS[row['action']],
        'source_quote': row['text'], 'reason': REASONS[row['action']]}, ensure_ascii=False, separators=(',', ':'))


def make_data():
    phrases = {
        'interest': [('什么事都提不起兴趣', '以前喜欢的事情仍然让我有乐趣'), ('对喜欢的活动失去了兴趣', '做喜欢的事情仍然觉得有意思'), ('干什么都觉得没意思', '兴趣没有减少')],
        'mood': [('心情很低落', '没有低落的感觉'), ('总是觉得难过', '并不难过'), ('感到沮丧', '最近心情很好')],
        'sleep': [('晚上很难入睡', '晚上睡得很踏实'), ('总是半夜醒来睡不回去', '没有睡不着的情况'), ('早醒后无法再睡', '没有睡眠问题')],
        'energy': [('一直很疲惫', '精力很充沛'), ('没有精神和力气', '没有疲倦感'), ('每天无精打采', '精力没有减少')],
        'appetite': [('吃不下东西', '胃口没有变化'), ('食欲明显减退', '吃饭一直很正常'), ('食量比以前多了很多', '食欲没有异常')],
        'self_worth': [('觉得自己一无是处', '不觉得自己没有价值'), ('反复责怪自己', '没有责怪自己'), ('总觉得自己是失败者', '不认为自己很失败')],
        'concentration': [('很难集中注意力', '能够保持注意力集中'), ('看书总是走神', '看书时不走神'), ('做事经常分心', '做事时没有分心')],
        'psychomotor': [('动作明显变慢，别人也看出来了', '动作速度没有异常'), ('明显坐立不安', '没有坐立不安'), ('说话慢了很多，朋友也注意到了', '说话速度没有变化')],
        'self_harm': [('出现不想活下去的念头', '没有不想活的想法'), ('想到伤害自己', '从未想过伤害自己'), ('想到结束自己的生命', '没有结束生命的想法')],
    }
    rows = []
    for c, pairs in phrases.items():
        for i, (positive, negative) in enumerate(pairs):
            for modifier in ['这段时间', '最近几天', '目前']:
                cases = [
                    ('B', f'{modifier}我{positive}。'), ('C', f'{modifier}我{negative}。'),
                    ('D', f'小时候我{positive}，那已经是过去的事情了。'),
                    ('E', f'{modifier}我的同事{positive}。我在转述他的经历。'),
                    ('F', f'{modifier}我{positive}，但我又觉得我{negative}，我自己也说不清。'),
                    ('A', '没有吧，我不知道你在问什么。' if i < 2 else '我不明白你指的是哪一种情况。'),
                ]
                for action, text in cases:
                    rows.append({'id': f'synthetic-{c}-{i}-{modifier}-{action}', 'concept': c, 'text': text,
                                 'action': action, 'synthetic': True, 'use': 'evidence_semantics_only_no_severity',
                                 'split': 'probe' if i == 2 else 'train'})
    # Context examples supply explicit positive/negative observations rather than clinical labels.
    for c, (positive, negative) in {
        'positive_affect': ('我最近很开心', '我最近不开心'), 'worry': ('我很担心未来', '我并不担心'),
        'academic_pressure': ('我为学业感到压力', '学习没给我压力'), 'interpersonal_conflict': ('我和同学闹矛盾', '我与同学没有矛盾'),
        'loneliness': ('我觉得很孤独', '我一点也不孤独'), 'family_conflict': ('我和父母常吵架', '我与家人相处融洽'),
        'social_support': ('家人一直支持我', '我没有得到别人的支持'), 'coping_activity': ('我常用跑步放松', '我没有通过活动放松'),
        'rumination': ('我反复回想已经发生的事', '我不再纠结已经发生的事'), 'optimism': ('我对未来很乐观', '我并不乐观'),
        'functional_impairment': ('我的情绪影响了学习', '情绪没有影响我的生活'), 'stress_overwhelm': ('我感到压力无法承受', '目前压力我能应对'),
    }.items():
        for j, prefix in enumerate(['最近', '现在', '这几天']):
            for action, text in [('B', prefix+positive), ('C', prefix+negative), ('A', '希望别人能' + positive.replace('我', ''))]:
                rows.append({'id': f'context-{c}-{j}-{action}', 'concept': c, 'text': text, 'action': action,
                             'synthetic': True, 'use': 'context_semantics_only_no_severity', 'split': 'train'})
    inputs = {r['participant_id']: r for r in map(json.loads, (ROOT / 'train.inputs.jsonl').read_text(encoding='utf8').splitlines())}
    buckets = {a: [] for a in 'ABCDEF'}
    for row in map(json.loads, (ROOT / 'entailment-evidence/train.jsonl').read_text(encoding='utf8').splitlines()):
        source = sentences(inputs[row['participant_id']])
        for sid, c, action in row['actions']:
            buckets[action].append({'id': f"{row['participant_id']}-{sid}-{c}", 'participant_id': row['participant_id'],
                'concept': c, 'text': source[sid]['text'], 'action': action, 'synthetic': False,
                'use': 'label_blind_weak_teacher_action', 'split': 'train'})
    rng = random.Random(20260909)
    for group in buckets.values():
        rng.shuffle(group)
        rows.extend(group[:160])
    unique = {}
    for row in rows:
        key = (row['concept'], row['text'])
        if key in unique and unique[key]['split'] != row['split']:
            raise ValueError('Synthetic phrase leakage between training and probe')
        unique.setdefault(key, row)
    return list(unique.values())


def finite_prediction(encoder, row):
    tokenizer = encoder.processor.tokenizer
    batch, _ = encoder.batch(training_prompt(row['text'], row['concept']))
    lm = encoder.model.base_model.model.lm_head
    handle = lm.register_forward_pre_hook(lambda module, inputs: (inputs[0][:, -1:, :],))
    try:
        with torch.no_grad():
            encoder.model.base_model.model.rope_deltas = None
            out = encoder.model(**batch, use_cache=False)
            token_ids = [tokenizer.encode(c, add_special_tokens=False)[0] for c in 'ABCDEF']
            logits = out.logits[0, -1, token_ids]
            return 'ABCDEF'[int(logits.argmax())]
    finally:
        handle.remove()


def main(epochs):
    OUT.mkdir(exist_ok=True)
    data = make_data()
    (OUT / 'training_data.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in data), encoding='utf8')
    config = {'base': 'Qwen2.5-Omni-3B', 'initial_adapter': 'reasoning/sft-v2/adapter_emotion',
              'lora_rank': 8, 'lora_lr': 2e-5, 'epochs': epochs, 'accumulation': 4,
              'loss': 'first decision token CE + 0.1 structured rationale CE',
              'train_count': sum(r['split'] == 'train' for r in data), 'probe_count': sum(r['split'] == 'probe' for r in data),
              'has_severity_labels': False, 'raw_audio_training_in_this_stage': False,
              'protocol_sha256': sha(ROOT / 'protocol.json'), 'explanation_target': 'weak structural rationale, not clinician expert reasoning'}
    (OUT / 'configuration.json').write_text(json.dumps(config, indent=2), encoding='utf8')
    reservation = reserve(ROOT)
    try:
        torch.manual_seed(20260909)
        encoder = OmniEncoder('D:/depression-lab/models/Qwen2.5-Omni-3B', 'D:/depression-lab/runtime/reasoning/sft-v2/adapter_emotion')
        train = [r for r in data if r['split'] == 'train']
        probes = [r for r in data if r['split'] == 'probe']
        encoder.model.eval()
        pre = [finite_prediction(encoder, r) for r in probes]
        (OUT / 'before.json').write_text(json.dumps({'correct': sum(a == r['action'] for a, r in zip(pre, probes, strict=True)),
                                                 'total': len(probes), 'predictions': pre}))
        opt = torch.optim.AdamW([p for p in encoder.model.parameters() if p.requires_grad], lr=config['lora_lr'])
        best = -1
        step = 0
        for epoch in range(epochs):
            random.Random(20260909+epoch).shuffle(train)
            encoder.model.train()
            opt.zero_grad()
            for i, row in enumerate(train):
                batch, prefix = encoder.batch(training_prompt(row['text'], row['concept']), completion=target(row))
                labels = batch.pop('labels')[:, prefix:]
                # Project only completion positions; the supervised prefix has zero loss.
                handle = encoder.model.base_model.model.lm_head.register_forward_pre_hook(
                    lambda module, inputs, n=prefix: (inputs[0][:, n-1:-1, :],))
                try:
                    encoder.model.base_model.model.rope_deltas = None
                    output = encoder.model(**batch, use_cache=False)
                    logits = output.logits.float()
                    first = torch.nn.functional.cross_entropy(logits[:, 0], labels[:, 0])
                    rationale = torch.nn.functional.cross_entropy(logits[:, 1:].reshape(-1, logits.shape[-1]), labels[:, 1:].reshape(-1))
                    loss = first + .1*rationale
                    group = min(4, len(train) - (i//4)*4)
                    (loss/group).backward()
                finally:
                    handle.remove()
                if (i+1) % 4 == 0 or i+1 == len(train):
                    torch.nn.utils.clip_grad_norm_([p for p in encoder.model.parameters() if p.requires_grad], 1)
                    opt.step()
                    opt.zero_grad()
                    step += 1
                    if step % 20 == 0:
                        print(json.dumps({'epoch': epoch+1, 'step': step, 'loss': float(loss.detach()), 'rows_done': i+1, 'rows': len(train)}), flush=True)
                del output, logits, batch, labels, loss, first, rationale
            encoder.model.eval()
            predictions = [finite_prediction(encoder, r) for r in probes]
            correct = sum(a == r['action'] for a, r in zip(predictions, probes, strict=True))
            result = {'epoch': epoch+1, 'synthetic_probe_correct': correct, 'total': len(probes), 'predictions': predictions}
            (OUT / f'epoch-{epoch+1}.json').write_text(json.dumps(result))
            print(json.dumps(result), flush=True)
            if correct > best:
                best = correct
                encoder.save(OUT)
                (OUT / 'best.json').write_text(json.dumps(result))
        (OUT / 'complete.json').write_text(json.dumps({'updates': step, 'epochs': epochs, 'best_synthetic_correct': best, 'total': len(probes)}))
    finally:
        reservation.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--epochs', type=int, default=2)
    main(parser.parse_args().epochs)
