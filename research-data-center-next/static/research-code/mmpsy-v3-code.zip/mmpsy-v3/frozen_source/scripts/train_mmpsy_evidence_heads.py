"""Actual predicted evidence -> learned severity; distribution and continuous controls."""
# ruff: noqa: E402
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from scipy.stats import spearmanr
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector, vector_with_counts
from scripts.prepare_mmpsy_v2 import ROOT, sha


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def metrics(pred, y):
    return {'mae': float(np.abs(pred-y).mean()), 'rmse': float(np.square(pred-y).mean() ** .5),
            'rho': float(spearmanr(pred, y).statistic) if np.ptp(pred) > 1e-8 else None,
            'prediction_std': float(pred.std())}


def main(acoustic_regularization=False, source_counts=False, annotation='entailment-evidence', output=None):
    torch.set_num_threads(2)
    out = ROOT / (output or ('evidence-counts' if source_counts else 'evidence-audio-regularized' if acoustic_regularization else 'evidence-heads'))
    out.mkdir(exist_ok=True)
    config = {'version': 'mmpsy-phq-severity-index-v2', 'seeds': [20260909, 20260910, 20260911],
              'architecture': 'Linear(input,128), GELU, Linear(128,101), softmax; expected score',
              'max_epochs': 100, 'patience': 10, 'batch': 32, 'lr': .001,
              'loss': 'mean RPS + 0.5 normalized MSE',
              'input': 'actual frozen 7B predicted discrete source evidence + optional measured 160 mel moments',
              'protocol_sha256': sha(ROOT / 'protocol.json'), 'test_access': False,
              'context_concepts': '12 explicitly nonclinical circumstances in addition to 9 symptoms',
              'note': 'larger-data head experiment; settings differ from original tiny EATD run and are versioned'}
    if acoustic_regularization:
        config.update(audio_scales=[.03, .1, .3], audio_input_dropout=.5,
                      reason='Development evidence of noise from unconstrained audio; fixed shrinkage comparison')
    config['source_counts'] = source_counts
    config['annotation'] = annotation
    write(out / 'configuration.json', config)
    evidence, acoustics, y, ids, cover = {}, {}, {}, {}, {}
    for split in ['train', 'dev']:
        features = dict(np.load(ROOT / f'{split}.features.npz'))
        ids[split] = list(features['participant_ids'])
        records = {r['participant_id']: r for r in map(json.loads, (ROOT / annotation / f'{split}.jsonl').read_text(encoding='utf8').splitlines())}
        if set(records) != set(ids[split]):
            raise ValueError('Missing, extra or duplicate evidence participants')
        parsed = [(vector_with_counts if source_counts else vector)(records[uid]['evidence']) for uid in ids[split]]
        evidence[split] = np.stack([row[0] for row in parsed])
        acoustics[split] = features['mel']
        targets = json.loads((ROOT / f'{split}.targets.json').read_text())
        y[split] = np.array([targets[uid] for uid in ids[split]], dtype=np.float32)
        cover[split] = {'known_concepts_mean': float(np.mean([sum(v[0] != 0 for v in row[1]) for row in parsed])),
                        'evidence_gate_coverage': float(np.mean([sum(v[0] != 0 for v in row[1]) >= 3 and not row[2] for row in parsed]))}
    write(out / 'coverage.json', cover)
    scaler = StandardScaler().fit(acoustics['train'])
    audio = {s: scaler.transform(v) / np.sqrt(160) for s, v in acoustics.items()}
    modes = {
        'symptoms': {s: x[:, :153] for s, x in evidence.items()},
        'symptoms_audio': {s: np.concatenate([evidence[s][:, :153], audio[s]], axis=1) for s in evidence},
        'evidence': evidence,
        'evidence_audio': {s: np.concatenate([evidence[s], audio[s]], axis=1) for s in evidence},
    }
    if acoustic_regularization:
        modes = {f'evidence_audio_scale_{scale}': {s: np.concatenate([evidence[s], audio[s] * scale], axis=1)
                  for s in evidence} for scale in config['audio_scales']}
    if source_counts:
        modes = {'evidence_counts': evidence, **{f'evidence_counts_audio_scale_{scale}': {
            s: np.concatenate([evidence[s], audio[s] * scale], axis=1) for s in evidence} for scale in [.1, 1.]}}
    results = []
    grid = torch.arange(101)
    ytrain = torch.tensor(y['train'])
    low = ytrain.floor().long()
    high = ytrain.ceil().long()
    weight = ytrain - low
    target = torch.nn.functional.one_hot(low, 101) * (1 - weight[:, None]) + torch.nn.functional.one_hot(high, 101) * weight[:, None]
    target_cdf = target.cumsum(-1)
    prior = (target.sum(0) + .1) / (len(target) + 10.1)
    for mode, x in modes.items():
        trials = []
        for alpha in [.1, 1, 10, 100, 1000]:
            model = Ridge(alpha=alpha, solver='lsqr').fit(x['train'], y['train'])
            pred = np.clip(model.predict(x['dev']), 0, 100)
            trials.append((float(np.abs(pred-y['dev']).mean()), alpha, model, pred))
        _, alpha, regressor, pred = min(trials, key=lambda t: t[0])
        result = {'name': mode + '_ridge', 'alpha': alpha, **metrics(pred, y['dev'])}
        results.append(result)
        joblib.dump({'mode': mode, 'regressor': regressor, 'audio_scaler': scaler}, out / (result['name'] + '.joblib'))
        print(json.dumps(result), flush=True)
        xt = torch.tensor(x['train'], dtype=torch.float32)
        xv = torch.tensor(x['dev'], dtype=torch.float32)
        for seed in config['seeds']:
            torch.manual_seed(seed)
            model = nn.Sequential(nn.Linear(xt.shape[1], 128), nn.GELU(), nn.Linear(128, 101))
            with torch.no_grad():
                model[-1].bias.copy_(prior.log())
                model[-1].weight.mul_(.1)
            opt = torch.optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=.01)
            best, stale, history = float('inf'), 0, []
            for epoch in range(config['max_epochs']):
                model.train()
                for batch in torch.randperm(len(xt)).split(config['batch']):
                    xb = xt[batch].clone()
                    if acoustic_regularization:
                        keep = (torch.rand((len(batch), 1)) > config['audio_input_dropout']).float()
                        xb[:, -160:] *= keep
                    p = model(xb).softmax(-1)
                    loss = (p.cumsum(-1) - target_cdf[batch]).square().mean() + .5 * (((p * grid).sum(-1) - ytrain[batch]) / 100).square().mean()
                    opt.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), 1)
                    opt.step()
                model.eval()
                with torch.no_grad():
                    probabilities = model(xv).softmax(-1)
                    pred = (probabilities * grid).sum(-1).numpy()
                evaluation = metrics(pred, y['dev'])
                history.append({'epoch': epoch+1, **evaluation})
                if evaluation['mae'] < best - 1e-5:
                    best, stale = evaluation['mae'], 0
                    best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
                    best_pred = probabilities.numpy().copy()
                    best_evaluation = evaluation
                else:
                    stale += 1
                if stale >= config['patience']:
                    break
            name = f'{mode}-{seed}'
            torch.save({'state_dict': best_state, 'mode': mode, 'input_dim': xt.shape[1],
                        'audio_scale': float(mode.split('_')[-1]) if 'scale_' in mode else 1.,
                        'source_counts': source_counts,
                        'seed': seed, 'score_definition': config['version']}, out / f'{name}.pt')
            joblib.dump(scaler, out / 'audio_scaler.joblib')
            write(out / f'{name}.history.json', history)
            np.save(out / f'{name}.dev.npy', best_pred)
            result = {'name': name, 'seed': seed, 'epochs': len(history), **best_evaluation}
            results.append(result)
            print(json.dumps(result), flush=True)
        write(out / 'results.json', results)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--acoustic-regularization', action='store_true')
    parser.add_argument('--source-counts', action='store_true')
    parser.add_argument('--annotation', default='entailment-evidence')
    parser.add_argument('--output')
    args = parser.parse_args()
    with threadpool_limits(2):
        main(args.acoustic_regularization, args.source_counts, args.annotation, args.output)
