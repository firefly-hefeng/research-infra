"""Local finite-choice evidence extractor, teacher label-blind, no JSON generation."""
# ruff: noqa: E402
import argparse
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import torch
from transformers import AutoTokenizer, Qwen2_5_VLForConditionalGeneration
from depression_lab.evidence_entailment import SYSTEM, VERSION, candidates, bundle_from_actions
from scripts.cache_mmpsy_v2 import sentences
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.run_unified_experiments import reserve
from depression_lab.finite_evidence_policy import FiniteEvidencePolicy

PROBES = [
    ('sleep', '这两周没有睡眠问题，能一觉睡到早上。', 'C'),
    ('sleep', '那是我读初中时候的事情，已经过去十年了，我当时总是睡不着。', 'D'),
    ('mood', '我室友这几天非常难过，我自己没什么异常。', 'C'),
    ('sleep', '我同事向我抱怨睡不着，我在转述他的经历。', 'E'),
    ('energy', '周末爬完山会累，休息一晚就恢复了。', 'A'),
    ('mood', '这段时间高兴不起来，说不上来多久一次。', 'B'),
    ('mood', '没有啊。', 'A'),
    ('sleep', '最近睡不着，但我也没有失眠，具体我说不清。', 'F'),
    ('positive_affect', '要是以后能开心一点就好了。', 'A'),
    ('positive_affect', '这几天心情很好，我挺开心。', 'B'),
    ('mood', '我不是不难过，只是不想让人看出来。', 'B'),
    ('mood', '心里很难过，不过我想努力好起来。', 'B'),
]


def main(mode, limit):
    out = ROOT / 'entailment-evidence'
    out.mkdir(exist_ok=True)
    config = {'version': VERSION, 'system': SYSTEM, 'model': 'local/Qwen2.5-VL-7B-Instruct',
              'decode': 'highest conditional probability among six single-token letters',
              'human_verified': False, 'teacher_sees_labels': False, 'protocol_sha256': sha(ROOT / 'protocol.json')}
    cp = out / 'configuration.json'
    if cp.exists() and json.loads(cp.read_text(encoding='utf8')) != config:
        raise ValueError('Frozen annotation protocol changed')
    cp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf8')
    reservation = reserve(ROOT)
    try:
        torch.set_num_threads(4)
        path = 'D:/speech-cognition-4090/models/Qwen2.5-VL-7B-Instruct'
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, padding_side='left')
        model = Qwen2_5_VLForConditionalGeneration.from_pretrained(path, torch_dtype=torch.bfloat16,
            attn_implementation='sdpa', local_files_only=True).to('cuda').eval()
        policy = FiniteEvidencePolicy(model, tokenizer)
        classify = policy.classify

        if mode == 'probe':
            import time
            jobs = [(c, t) for c, t, _ in PROBES]
            begin = time.perf_counter()
            cached = policy.logits(jobs)
            cached_time = time.perf_counter() - begin
            begin = time.perf_counter()
            full = policy.logits(jobs, cached=False)
            full_time = time.perf_counter() - begin
            compare = {'action_agreement': float((cached.argmax(-1) == full.argmax(-1)).float().mean()),
                       'max_bf16_logit_difference': float((cached - full).abs().max()),
                       'cached_seconds': cached_time, 'full_seconds': full_time,
                       'prefix_tokens': len(policy.prefix_ids)}
            (out / 'prefix_cache_probe.json').write_text(json.dumps(compare, indent=2))
            if compare['action_agreement'] != 1:
                raise ValueError('Cached/full semantic actions disagree; investigate before bulk use')
            choices = classify([(c, t) for c, t, _ in PROBES])
            results = [{'concept': c, 'text': t, 'expected': a, 'actual': p} for (c, t, a), p in zip(PROBES, choices, strict=True)]
            dest = out / 'synthetic_semantic_probe.json'
            dest.write_text(json.dumps({'synthetic': True, 'correct': sum(r['expected'] == r['actual'] for r in results),
                                       'total': len(results), 'cases': results}, ensure_ascii=False, indent=2), encoding='utf8')
            print(dest.read_text(encoding='utf8'), flush=True)
            return
        for split in ['train', 'dev']:
            output = out / f'{split}.jsonl'
            done = {r['participant_id'] for r in map(json.loads, output.read_text(encoding='utf8').splitlines())} if output.exists() else set()
            rows = [json.loads(line) for line in (ROOT / f'{split}.inputs.jsonl').read_text(encoding='utf8').splitlines()]
            rows = [r for r in rows if r['participant_id'] not in done]
            if limit:
                rows = rows[:limit]
            for begin in range(0, len(rows), 12):
                group = rows[begin:begin+12]
                sources = [sentences(r) for r in group]
                pointers = [(i, sid, c) for i, source in enumerate(sources) for sid, c in candidates(source)]
                choices = classify([(c, sources[i][sid]['text']) for i, sid, c in pointers])
                for i, row in enumerate(group):
                    actions = [(sid, c, a) for (owner, sid, c), a in zip(pointers, choices, strict=True) if owner == i]
                    turns = [{'id': t['turn_id'], 'text': t['text'], 'role': 'user'} for t in row['turns']]
                    bundle = bundle_from_actions(actions, sources[i], turns)
                    record = {'participant_id': row['participant_id'], 'split': split, 'evidence': bundle,
                              'actions': actions, 'input_sha256': __import__('hashlib').sha256(json.dumps(sources[i], ensure_ascii=False).encode()).hexdigest()}
                    with output.open('a', encoding='utf8') as file:
                        file.write(json.dumps(record, ensure_ascii=False) + '\n')
                print(json.dumps({'split': split, 'done': begin + len(group), 'total': len(rows), 'candidate_count': len(pointers)}), flush=True)
    finally:
        reservation.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['probe', 'annotate'])
    parser.add_argument('--limit', type=int, default=0)
    args = parser.parse_args()
    main(args.mode, args.limit)
