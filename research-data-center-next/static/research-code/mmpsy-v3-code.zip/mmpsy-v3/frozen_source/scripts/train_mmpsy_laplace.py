"""Structured evidence distribution head with a low-parameter Laplace family."""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.train_mmpsy_evidence_heads import write, metrics


class LaplaceHead(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(dim, 128), nn.GELU(), nn.Linear(128, 2))
    def forward(self, x):
        raw = self.net(x)
        location = raw[:, :1].sigmoid() * 100
        scale = torch.nn.functional.softplus(raw[:, 1:]) * 10 + 1
        logits = -(torch.arange(101) - location).abs() / scale
        return logits.softmax(-1), location, scale


def main():
    out = ROOT / 'evidence-laplace'
    out.mkdir(exist_ok=True)
    config = {'family': 'discretized Laplace 101 bins; same source-only evidence bottleneck',
              'losses': ['rps', 'laplace_nll'], 'audio_scales': [0., .1, 1.],
              'seeds': [20260909, 20260910, 20260911], 'epochs': 120, 'patience': 12,
              'lr': .001, 'batch_size': 32, 'protocol_sha256': sha(ROOT / 'protocol.json'),
              'purpose': 'test whether estimating 101 independent logits wastes small-data capacity', 'test_access': False}
    write(out / 'configuration.json', config)
    torch.set_num_threads(2)
    e, a, y = {}, {}, {}
    for s in ['train', 'dev']:
        feat = dict(np.load(ROOT / f'{s}.features.npz'))
        annotation = {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / 'entailment-evidence' / f'{s}.jsonl').read_text(encoding='utf8').splitlines())}
        e[s] = np.stack([vector(annotation[uid])[0] for uid in feat['participant_ids']])
        a[s] = feat['mel']
        targets = json.loads((ROOT / f'{s}.targets.json').read_text())
        y[s] = torch.tensor([targets[uid] for uid in feat['participant_ids']])
    scaler = StandardScaler().fit(a['train'])
    a = {s: scaler.transform(values) / np.sqrt(160) for s, values in a.items()}
    joblib.dump(scaler, out / 'audio_scaler.joblib')
    low, high = y['train'].floor().long(), y['train'].ceil().long()
    weight = y['train'] - low
    cdf = (nn.functional.one_hot(low, 101) * (1-weight[:, None]) + nn.functional.one_hot(high, 101) * weight[:, None]).cumsum(-1)
    results = []
    for scale in config['audio_scales']:
        x = {s: torch.tensor(np.concatenate([e[s], a[s] * scale], axis=1) if scale else e[s], dtype=torch.float32) for s in e}
        for loss_name in config['losses']:
            for seed in config['seeds']:
                torch.manual_seed(seed)
                model = LaplaceHead(x['train'].shape[1])
                with torch.no_grad():
                    model.net[-1].bias[0] = torch.logit(y['train'].median() / 100)
                    model.net[-1].bias[1] = .5
                    model.net[-1].weight.mul_(.1)
                opt = torch.optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=.01)
                best, stale, history = float('inf'), 0, []
                for epoch in range(config['epochs']):
                    for ix in torch.randperm(len(y['train'])).split(config['batch_size']):
                        p, mu, b = model(x['train'][ix])
                        rps = (p.cumsum(-1)-cdf[ix]).square().mean()
                        score = (p * torch.arange(101)).sum(-1)
                        if loss_name == 'rps':
                            loss = rps + .5 * ((score-y['train'][ix])/100).square().mean()
                        else:
                            loss = ((mu[:, 0]-y['train'][ix]).abs()/b[:, 0] + b[:, 0].log()).mean() + rps
                        opt.zero_grad()
                        loss.backward()
                        nn.utils.clip_grad_norm_(model.parameters(), 1)
                        opt.step()
                    with torch.no_grad():
                        p, _, _ = model(x['dev'])
                        pred = (p * torch.arange(101)).sum(-1).numpy()
                    evaluation = metrics(pred, y['dev'].numpy())
                    history.append({'epoch': epoch+1, **evaluation})
                    if evaluation['mae'] < best - 1e-5:
                        best, stale = evaluation['mae'], 0
                        state = {k: v.detach().clone() for k, v in model.state_dict().items()}
                        best_p, best_eval = p.numpy().copy(), evaluation
                    else:
                        stale += 1
                    if stale >= config['patience']:
                        break
                name = f'{loss_name}-audio-{scale}-{seed}'
                torch.save({'state_dict': state, 'input_dim': x['train'].shape[1], 'audio_scale': scale,
                            'family': 'laplace', 'seed': seed, 'score_definition': 'mmpsy-phq-severity-index-v2'}, out / f'{name}.pt')
                np.save(out / f'{name}.dev.npy', best_p)
                write(out / f'{name}.history.json', history)
                result = {'name': name, 'seed': seed, 'epochs': len(history), **best_eval}
                results.append(result)
                print(json.dumps(result), flush=True)
                write(out / 'results.json', results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
