"""Accuracy-only latent bypass control; explicitly ineligible as evidence-only product."""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.train_mmpsy_evidence_heads import write, metrics


def main():
    out = ROOT / 'dense-control'
    out.mkdir(exist_ok=True)
    write(out / 'configuration.json', {'product_eligible': False, 'reason': 'contains dense semantic bypass',
        'alpha': [.1, 1, 10, 100], 'evidence_weight': [.5, 1, 2], 'audio_scale': [0., .1, 1.],
        'protocol_sha256': sha(ROOT / 'protocol.json'), 'test_access': False})
    f = {s: dict(np.load(ROOT / f'{s}.features.npz')) for s in ['train', 'dev']}
    hscale = StandardScaler().fit(f['train']['text_mean'])
    ascale = StandardScaler().fit(f['train']['mel'])
    h = {s: hscale.transform(x['text_mean'])/np.sqrt(768) for s, x in f.items()}
    a = {s: ascale.transform(x['mel'])/np.sqrt(160) for s, x in f.items()}
    e, y = {}, {}
    for s in f:
        rows = {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / 'entailment-evidence' / f'{s}.jsonl').read_text(encoding='utf8').splitlines())}
        e[s] = np.stack([vector(rows[uid])[0] for uid in f[s]['participant_ids']])
        target = json.loads((ROOT / f'{s}.targets.json').read_text())
        y[s] = np.array([target[uid] for uid in f[s]['participant_ids']])
    results = []
    for audio_scale in [0., .1, 1.]:
        trials = []
        for ev_weight in [.5, 1, 2]:
            x = {s: np.concatenate([h[s], e[s]*ev_weight, a[s]*audio_scale], axis=1) for s in f}
            for alpha in [.1, 1, 10, 100]:
                model = Ridge(alpha=alpha, solver='lsqr', tol=1e-6).fit(x['train'], y['train'])
                pred = np.clip(model.predict(x['dev']), 0, 100)
                trials.append((float(np.abs(pred-y['dev']).mean()), ev_weight, alpha, model, pred))
        _, ev_weight, alpha, model, pred = min(trials, key=lambda t: t[0])
        name = f'e5-evidence-audio-{audio_scale}'
        joblib.dump({'regressor': model, 'semantic_scaler': hscale, 'audio_scaler': ascale,
                     'evidence_weight': ev_weight, 'audio_scale': audio_scale, 'product_eligible': False}, out / f'{name}.joblib')
        result = {'name': name, 'evidence_weight': ev_weight, 'alpha': alpha, **metrics(pred, y['dev']),
                  'trials': [{'mae': m, 'evidence_weight': w, 'alpha': aa} for m, w, aa, _, _ in trials]}
        results.append(result)
        write(out / f'{name}.dev.json', pred.tolist())
        print(json.dumps({k: v for k, v in result.items() if k != 'trials'}), flush=True)
    write(out / 'results.json', results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
