"""Lock-guarded one-time holdout feature/extractor inference; never opens target labels."""
# ruff: noqa: E402
import gc
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer, Qwen2_5_VLForConditionalGeneration
from depression_lab.finite_evidence_policy import FiniteEvidencePolicy
from depression_lab.omni_evidence_policy import OmniEvidencePolicy
from depression_lab.unified_model import OmniEncoder
from depression_lab.evidence_entailment import candidates, bundle_from_actions
from scripts.cache_mmpsy_v2 import sentences
from scripts.prepare_mmpsy_v2 import ROOT, DATA, sha
from scripts.train_mmpsy_baselines import pooled_mel
from scripts.run_unified_experiments import reserve


def verify_lock():
    lock = json.loads((ROOT / 'selection_lock.json').read_text(encoding='utf8'))
    for path, expected in lock['hashes'].items():
        if sha(path) != expected:
            raise ValueError('Frozen artifact/source changed: '+path)
    return lock


def cache_e5(groups):
    path = 'D:/speech-cognition-4090/models/multilingual-e5-base'
    tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
    model = AutoModel.from_pretrained(path, local_files_only=True).to('cuda').eval()
    for split, rows in groups.items():
        output = ROOT / f'{split}.features.npz'
        if output.exists():
            continue
        segments, bounds = [], [0]
        for row in rows:
            segments.extend(sentences(row))
            bounds.append(len(segments))
        vectors = []
        for start in range(0, len(segments), 48):
            tokens = tokenizer(['passage: '+s['text'] for s in segments[start:start+48]], return_tensors='pt', padding=True, truncation=False).to('cuda')
            if tokens.input_ids.shape[1] > 512:
                raise ValueError('Holdout segment too long; no truncation')
            with torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
                hidden = model(**tokens).last_hidden_state.float()
                mask = tokens.attention_mask.unsqueeze(-1)
                pooled = (hidden*mask).sum(1)/mask.sum(1)
                vectors.append(torch.nn.functional.normalize(pooled, dim=-1).cpu().numpy())
        vectors = np.concatenate(vectors)
        means = np.stack([vectors[a:b].mean(0) for a, b in zip(bounds[:-1], bounds[1:], strict=True)])
        deviations = np.stack([vectors[a:b].std(0) for a, b in zip(bounds[:-1], bounds[1:], strict=True)])
        mel = np.stack([pooled_mel(DATA / 'np_data' / r['participant_id'] / 'mel-spectrogram') for r in rows])
        np.savez_compressed(output, participant_ids=[r['participant_id'] for r in rows], bounds=bounds,
                            segment_vectors=vectors, text_mean=means, text_std=deviations, mel=mel)
        (ROOT / f'{split}.segments.json').write_text(json.dumps(segments, ensure_ascii=False), encoding='utf8')
        print(json.dumps({'stage': 'holdout_e5_features', 'split': split, 'count': len(rows)}), flush=True)
    del model, tokenizer


def annotate(groups, student):
    if student:
        encoder = OmniEncoder('D:/depression-lab/models/Qwen2.5-Omni-3B', str(ROOT / 'reasoner-sft/adapter'))
        encoder.model.eval()
        policy = OmniEvidencePolicy(encoder)
        folder = ROOT / 'student-evidence'
    else:
        path = 'D:/speech-cognition-4090/models/Qwen2.5-VL-7B-Instruct'
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, padding_side='left')
        model = Qwen2_5_VLForConditionalGeneration.from_pretrained(path, torch_dtype=torch.bfloat16,
            attn_implementation='sdpa', local_files_only=True).to('cuda').eval()
        policy = FiniteEvidencePolicy(model, tokenizer)
        folder = ROOT / 'entailment-evidence'
    for split, all_rows in groups.items():
        output = folder / f'{split}.jsonl'
        done = {r['participant_id'] for r in map(json.loads, output.read_text(encoding='utf8').splitlines())} if output.exists() else set()
        rows = [r for r in all_rows if r['participant_id'] not in done]
        for start in range(0, len(rows), 16):
            group = rows[start:start+16]
            sources = [sentences(r) for r in group]
            pointers = [(i, sid, c) for i, source in enumerate(sources) for sid, c in candidates(source)]
            actions = policy.classify([(c, sources[i][sid]['text']) for i, sid, c in pointers])
            for i, row in enumerate(group):
                chosen = [(sid, c, action) for (owner, sid, c), action in zip(pointers, actions, strict=True) if owner == i]
                turns = [{'id': t['turn_id'], 'role': 'user', 'text': t['text']} for t in row['turns']]
                bundle = bundle_from_actions(chosen, sources[i], turns)
                record = {'participant_id': row['participant_id'], 'split': split, 'actions': chosen, 'evidence': bundle,
                          'heldout': True, 'student': student, 'labels_seen': False}
                with output.open('a', encoding='utf8') as file:
                    file.write(json.dumps(record, ensure_ascii=False)+'\n')
            print(json.dumps({'stage': 'holdout_evidence', 'student': student, 'split': split,
                              'done': start+len(group), 'count': len(rows)}), flush=True)
    del policy


def main():
    lock = verify_lock()
    protocol = json.loads((ROOT / 'protocol.json').read_text(encoding='utf8'))
    inputs = [json.loads(line) for line in (DATA / 'semantic_inputs.label_blind.jsonl').read_text(encoding='utf8').splitlines()]
    groups = {split: [r for r in inputs if protocol['splits'][r['participant_id']] == split] for split in ['calibration', 'test']}
    if len(groups['calibration']) != lock['calibration_n'] or len(groups['test']) != lock['test_n']:
        raise ValueError('Holdout participant counts differ from frozen plan')
    for split, rows in groups.items():
        (ROOT / f'{split}.inputs.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows), encoding='utf8')
    reservation = reserve(ROOT)
    try:
        torch.set_num_threads(4)
        cache_e5(groups)
        gc.collect()
        torch.cuda.empty_cache()
        annotate(groups, student=False)
        gc.collect()
        torch.cuda.empty_cache()
        annotate(groups, student=True)
        (ROOT / 'holdout_inference_complete.json').write_text(json.dumps({'completed': True, 'target_labels_read': False}))
    finally:
        reservation.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
