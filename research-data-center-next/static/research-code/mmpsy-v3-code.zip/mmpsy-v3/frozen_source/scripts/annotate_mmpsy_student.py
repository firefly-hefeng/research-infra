"""Actual trained extractor predictions, never teacher substitution for score-head fitting."""
# ruff: noqa: E402
import argparse
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, 'D:/depression-lab/training-packages')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
from depression_lab.unified_model import OmniEncoder
from depression_lab.omni_evidence_policy import OmniEvidencePolicy
from depression_lab.evidence_entailment import candidates, bundle_from_actions
from scripts.cache_mmpsy_v2 import sentences
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.run_unified_experiments import reserve
from scripts.annotate_mmpsy_entailment import PROBES
from scripts.train_mmpsy_reasoner import OUT, training_prompt


def main(mode):
    out = ROOT / 'student-evidence'
    out.mkdir(exist_ok=True)
    config = {'model': 'trained Omni3B finite source evidence plus structured rationale',
              'adapter_sha256': sha(OUT / 'adapter/adapter_model.safetensors'),
              'label_blind': True, 'raw_audio_used_for_annotation': False,
              'prompt_example': training_prompt('材料占位，不是真实数据', 'mood'),
              'protocol_sha256': sha(ROOT / 'protocol.json')}
    cp = out / 'configuration.json'
    if cp.exists() and json.loads(cp.read_text(encoding='utf8')) != config:
        raise ValueError('Extractor changed; new prediction cache required')
    cp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf8')
    reservation = reserve(ROOT)
    try:
        encoder = OmniEncoder('D:/depression-lab/models/Qwen2.5-Omni-3B', str(OUT / 'adapter'))
        encoder.model.eval()
        policy = OmniEvidencePolicy(encoder)
        if mode == 'probe':
            jobs = [(c, text) for c, text, _ in PROBES]
            actions = policy.classify(jobs)
            explanations = policy.explanations(jobs, actions)
            result = {'synthetic': True, 'clinical_test': False,
                      'semantic_correct': sum(a == expected for a, (_, _, expected) in zip(actions, PROBES, strict=True)),
                      'total': len(PROBES), 'cot_structural_source_agreement': sum(x['structural_source_agreement'] for x in explanations),
                      'actions': actions, 'explanations': explanations}
            (out / 'synthetic_probe.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
            print(json.dumps({k: v for k, v in result.items() if k not in ['explanations', 'actions']}), flush=True)
            return
        for split in ['train', 'dev']:
            output = out / f'{split}.jsonl'
            done = {r['participant_id'] for r in map(json.loads, output.read_text(encoding='utf8').splitlines())} if output.exists() else set()
            rows = [json.loads(line) for line in (ROOT / f'{split}.inputs.jsonl').read_text(encoding='utf8').splitlines()]
            rows = [r for r in rows if r['participant_id'] not in done]
            for begin in range(0, len(rows), 16):
                group = rows[begin:begin+16]
                sources = [sentences(r) for r in group]
                pointers = [(i, sid, c) for i, source in enumerate(sources) for sid, c in candidates(source)]
                actions = policy.classify([(c, sources[i][sid]['text']) for i, sid, c in pointers])
                for i, row in enumerate(group):
                    selected = [(sid, c, action) for (owner, sid, c), action in zip(pointers, actions, strict=True) if owner == i]
                    turns = [{'id': t['turn_id'], 'role': 'user', 'text': t['text']} for t in row['turns']]
                    bundle = bundle_from_actions(selected, sources[i], turns)
                    bundle['annotation_origin'] = 'trained_Omni3B_actual_prediction_not_teacher_substitute'
                    record = {'participant_id': row['participant_id'], 'split': split, 'actions': selected, 'evidence': bundle}
                    with output.open('a', encoding='utf8') as file:
                        file.write(json.dumps(record, ensure_ascii=False)+'\n')
                print(json.dumps({'split': split, 'done': begin+len(group), 'total': len(rows), 'source_decisions': len(pointers)}), flush=True)
    finally:
        reservation.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['probe', 'annotate'])
    main(parser.parse_args().mode)
