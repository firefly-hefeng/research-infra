"""Online 32x4 source-selection GRPO; fixed scorer, exact source/denial constraints.

This deliberately logs an evidence-action experiment, not an LLM token-level
EmotionThinker reproduction. CoT wording is not an action or a numeric reward.
"""
# ruff: noqa: E402
import copy
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.train_mmpsy_evidence_heads import metrics, write
from scripts.train_mmpsy_joint_selector import JointSelector, eligibility


def state_hash(module):
    digest = hashlib.sha256()
    for key, value in module.state_dict().items():
        digest.update(key.encode())
        digest.update(value.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def main():
    out = ROOT / 'selection-grpo'
    out.mkdir(exist_ok=True)
    config = {'groups': 32, 'candidates': 4, 'branches': ['outcome', 'outcome_evidence'],
              'seed': 20260909, 'kl_beta': .02, 'lr': .003, 'ppo_clip': .2,
              'action_space': 'retain or omit source-supported concept; all explicit denials protected',
              'reference': 'supervised smoothed source-retention policy, frozen per branch',
              'scorer': 'frozen teacher-evidence 3-seed ensemble + audio-tilt l2=1',
              'tau': 0., 'tau_reason': 'no independently validated explanation reward available',
              'evidence_reward': '0.05 retention coverage; mechanical citation/denial constraints; not expert correctness',
              'test_access': False, 'protocol_sha256': sha(ROOT / 'protocol.json')}
    write(out / 'configuration.json', config)
    torch.set_num_threads(2)
    torch.manual_seed(config['seed'])
    e, a, h, y, ids = {}, {}, {}, {}, {}
    for split in ['train', 'dev']:
        f = dict(np.load(ROOT / f'{split}.features.npz'))
        ids[split] = list(f['participant_ids'])
        records = {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / 'entailment-evidence' / f'{split}.jsonl').read_text(encoding='utf8').splitlines())}
        e[split] = torch.tensor(np.stack([vector(records[uid])[0] for uid in ids[split]]))
        a[split], h[split] = f['mel'], f['text_mean']
        targets = json.loads((ROOT / f'{split}.targets.json').read_text())
        y[split] = torch.tensor([targets[uid] for uid in ids[split]])
    sa = joblib.load(ROOT / 'audio-residual/audio_scaler.joblib')
    sh = StandardScaler().fit(h['train'])
    joblib.dump({'audio': sa, 'semantic': sh}, out / 'scalers.joblib')
    a = {s: torch.tensor(sa.transform(x)/np.sqrt(160), dtype=torch.float32) for s, x in a.items()}
    h = {s: torch.tensor(sh.transform(x)/np.sqrt(768), dtype=torch.float32) for s, x in h.items()}
    masks = {s: eligibility(e[s]) for s in e}
    frozen = torch.load(ROOT / 'audio-residual/audio-tilt-l2-1.0.pt', weights_only=True)
    heads = nn.ModuleList([nn.Sequential(nn.Linear(177, 128), nn.GELU(), nn.Linear(128, 101)) for _ in range(3)])
    for head, state in zip(heads, frozen['heads'], strict=True):
        head.load_state_dict(state)
    heads.requires_grad_(False)
    head_hash = state_hash(heads)
    beta = frozen['beta']
    grid = torch.arange(101)
    gate_model = JointSelector()
    # SFT on independent source availability, no severity labels in this step.
    opt = torch.optim.AdamW(gate_model.selector.parameters(), lr=.003)
    policy_inputs = {s: torch.cat([h[s], e[s], a[s]*.1], -1) for s in e}
    for _ in range(150):
        logits = gate_model.selector(policy_inputs['train'])
        loss = nn.functional.binary_cross_entropy_with_logits(logits[masks['train'][0]], torch.full_like(logits[masks['train'][0]], .9))
        opt.zero_grad()
        loss.backward()
        opt.step()
    reference = copy.deepcopy(gate_model.selector).eval().requires_grad_(False)
    reference_hash = state_hash(reference)
    torch.save({'state_dict': reference.state_dict(), 'family': 'source-retention-reference'}, out / 'sft_reference.pt')

    def score(selected, acoustic):
        p = torch.stack([head(selected).softmax(-1) for head in heads]).mean(0)
        return (p.clamp_min(1e-8).log() + (acoustic@beta)[:, None]*(grid-50)/100).softmax(-1)

    def evaluate(model):
        with torch.no_grad():
            _, _, g, selected = model(h['dev'], e['dev'], a['dev']*.1, *masks['dev'])
            p = score(selected, a['dev'])
        return metrics((p*grid).sum(-1).numpy(), y['dev'].numpy()), p.numpy(), int((masks['dev'][0] & (g < .5)).sum())

    before, before_p, _ = evaluate(gate_model)
    write(out / 'before.json', before)
    np.save(out / 'reference.dev.npy', before_p)
    order = torch.randperm(len(y['train']), generator=torch.Generator().manual_seed(config['seed']))[:config['groups']]
    results = []
    for branch in config['branches']:
        model = copy.deepcopy(gate_model)
        optimizer = torch.optim.AdamW(model.selector.parameters(), lr=config['lr'])
        updates = zero = diverse = 0
        logs = []
        torch.manual_seed(config['seed'])
        for group, index in enumerate(order):
            index = int(index)
            evidence = e['train'][index:index+1].repeat(4, 1)
            acoustic = a['train'][index:index+1].repeat(4, 1)
            latent = h['train'][index:index+1].repeat(4, 1)
            available, protected = (v[index:index+1].repeat(4, 1) for v in masks['train'])
            free = available & ~protected
            inputs = torch.cat([latent, evidence, acoustic*.1], -1)
            with torch.no_grad():
                old_logits = model.selector(inputs)
                dist = torch.distributions.Bernoulli(logits=old_logits)
                actions = dist.sample()
                actions = torch.where(protected, torch.ones_like(actions), actions)
                actions = torch.where(available, actions, torch.zeros_like(actions))
                old_logp = (dist.log_prob(actions)*free).sum(-1)
                _, _, _, selected = model(latent, evidence, acoustic*.1, available, protected, actions=actions)
                p = score(selected, acoustic)
                truth = y['train'][index]
                lower, upper = truth.floor().long(), truth.ceil().long()
                fraction = truth-lower
                target = (nn.functional.one_hot(lower, 101)*(1-fraction) +
                          nn.functional.one_hot(upper, 101)*fraction).cumsum(-1)
                rps = (p.cumsum(-1)-target).square().mean(-1)
                predicted = (p*grid).sum(-1)
                outcome = -rps-.5*((predicted-y['train'][index])/100).square()
                retained = (actions*available).sum(-1)/available.sum(-1).clamp_min(1)
                rewards = outcome + (.05*retained if branch == 'outcome_evidence' else 0)
                reference_logits = reference(inputs)
                var = float(rewards.std(unbiased=False))
                different_scores = bool(torch.ptp(predicted) > 1e-7) if hasattr(torch, 'ptp') else bool(predicted.max()-predicted.min() > 1e-7)
                diverse += int(different_scores)
            record = {'group': group, 'participant_id': ids['train'][index], 'actions': actions.tolist(),
                      'outcome_rewards': outcome.tolist(), 'retention_rewards': retained.tolist(), 'rewards': rewards.tolist(),
                      'scores': predicted.tolist(), 'reward_std': var, 'tau': 0, 'different_scores': different_scores}
            if var < 1e-8 or not free.any():
                zero += 1
                record['updated'] = False
            else:
                advantages = (rewards-rewards.mean())/rewards.std(unbiased=False)
                logits = model.selector(inputs)
                current = torch.distributions.Bernoulli(logits=logits)
                ratio = ((current.log_prob(actions)*free).sum(-1)-old_logp).exp()
                surrogate = torch.minimum(ratio*advantages, ratio.clamp(.8, 1.2)*advantages).mean()
                kl = (torch.distributions.kl_divergence(current, torch.distributions.Bernoulli(logits=reference_logits))*free).sum()/free.sum().clamp_min(1)
                loss = -surrogate+config['kl_beta']*kl
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.selector.parameters(), 1)
                optimizer.step()
                updates += 1
                record.update(updated=True, kl=float(kl.detach()), loss=float(loss.detach()))
            logs.append(record)
        evaluation, probabilities, dropped = evaluate(model)
        torch.save({'state_dict': model.selector.state_dict(), 'family': 'reinforced-source-selector', 'branch': branch}, out / f'{branch}.pt')
        np.save(out / f'{branch}.dev.npy', probabilities)
        (out / f'{branch}.candidates.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in logs), encoding='utf8')
        result = {'name': branch, 'updates': updates, 'zero_variance_groups': zero, 'groups_with_different_scores': diverse,
                  'candidate_count': 128, 'tau_active_groups': 0, 'dropped_supported_concepts': dropped,
                  'reference_unchanged': state_hash(reference) == reference_hash, 'scorer_unchanged': state_hash(heads) == head_hash, **evaluation}
        results.append(result)
        print(json.dumps(result), flush=True)
    write(out / 'results.json', results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
