"""Joint hard evidence selection; the score head has no latent representation path.

Research A-lite: frozen E5 + measured mel, trainable selector and score head.
Not misrepresented as a newly trained Omni audio encoder.
"""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from depression_lab.compact_evidence import vector
from scripts.prepare_mmpsy_v2 import ROOT, sha
from scripts.train_mmpsy_evidence_heads import write, metrics


class JointSelector(nn.Module):
    def __init__(self):
        super().__init__()
        self.selector = nn.Sequential(nn.Linear(768+160+177, 128), nn.GELU(), nn.Linear(128, 21))
        self.scorer = nn.Sequential(nn.Linear(177+160, 128), nn.GELU(), nn.Linear(128, 101))

    def forward(self, representation, evidence, acoustic, available, protected, actions=None):
        logits = self.selector(torch.cat([representation, evidence, acoustic], -1))
        soft = logits.sigmoid()
        hard = (soft > .5).float() if actions is None else actions.float()
        g = hard + soft - soft.detach()
        g = torch.where(protected, torch.ones_like(g), g)
        g = torch.where(available, g, torch.zeros_like(g))
        values = []
        for c in range(9):
            original = evidence[:, c*17:(c+1)*17]
            unknown = torch.zeros_like(original)
            unknown[:, [0, 3, 8, 11, 14]] = 1
            values.append(original*g[:, c:c+1] + unknown*(1-g[:, c:c+1]))
        for c in range(12):
            values.append(evidence[:, 153+c*2:153+c*2+2] * g[:, 9+c:10+c])
        selected = torch.cat(values, -1)
        return self.scorer(torch.cat([selected, acoustic], -1)).softmax(-1), logits, g, selected


def eligibility(e):
    available, protected = [], []
    for c in range(9):
        available.append(e[:, c*17+1:c*17+3].sum(-1) > 0)
        protected.append(e[:, c*17+2] == 1)
    for c in range(12):
        available.append(e[:, 153+c*2:155+c*2].sum(-1) > 0)
        protected.append(e[:, 154+c*2] == 1)
    return torch.stack(available, -1), torch.stack(protected, -1)


def main():
    out = ROOT / 'joint-selector'
    out.mkdir(exist_ok=True)
    config = {'route': 'A-lite-frozen-E5-mel-joint-hard-selector', 'seeds': [20260909, 20260910, 20260911],
              'epochs': 80, 'patience': 10, 'batch': 32, 'lr': .0003, 'retention_weights': [.001, .01],
              'audio_scale': .1, 'retains_all_explicit_denials': True, 'no_latent_score_bypass': True,
              'test_access': False, 'protocol_sha256': sha(ROOT / 'protocol.json')}
    write(out / 'configuration.json', config)
    torch.set_num_threads(2)
    e, a, h, y = {}, {}, {}, {}
    for s in ['train', 'dev']:
        f = dict(np.load(ROOT / f'{s}.features.npz'))
        records = {r['participant_id']: r['evidence'] for r in map(json.loads, (ROOT / 'entailment-evidence' / f'{s}.jsonl').read_text(encoding='utf8').splitlines())}
        e[s] = torch.tensor(np.stack([vector(records[uid])[0] for uid in f['participant_ids']]))
        a[s], h[s] = f['mel'], f['text_mean']
        targets = json.loads((ROOT / f'{s}.targets.json').read_text())
        y[s] = torch.tensor([targets[uid] for uid in f['participant_ids']])
    sa, sh = StandardScaler().fit(a['train']), StandardScaler().fit(h['train'])
    joblib.dump({'audio': sa, 'semantic': sh}, out / 'scalers.joblib')
    a = {s: torch.tensor(sa.transform(x)*.1/np.sqrt(160), dtype=torch.float32) for s, x in a.items()}
    h = {s: torch.tensor(sh.transform(x)/np.sqrt(768), dtype=torch.float32) for s, x in h.items()}
    masks = {s: eligibility(e[s]) for s in e}
    low, high = y['train'].floor().long(), y['train'].ceil().long()
    w = y['train'] - low
    cdf = (nn.functional.one_hot(low, 101)*(1-w[:, None]) + nn.functional.one_hot(high, 101)*w[:, None]).cumsum(-1)
    all_results = []
    for coefficient in config['retention_weights']:
        for seed in config['seeds']:
            torch.manual_seed(seed)
            model = JointSelector()
            state = torch.load(ROOT / 'evidence-heads' / f'evidence-{seed}.pt', weights_only=True)['state_dict']
            with torch.no_grad():
                model.scorer[0].weight[:, :177] = state['0.weight']
                model.scorer[0].weight[:, 177:] = 0
                model.scorer[0].bias.copy_(state['0.bias'])
                model.scorer[2].weight.copy_(state['2.weight'])
                model.scorer[2].bias.copy_(state['2.bias'])
                model.selector[2].bias.fill_(1)
                model.selector[2].weight.mul_(.1)
            opt = torch.optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=.01)
            best, stale, history = float('inf'), 0, []
            for epoch in range(config['epochs']):
                for ix in torch.randperm(len(y['train'])).split(config['batch']):
                    p, logits, _, _ = model(h['train'][ix], e['train'][ix], a['train'][ix], *(x[ix] for x in masks['train']))
                    score = (p*torch.arange(101)).sum(-1)
                    supervision = masks['train'][0][ix] & ~masks['train'][1][ix]
                    retention = nn.functional.softplus(-logits)[supervision].mean() if supervision.any() else logits.sum()*0
                    loss = (p.cumsum(-1)-cdf[ix]).square().mean() + .5*((score-y['train'][ix])/100).square().mean() + coefficient*retention
                    opt.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), 1)
                    opt.step()
                with torch.no_grad():
                    p, _, gates, _ = model(h['dev'], e['dev'], a['dev'], *masks['dev'])
                    prediction = (p*torch.arange(101)).sum(-1).numpy()
                evaluation = metrics(prediction, y['dev'].numpy())
                evaluation['dropped_supported_concepts'] = int((masks['dev'][0] & (gates < .5)).sum())
                history.append({'epoch': epoch+1, **evaluation})
                if evaluation['mae'] < best - 1e-5:
                    best, stale = evaluation['mae'], 0
                    state = {k: v.detach().clone() for k, v in model.state_dict().items()}
                    best_p, best_eval = p.numpy().copy(), evaluation
                else:
                    stale += 1
                if stale >= config['patience']:
                    break
            name = f'joint-retain-{coefficient}-{seed}'
            torch.save({'state_dict': state, 'family': 'joint-selector', 'seed': seed, 'audio_scale': .1,
                        'score_definition': 'mmpsy-phq-severity-index-v2'}, out / f'{name}.pt')
            np.save(out / f'{name}.dev.npy', best_p)
            write(out / f'{name}.history.json', history)
            result = {'name': name, 'seed': seed, 'epochs': len(history), **best_eval}
            all_results.append(result)
            print(json.dumps(result), flush=True)
            write(out / 'results.json', all_results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
