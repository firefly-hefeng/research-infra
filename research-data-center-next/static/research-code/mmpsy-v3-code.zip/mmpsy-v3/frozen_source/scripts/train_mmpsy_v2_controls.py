"""Development-only controls and frozen-encoder ceiling; no test access."""
# ruff: noqa: E402
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.kernel_ridge import KernelRidge
from scipy.stats import spearmanr
from threadpoolctl import threadpool_limits
from scripts.prepare_mmpsy_v2 import ROOT, sha


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')


def main():
    out = ROOT / 'controls'
    out.mkdir(exist_ok=True)
    if (out / 'results.json').exists():
        print((out / 'results.json').read_text())
        return
    alphas = [0.01, 0.1, 1, 10, 100, 1000]
    write(out / 'configuration.json', {'alphas': alphas, 'rbf_gamma': [0.05, 0.2, 1, 5],
        'encoder': 'frozen multilingual-e5-base, all sentence segments', 'protocol_sha256': sha(ROOT / 'protocol.json'),
        'test_access': False, 'seed': 20260909})
    rows, y, feat, strings = {}, {}, {}, {}
    for s in ['train', 'dev']:
        rows[s] = [json.loads(line) for line in (ROOT / f'{s}.inputs.jsonl').read_text(encoding='utf8').splitlines()]
        targets = json.loads((ROOT / f'{s}.targets.json').read_text())
        y[s] = np.array([targets[r['participant_id']] for r in rows[s]])
        feat[s] = np.load(ROOT / f'{s}.features.npz', allow_pickle=False)
        assert list(feat[s]['participant_ids']) == [r['participant_id'] for r in rows[s]]
        strings[s] = ['\n'.join(t['text'] for t in r['turns']) for r in rows[s]]
    vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(1, 3), max_features=12000, sublinear_tf=True)
    text = {'train': vectorizer.fit_transform(strings['train'])}
    text['dev'] = vectorizer.transform(strings['dev'])
    mel_scaler = StandardScaler().fit(feat['train']['mel'])
    mel = {s: csr_matrix(mel_scaler.transform(feat[s]['mel']) / np.sqrt(160)) for s in rows}
    mean_scaler = StandardScaler().fit(feat['train']['text_mean'])
    e5 = {s: mean_scaler.transform(feat[s]['text_mean']) / np.sqrt(768) for s in rows}
    inputs = {
        'text': text, 'audio': mel, 'fusion': {s: hstack([text[s], mel[s]]).tocsr() for s in rows},
        'e5': e5, 'e5_audio': {s: hstack([e5[s], mel[s]]).tocsr() for s in rows},
        'text_e5': {s: hstack([text[s], e5[s]]).tocsr() for s in rows},
        'text_e5_audio': {s: hstack([text[s], e5[s], mel[s]]).tocsr() for s in rows},
    }
    results, predictions = [], {}

    def record(name, pred, artifact, trials):
        pred = np.clip(pred, 0, 100)
        result = {'name': name, 'mae': float(np.abs(y['dev'] - pred).mean()),
                  'rmse': float(np.square(y['dev'] - pred).mean() ** .5),
                  'spearman': float(spearmanr(y['dev'], pred).statistic) if np.std(pred) else None,
                  'prediction_std': float(np.std(pred)), 'trials': trials}
        results.append(result)
        predictions[name] = pred.tolist()
        joblib.dump(artifact, out / f'{name}.joblib')
        print(json.dumps({k: v for k, v in result.items() if k != 'trials'}), flush=True)
        write(out / 'progress.json', results)

    for name, value in [('median', np.median(y['train'])), ('mean', np.mean(y['train']))]:
        record(name, np.full(len(y['dev']), value), {'kind': 'constant', 'value': float(value)}, [])
    for name, x in inputs.items():
        trials = []
        for alpha in alphas:
            model = Ridge(alpha=alpha, solver='lsqr', tol=1e-6).fit(x['train'], y['train'])
            pred = np.clip(model.predict(x['dev']), 0, 100)
            trials.append((float(np.abs(pred-y['dev']).mean()), alpha, model, pred))
        mae, alpha, model, pred = min(trials, key=lambda t: t[0])
        record(name, pred, {'kind': name, 'regressor': model, 'vectorizer': vectorizer,
                           'mel_scaler': mel_scaler, 'mean_scaler': mean_scaler},
               [{'mae': m, 'alpha': a} for m, a, _, _ in trials])
    # Nonlinear frozen semantic representation is an accuracy control, not a
    # faithful evidence bottleneck or an eligible clinical product model.
    for name in ['e5_rbf', 'e5_audio_rbf']:
        x = {s: e5[s] if name == 'e5_rbf' else np.concatenate([e5[s], mel[s].toarray()], axis=1) for s in rows}
        trials = []
        for gamma in [0.05, 0.2, 1, 5]:
            for alpha in alphas[:5]:
                model = KernelRidge(alpha=alpha, kernel='rbf', gamma=gamma).fit(x['train'], y['train'])
                pred = np.clip(model.predict(x['dev']), 0, 100)
                trials.append((float(np.abs(pred-y['dev']).mean()), gamma, alpha, model, pred))
        _, gamma, alpha, model, pred = min(trials, key=lambda t: t[0])
        record(name, pred, {'kind': name, 'regressor': model, 'mean_scaler': mean_scaler,
                           'mel_scaler': mel_scaler}, [{'mae': m, 'gamma': g, 'alpha': a} for m, g, a, _, _ in trials])
    write(out / 'dev_predictions.json', {'participant_ids': [r['participant_id'] for r in rows['dev']],
                                       'target': y['dev'].tolist(), 'predictions': predictions})
    write(out / 'results.json', results)


if __name__ == '__main__':
    with threadpool_limits(2):
        main()
