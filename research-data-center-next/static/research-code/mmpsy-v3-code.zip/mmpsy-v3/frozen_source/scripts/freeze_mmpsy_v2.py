"""Freeze development choices and artifact hashes before any holdout prediction."""
# ruff: noqa: E402
import argparse
import json
import shutil
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import joblib
from scripts.prepare_mmpsy_v2 import ROOT, sha


def main(prepare_only=False):
    lock_path = ROOT / 'selection_lock.json'
    if lock_path.exists():
        print('Selection already locked; no changes made')
        return
    required = ['controls', 'prototype-feasibility', 'evidence-heads', 'evidence-counts', 'evidence-laplace',
                'joint-selector', 'audio-residual', 'student-heads', 'selection-grpo', 'dense-control']
    for folder in required:
        if not (ROOT / folder / 'results.json').is_file():
            raise ValueError('Incomplete development experiment: '+folder)
    out = ROOT / 'release-candidate'
    out.mkdir(exist_ok=True)
    selected = ROOT / 'audio-residual/audio-tilt-l2-1.0.pt'
    shutil.copy2(selected, out / 'scorer.pt')
    scaler = joblib.load(ROOT / 'audio-residual/audio_scaler.joblib')
    controls = json.loads((ROOT / 'controls/results.json').read_text())
    baseline = min(controls, key=lambda row: row['mae'])
    if baseline['name'] != 'e5':
        raise ValueError('Unexpected strongest baseline; inspect before locking')
    manifest = {'engine': 'mmpsy-evidence-v2', 'model_version': 'mmpsy-v2-B-evidence-ensemble-audio-tilt',
                'score_definition': 'mmpsy-phq-severity-index-v2', 'target_construction': '100*PHQ9_raw/27',
                'scale_comparable_with_SDS_v1': False, 'scorer_sha256': sha(out / 'scorer.pt'),
                'extractor': 'frozen_local_Qwen2.5-VL-7B_finite_source_entailment',
                'explanation_adapter': str(ROOT / 'reasoner-sft/adapter'),
                'explanation_adapter_sha256': sha(ROOT / 'reasoner-sft/adapter/adapter_model.safetensors'),
                'source_evidence_version': 'source-entailment-v1',
                'audio_normalizer': {'mean': scaler.mean_.tolist(), 'scale': scaler.scale_.tolist()},
                'selected_dev_mae': 8.197885513305664, 'strongest_simple_baseline': baseline['name'],
                'baseline_dev_mae': baseline['mae'], 'selection_rule': 'minimum dev MAE among actually-audio-using source-only evidence candidates; all three seeds retained',
                'clinical_validated': False, 'free_chat_validated': False,
                'interval_population': 'MMPsy released interview features; no validated free-chat coverage',
                'provenance': '1273 eligible MMPsy participants; raw author waveforms unavailable'}
    (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    if prepare_only:
        print(json.dumps({'prepared_for_development_replay': True, 'test_locked': False}))
        return
    paths = []
    for folder in required:
        paths.extend((ROOT / folder).glob('*.pt'))
        paths.extend((ROOT / folder).glob('*.joblib'))
        paths.append(ROOT / folder / 'results.json')
    paths += [out / 'manifest.json', out / 'scorer.pt', ROOT / 'protocol.json',
              ROOT / 'entailment-evidence/configuration.json', ROOT / 'student-evidence/configuration.json',
              ROOT / 'reasoner-sft/adapter/adapter_model.safetensors']
    workspace = Path(__file__).resolve().parents[1]
    paths += list((workspace / 'depression_lab').glob('*.py'))
    paths += [p for p in (workspace / 'scripts').glob('*mmpsy*.py')]
    for base in ['D:/speech-cognition-4090/models/multilingual-e5-base',
                 'D:/speech-cognition-4090/models/Qwen2.5-VL-7B-Instruct',
                 'D:/depression-lab/models/Qwen2.5-Omni-3B']:
        paths += list(Path(base).glob('*.safetensors'))
        paths += list(Path(base).glob('*.json'))
    lock = {'selected_model': str(out), 'strongest_simple_baseline': str(ROOT / 'controls/e5.joblib'),
            'criterion': 'selected minus strongest simple baseline participant MAE bootstrap upper95 < 0',
            'bootstrap_iterations': 10000, 'bootstrap_seed': 20260909,
            'test_n': 101, 'calibration_n': 100, 'test_prediction_started': False,
            'old_EATD_test_reused': False, 'hashes': {str(path.resolve()): sha(path) for path in sorted(set(paths))}}
    # Store source snapshots as well as hashes so the model can be reproduced.
    for path in paths:
        if path.suffix == '.py' and path.is_relative_to(workspace):
            dest = ROOT / 'frozen_source' / path.relative_to(workspace)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
    lock_path.write_text(json.dumps(lock, indent=2), encoding='utf8')
    print(json.dumps({'locked': True, 'artifact': str(out), 'baseline': baseline['name'], 'test_read': False}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only', action='store_true')
    main(parser.parse_args().prepare_only)
