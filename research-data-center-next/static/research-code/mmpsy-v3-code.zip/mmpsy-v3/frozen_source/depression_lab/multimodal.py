"""Join paired linguistic and waveform representations for a learned scoring head."""
import hashlib

import numpy as np

from depression_lab.audio_features import load_bundle, pool_bundles
from depression_lab.config import settings
from depression_lab.training import FEATURE_VERSIONS, feature_matrix


def paired_inputs(session):
    """Validate source pairing before inference or saving a new audio turn."""
    turn_ids = [t["id"] for t in session["turns"]]
    if len(turn_ids) != len(set(turn_ids)):
        raise ValueError("发言 ID 必须唯一，避免语音和证据关联歧义。")
    users = {t["id"]: t for t in session["turns"] if t["role"] == "user"}
    audio_rows = [a for a in session.get("audio", []) if a.get("audio_features_id")]
    seen_turns, identifiers, transcripts = set(), [], []
    for row in audio_rows:
        tid = row["turn_id"]
        if tid not in users or tid in seen_turns:
            raise ValueError("语音编码必须对应唯一的用户发言，不能引用助手或重复关联。")
        seen_turns.add(tid)
        identifiers.append(row["audio_features_id"])
        transcripts.append(users[tid]["text"])
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("同一录音不能作为多个独立用户发言重复计分。")
    bundles = [load_bundle(identifier) for identifier in identifiers]
    return users, seen_turns, identifiers, transcripts, bundles


async def attach_multimodal(report, session):
    users, seen_turns, identifiers, transcripts, bundles = paired_inputs(session)
    if not identifiers:
        report["multimodal"] = {"status": "audio_missing", "features_ready": False,
                                "audio_used_for_prediction": False, "reason": "需要原录音；仅有转录无法恢复声音特征。"}
        return report
    record = {"transcript": "\n".join(transcripts), "audio_features_ids": identifiers}
    pooled = pool_bundles(bundles, record["transcript"])
    X = await feature_matrix([record], "text_audio")
    complete_pairing = len(seen_turns) == len(users)
    result = {"status": "awaiting_trained_fusion_head", "features_ready": True,
              "text_dimension": 768, "speech_dimension": 2048, "measurement_dimension": 6,
              "fusion_input_dimension": int(X.shape[1]), "audio_recordings": len(identifiers),
              "paired_user_turns": len(seen_turns), "total_user_turns": len(users),
              "complete_pairing": complete_pairing,
              "feature_version": FEATURE_VERSIONS["text_audio"],
              "feature_fingerprint": hashlib.sha256(np.nan_to_num(X).tobytes()).hexdigest(),
              "audio_source_sha256": pooled["source_sha256"], "acoustics": pooled["acoustics"],
              "audio_used_in_features": True, "audio_used_for_prediction": False,
              "prediction": None, "reason": "原始语音和文本已形成联合输入，仍需独立临床标签训练融合评分头。",
              "evidence_boundary": "波形编码不是已验证的抑郁或情绪标签；PHQ语义映射总分仍单独标记。"}
    artifact_path = settings().get("severity_artifact_path")
    if artifact_path and complete_pairing:
        from depression_lab.predict import load_artifact, predict_record
        artifact = load_artifact(artifact_path)
        if artifact["modality"] != "text_audio":
            result["reason"] = "已配置的评分工件不是语音与文本融合模型。"
        else:
            result["prediction"] = await predict_record(artifact, record)
            result.update(status="fused_prediction", audio_used_for_prediction=True,
                          reason="使用独立标签训练的融合工件；是否具备临床效力仍取决于外部验证。")
            report["trained_severity"] = {"available": True, **result["prediction"]}
    elif artifact_path and not complete_pairing:
        result.update(status="audio_pairing_incomplete", reason="部分用户发言没有对应录音，当前融合工件要求完整配对，暂不生成融合预测。")
    report["multimodal"] = result
    return report
