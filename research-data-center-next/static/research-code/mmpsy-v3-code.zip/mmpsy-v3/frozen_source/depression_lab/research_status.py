"""Bind research acceptance metadata to the exact deployed model weights."""

import json
from pathlib import Path


def load_research_status(artifact, model_info):
    result = {
        "prediction_criterion": "pending",
        "clinical_validated": False,
        "free_chat_validated": False,
    }
    path = Path(artifact) / "research_validation.json"
    if not path.exists():
        return result
    try:
        data = json.loads(path.read_text(encoding="utf8"))
        if (
            data["schema_version"] != "research-acceptance-v1"
            or data["head_sha256"] != model_info["head_sha256"]
            or data["adapter_sha256"] != model_info["adapter_sha256"]
            or type(data["criterion_passed"]) is not bool
            or data["test_n"] != 79
            or data["calibration_n"] != 9
        ):
            raise ValueError("Research metadata does not match this experiment")
    except (KeyError, TypeError, ValueError):
        result["prediction_criterion"] = "metadata_mismatch"
        return result
    result.update(
        prediction_criterion="passed" if data["criterion_passed"] else "failed",
        population="EATD held-out participants",
        test_n=data["test_n"],
        calibration_n=data["calibration_n"],
        report_coverage=data.get("report_coverage"),
    )
    return result
