"""Product adapter: evidence during chat, learned scores on explicit summary."""

from depression_lab.evidence import public_report, validate_evidence
from depression_lab.evidence_report_text import evidence_record_explanation


def from_legacy(report, turns, has_audio=False):
    observations = []
    frequencies = {
        "unknown": "unknown",
        "not_at_all": "none",
        "several_days": "some",
        "more_than_half": "most",
        "nearly_every_day": "daily",
    }
    for item in report.get("items", []):
        for source in item.get("evidence", []):
            observations.append(
                {
                    "concept": item["id"],
                    "turn_id": source["turn_id"],
                    "quote": source["quote"],
                    "presence": item.get("presence", "unknown")
                    if item.get("presence") != "uncertain"
                    else "unknown",
                    "frequency": frequencies.get(item.get("frequency"), "unknown"),
                    "scope": "self",
                    "period": "current" if item.get("period") == "past_two_weeks" else "unknown",
                    "rationale": item.get("rationale", ""),
                    "impact": "unknown",
                }
            )
    bundle = validate_evidence({"observations": observations}, turns)
    result = public_report(bundle, has_audio=has_audio, state="collecting", risk=report.get("risk"))
    result["status"] = "collecting"
    result["provenance"] = report.get("provenance", {})
    result["explanation"] = evidence_record_explanation(bundle)
    result["explanation_status"] = "collecting_evidence_record_not_generated_CoT"
    return result


def input_record(session):
    from depression_lab.raw_audio import resolve

    users = {t["id"]: t for t in session["turns"] if t["role"] == "user"}
    audio, hashes, aligned, spoken_text = [], [], [], []
    for ref in session.get("audio", []):
        if ref.get("raw_audio_id") and ref.get("turn_id") in users:
            path, meta = resolve(session["id"], ref["raw_audio_id"])
            if meta["sha256"] != ref["audio_sha256"]:
                raise ValueError("Stored source hashes disagree")
            if meta["sha256"] in hashes:
                raise ValueError("同一录音不能重复计分")
            hashes.append(meta["sha256"])
            audio.append(str(path))
            turn = users[ref["turn_id"]]
            spoken_text.append(turn["text"])
            segments = turn.get("audio_segments", [])
            original_text = "".join(s.get("text", "") for s in segments)
            if segments and "".join(original_text.split()) != "".join(turn["text"].split()):
                # A corrected transcript has no trustworthy word-level timing.
                # Encode it with its whole recording rather than silently using
                # the stale ASR wording or inventing corrected timestamps.
                aligned.append(
                    {
                        "path": str(path),
                        "start": 0.0,
                        "end": max(s.get("end", 0) for s in segments),
                        "text": turn["text"],
                        "precision": "whole_recording_reviewed_transcript",
                    }
                )
                continue
            for s in segments:
                if isinstance(s.get("start"), (int, float)) and isinstance(s.get("end"), (int, float)):
                    aligned.append(
                        {
                            "path": str(path),
                            "start": s["start"],
                            "end": s["end"],
                            "text": s.get("text", ""),
                            "precision": "asr_segment",
                        }
                    )
    return {
        "id": session["id"],
        "turns": session["turns"],
        "transcript": "\n".join(t["text"] for t in users.values()),
        "audio_paths": audio,
        "audio_sha256": hashes,
        "aligned_segments": aligned,
        "audio_transcript": "\n".join(spoken_text),
    }
