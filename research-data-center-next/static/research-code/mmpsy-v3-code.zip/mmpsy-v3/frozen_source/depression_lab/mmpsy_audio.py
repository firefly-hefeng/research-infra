"""Reproduce the released MMPsy mel recipe from a local 16 kHz waveform.

Author recipe: 2048-point periodic Hann, hop533, 80 Slaney area-normalized
bands, power dB with top_db80, then participant-wide mean/std normalization.
Original MMPsy waveforms are unavailable; this is recipe compatibility, not a
claim of raw-feature identity against the unreleased recordings.
"""
from functools import lru_cache
import numpy as np
from scipy.fft import rfft
from scipy.signal.windows import hann

VERSION = 'mmpsy-mel-recipe-v1'


@lru_cache(maxsize=1)
def mel_bank():
    def hz_to_mel(hz):
        hz = np.asarray(hz, dtype=float)
        return np.where(hz < 1000, hz*3/200, 15 + np.log(np.maximum(hz, 1)/1000)/(np.log(6.4)/27))
    def mel_to_hz(mel):
        return np.where(mel < 15, mel*200/3, 1000*np.exp((np.log(6.4)/27)*(mel-15)))
    edges = mel_to_hz(np.linspace(hz_to_mel(0), hz_to_mel(8000), 82))
    frequencies = np.linspace(0, 8000, 1025)
    lower = (frequencies[None] - edges[:-2, None]) / (edges[1:-1]-edges[:-2])[:, None]
    upper = (edges[2:, None] - frequencies[None]) / (edges[2:]-edges[1:-1])[:, None]
    filters = np.maximum(0, np.minimum(lower, upper))
    filters *= (2/(edges[2:]-edges[:-2]))[:, None]
    return filters.astype(np.float32), edges


def normalized_mel(wave):
    wave = np.asarray(wave, dtype=np.float64)
    if wave.ndim != 1 or len(wave) < 1600 or not np.isfinite(wave).all():
        raise ValueError('Expected at least 0.1 seconds of finite mono 16k audio')
    if np.sqrt(np.mean(wave**2)) < 1e-5:
        raise ValueError('Silent waveform has no usable voice measurements')
    # The released author code feeds PCM16-valued float64 samples to librosa.
    padded = np.pad(wave*32768, (1024, 1024))
    frames = np.lib.stride_tricks.sliding_window_view(padded, 2048)[::533]
    filters, _ = mel_bank()
    window = hann(2048, sym=False)
    pieces = []
    for start in range(0, len(frames), 256):
        power = np.abs(rfft(frames[start:start+256]*window, axis=-1))**2
        pieces.append(filters @ power.T)
    power = np.concatenate(pieces, axis=1)
    db = 10*np.log10(np.maximum(power, 1e-10))
    db = np.maximum(db, db.max()-80)
    scale = db.std()
    if scale < 1e-8:
        raise ValueError('Constant mel matrix cannot be normalized')
    return (db-db.mean())/scale


def measurements(wave, source_sha256):
    mel = normalized_mel(wave)
    values = np.concatenate([mel.mean(1), mel.std(1)]).astype(np.float32)
    _, edges = mel_bank()
    return {'version': VERSION, 'values': values.tolist(), 'source_sha256': list(source_sha256),
            'source': 'retained_original_waveform', 'duration_seconds': len(wave)/16000,
            'frame_count': mel.shape[1], 'band_edges_hz': edges.tolist(),
            'feature_names': [f'mel_band_{i}_{stat}' for stat in ['mean', 'std'] for i in range(80)],
            'measurement_definition': 'participant-normalized log-mel band moments; not symptom severity',
            'unreleased_author_raw_waveform_parity_verified': False}
