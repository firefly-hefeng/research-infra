"""Server-owned waveform features and consistent multi-recording pooling."""
import hashlib
import json
import re

import numpy as np

from depression_lab.config import runtime_dir

AUDIO_VERSION = "xlsr300m-8s-bf16-meanstd-v1"
AUDIO_DIM = 2048
ACOUSTIC_FIELDS = ["duration_seconds", "rms_dbfs", "energy_activity_fraction", "f0_median_hz", "f0_iqr_hz", "transcribed_characters_per_second"]


def feature_id(source_sha256, weights_sha256):
    return hashlib.sha256(f"{AUDIO_VERSION}:{weights_sha256}:{source_sha256}".encode()).hexdigest()


def feature_path(identifier):
    if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{64}", identifier):
        raise ValueError("音频特征引用格式错误")
    directory = runtime_dir() / "audio-features"
    directory.mkdir(exist_ok=True)
    return directory / (identifier + ".json")


def validate_bundle(bundle):
    vector = np.asarray(bundle.get("vector"), dtype=float)
    if (bundle.get("version") != AUDIO_VERSION or vector.shape != (AUDIO_DIM,)
            or not np.isfinite(vector).all() or np.any(vector[1024:] < 0)
            or bundle.get("frames", 0) < 1):
        raise ValueError("音频编码缺失、版本错误或包含无效数值")
    return bundle


def save_bundle(bundle):
    validate_bundle(bundle)
    identifier = feature_id(bundle["source_sha256"], bundle["weights_sha256"])
    path = feature_path(identifier)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(bundle, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temp.replace(path)
    return identifier


def load_bundle(identifier):
    path = feature_path(identifier)
    if not path.exists():
        raise ValueError("音频特征不存在，请重新导入对应录音。")
    bundle = validate_bundle(json.loads(path.read_text(encoding="utf-8")))
    if feature_id(bundle["source_sha256"], bundle["weights_sha256"]) != identifier:
        raise ValueError("音频特征来源标识不一致")
    return bundle


def summary(bundle):
    return {k: bundle[k] for k in ("version", "model", "source_sha256", "weights_sha256", "frames", "duration_seconds", "acoustics")}


def pool_bundles(bundles, transcript=""):
    if not bundles:
        raise ValueError("融合预测需要真实录音的编码")
    for bundle in bundles:
        validate_bundle(bundle)
    if len({b["weights_sha256"] for b in bundles}) != 1:
        raise ValueError("不能混合不同权重版本的语音编码")
    vectors = np.asarray([b["vector"] for b in bundles], dtype=float)
    weights = np.asarray([b["frames"] for b in bundles], dtype=float)
    weights /= weights.sum()
    means, stds = vectors[:, :1024], vectors[:, 1024:]
    mean = weights @ means
    variance = weights @ (stds ** 2 + means ** 2) - mean ** 2
    pooled = np.concatenate([mean, np.sqrt(np.maximum(variance, 0))])
    durations = np.asarray([b["duration_seconds"] for b in bundles], dtype=float)
    total_duration = float(durations.sum())
    if total_duration <= 0:
        raise ValueError("录音时长无效")
    acoustic = {"duration_seconds": total_duration}
    for field in ACOUSTIC_FIELDS[1:-1]:
        values = np.asarray([b["acoustics"].get(field) if b["acoustics"].get(field) is not None else np.nan for b in bundles])
        valid = np.isfinite(values)
        if not valid.any():
            acoustic[field] = None
        elif field == "rms_dbfs":
            power = np.average(10 ** (values[valid] / 10), weights=durations[valid])
            acoustic[field] = float(10 * np.log10(max(power, 1e-18)))
        else:
            acoustic[field] = float(np.average(values[valid], weights=durations[valid]))
    acoustic["transcribed_characters_per_second"] = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", transcript)) / total_duration if transcript else None
    return {"vector": pooled.tolist(), "acoustics": acoustic, "recordings": len(bundles),
            "frames": sum(b["frames"] for b in bundles), "weights_sha256": bundles[0]["weights_sha256"],
            "source_sha256": [b["source_sha256"] for b in bundles], "version": AUDIO_VERSION}


def bundles_from_record(record):
    identifiers = record.get("audio_features_ids") or ([record["audio_features_id"]] if record.get("audio_features_id") else [])
    if not identifiers:
        raise ValueError("需要 audio_features_ids，或先用 prepare_audio.py 从原录音生成编码。")
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("同一份音频编码不能在一次评估中重复计入")
    return [load_bundle(identifier) for identifier in identifiers]
