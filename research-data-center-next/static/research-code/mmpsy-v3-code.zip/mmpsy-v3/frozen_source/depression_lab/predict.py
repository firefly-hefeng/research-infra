"""Continuous severity inference from a trusted, separately evaluated local artifact."""
import argparse
import asyncio
import json
from pathlib import Path

import joblib
import numpy as np

from depression_lab.training import FEATURE_VERSIONS, feature_matrix
from depression_lab.audio_features import bundles_from_record


def load_artifact(path):
    # joblib uses pickle: only load artifacts created locally by trusted training code.
    artifact = joblib.load(Path(path))
    required = {"model", "scale", "item_ids", "maxima", "q", "coverage", "modality", "validation_status"}
    if (not required.issubset(artifact) or artifact.get("modality") not in FEATURE_VERSIONS
            or artifact.get("feature_version") != FEATURE_VERSIONS[artifact.get("modality")]):
        raise ValueError("模型工件缺少元数据或特征版本不兼容")
    if artifact["validation_status"] == "synthetic_software_check":
        raise ValueError("合成软件测试模型不能用于个人严重程度预测")
    return artifact


def predict_features(artifact, X):
    pipeline = artifact["model"]
    raw_items = pipeline.predict(X)
    items = np.clip(raw_items, 0, artifact["maxima"])
    contributions = {}
    if "features" in pipeline.named_steps and "ridge" in pipeline.named_steps:
        features, ridge = pipeline.named_steps["features"], pipeline.named_steps["ridge"]
        Z = features.transform(X)
        for name, section in features.output_indices_.items():
            if name != "remainder" and section.stop > section.start:
                contributions[name] = Z[:, section] @ ridge.coef_[:, section].T
    outputs = []
    for index, values in enumerate(items):
        total = float(values.sum())
        outputs.append({"scale": artifact["scale"], "score_kind": "supervised_continuous_estimate",
                        "total_score": total,
                        "item_scores": {key: float(v) for key, v in zip(artifact["item_ids"], values)},
                        "prediction_interval": [max(0.0, total - artifact["q"]),
                                                min(float(sum(artifact["maxima"])), total + artifact["q"])],
                        "nominal_coverage": artifact["coverage"],
                        "validation_status": artifact["validation_status"],
                        "clinical_use_validated": False,
                        "interval_assumptions": artifact.get("interval_assumptions"),
                        "treatment_decision": None})
        if contributions:
            outputs[-1]["model_contributions"] = {
                "interpretation": "exact_linear_model_contributions_not_causal_or_clinical_explanations",
                "intercept_total": float(pipeline.named_steps["ridge"].intercept_.sum()),
                "by_modality_total": {name: float(values[index].sum()) for name, values in contributions.items()},
                "by_modality_items": {name: values[index].tolist() for name, values in contributions.items()},
                "range_clipping_adjustment": float(items[index].sum() - raw_items[index].sum()),
            }
    return outputs


async def predict_record(artifact, record):
    text = record.get("transcript")
    if artifact["modality"] != "audio" and (not isinstance(text, str) or not text.strip() or len(text) > 22000):
        raise ValueError("transcript需要1–22000字的真实访谈输入")
    if artifact["modality"] != "text":
        bundles = bundles_from_record(record)
        if {b["weights_sha256"] for b in bundles} != {artifact.get("audio_weights_sha256")}:
            raise ValueError("预测音频编码器与训练工件的权重版本不一致")
    X = await feature_matrix([record], artifact["modality"])
    result = predict_features(artifact, X)[0]
    result["modality"] = artifact["modality"]
    result["audio_used_for_prediction"] = artifact["modality"] != "text"
    result["feature_version"] = artifact["feature_version"]
    return result


async def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", help="Trusted local model.joblib; never load unknown downloaded pickle files")
    parser.add_argument("input", help="JSON containing transcript and server audio_features_ids for audio modes; no labels needed")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    artifact = load_artifact(args.artifact)
    record = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
    result = await predict_record(artifact, record)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(cli())
