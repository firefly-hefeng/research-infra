"""Versioned score-only runtime: source evidence + measured acoustics -> 101 bins."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from depression_lab.compact_evidence import vector


class MMPsyScorer:
    def __init__(self, artifact):
        self.path = Path(artifact).resolve()
        self.manifest = json.loads((self.path / 'manifest.json').read_text(encoding='utf8'))
        if self.manifest['engine'] != 'mmpsy-evidence-v2':
            raise ValueError('Unsupported scoring model version')
        weights = self.path / 'scorer.pt'
        self.weights_sha256 = hashlib.sha256(weights.read_bytes()).hexdigest()
        if self.weights_sha256 != self.manifest['scorer_sha256']:
            raise ValueError('Scorer hash mismatch')
        state = torch.load(weights, weights_only=True, map_location='cpu')
        self.heads = nn.ModuleList([nn.Sequential(nn.Linear(177, 128), nn.GELU(), nn.Linear(128, 101)) for _ in range(3)])
        for head, params in zip(self.heads, state['heads'], strict=True):
            head.load_state_dict(params)
        self.heads.eval().requires_grad_(False)
        self.beta = state['beta']
        self.mean = np.array(self.manifest['audio_normalizer']['mean'], dtype=np.float32)
        self.scale = np.array(self.manifest['audio_normalizer']['scale'], dtype=np.float32)

    def predict(self, evidence, acoustic_values):
        if len(acoustic_values) != 160 or not np.isfinite(acoustic_values).all():
            raise ValueError('Need 160 finite source-measured acoustic values')
        features, slots, conflicts = vector(evidence)
        x = torch.tensor(features)[None]
        a = torch.tensor((np.asarray(acoustic_values, dtype=np.float32)-self.mean)/self.scale/np.sqrt(160), dtype=torch.float32)[None]
        with torch.no_grad():
            p = torch.stack([head(x).softmax(-1) for head in self.heads]).mean(0)
            grid = torch.arange(101)
            p = (p.clamp_min(1e-8).log() + (a@self.beta)[:, None]*(grid-50)/100).softmax(-1)[0]
        distribution = p.tolist()
        return {'distribution': distribution, 'score_0_100': sum(i*v for i, v in enumerate(distribution)),
                'slots': slots, 'conflicts': conflicts, 'input_dimension': len(features)+len(acoustic_values),
                'has_latent_bypass': False}
