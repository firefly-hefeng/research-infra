"""Measured acoustic descriptors; never a depression classifier."""
import io
import math
import re

import numpy as np
from scipy.signal import resample_poly


def decode_audio(data: bytes, target_sr: int = 16000, max_seconds: int = 1200) -> np.ndarray:
    import soundfile as sf
    try:
        with sf.SoundFile(io.BytesIO(data)) as f:
            if len(f) / f.samplerate > max_seconds:
                raise ValueError("录音超过时长限制")
            audio = f.read(dtype="float32", always_2d=True).mean(axis=1)
            sr = f.samplerate
    except (RuntimeError, sf.LibsndfileError):
        import av
        chunks = []
        size = 0
        with av.open(io.BytesIO(data)) as container:
            resampler = av.AudioResampler(format="fltp", layout="mono", rate=target_sr)
            for frame in container.decode(audio=0):
                for out in resampler.resample(frame):
                    values = out.to_ndarray().reshape(-1)
                    size += len(values)
                    if size > max_seconds * target_sr:
                        raise ValueError("录音超过时长限制")
                    chunks.append(values)
            for out in resampler.resample(None):
                chunks.append(out.to_ndarray().reshape(-1))
        audio = np.concatenate(chunks) if chunks else np.array([], dtype=np.float32)
        sr = target_sr
    if sr != target_sr:
        divisor = math.gcd(sr, target_sr)
        audio = resample_poly(audio, target_sr // divisor, sr // divisor).astype(np.float32)
    if not len(audio) or not np.isfinite(audio).all():
        raise ValueError("没有可解码的有效音频")
    if len(audio) > max_seconds * target_sr:
        raise ValueError("录音超过时长限制")
    return audio


def acoustic_features(audio: np.ndarray, sr: int = 16000, transcript: str = "") -> dict:
    audio = np.asarray(audio, dtype=np.float32)
    duration = len(audio) / sr
    rms = float(np.sqrt(np.mean(audio ** 2)))
    peak = float(np.max(np.abs(audio)))
    frame_size = int(0.03 * sr)
    hop = int(0.01 * sr)
    if len(audio) < frame_size:
        return {"duration_seconds": duration, "quality": "too_short", "usable_for_asr": False,
                "depression_score_contribution": None, "warnings": ["录音过短"]}
    frames = np.lib.stride_tricks.sliding_window_view(audio, frame_size)[::hop]
    frame_rms = np.sqrt(np.mean(frames ** 2, axis=1))
    # Energy activity is a proxy, not a clinical or speaker diarization VAD.
    threshold = max(float(np.percentile(frame_rms, 20)) * 2.5, 0.003)
    active = frame_rms > threshold
    activity = float(active.mean())
    pitches = []
    lo, hi = int(sr / 400), int(sr / 65)
    for frame in frames[::5]:
        if np.sqrt(np.mean(frame ** 2)) < threshold:
            continue
        x = (frame - frame.mean()) * np.hanning(frame_size)
        ac = np.correlate(x, x, mode="full")[frame_size - 1:]
        if ac[0] <= 1e-9:
            continue
        lag = lo + int(np.argmax(ac[lo:hi]))
        if ac[lag] / ac[0] >= 0.55:
            pitches.append(sr / lag)
    warnings = ["响度受麦克风增益影响；活动比例是能量阈值估计；音高可能存在倍频误差。"]
    if duration < 5:
        warnings.append("音频较短，韵律统计仅供参考。")
    if activity < 0.05:
        warnings.append("未检测到足够的语音活动，可能是静音或音量过低。")
    clipped = float(np.mean(np.abs(audio) >= 0.999))
    if clipped > 0.01:
        warnings.append("存在明显削波。")
    if len(pitches) < 5:
        warnings.append("没有足够的有声帧用于估计音高。")
    chars = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", transcript))
    return {
        "duration_seconds": round(duration, 3), "rms_dbfs": round(20 * math.log10(max(rms, 1e-9)), 2),
        "peak": round(peak, 5), "energy_activity_fraction": round(activity, 4),
        "clipping_fraction": round(clipped, 5),
        "f0_median_hz": round(float(np.median(pitches)), 2) if len(pitches) >= 5 else None,
        "f0_iqr_hz": round(float(np.percentile(pitches, 75) - np.percentile(pitches, 25)), 2) if len(pitches) >= 5 else None,
        "transcribed_characters_per_second": round(chars / duration, 3) if transcript else None,
        "quality": "insufficient_activity" if activity < 0.05 else "measured",
        "usable_for_asr": bool(duration >= 0.5 and peak > 0.003 and rms > 0.0005),
        "depression_score_contribution": None, "warnings": warnings,
        "method": "energy-threshold + autocorrelation; descriptive, not clinical validation",
    }
