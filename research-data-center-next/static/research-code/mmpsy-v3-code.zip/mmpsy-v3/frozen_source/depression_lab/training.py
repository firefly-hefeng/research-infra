"""Reproducible, separate-scale supervised regression baseline.

Training/dev/calibration/test are isolated. No clinical labels are generated here.
"""
import argparse
import asyncio
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import joblib
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.compose import ColumnTransformer

from depression_lab.config import runtime_dir
from depression_lab.dataset import load_manifest, text_hash
from depression_lab.scales import SCALES
from depression_lab.service import worker_call
from depression_lab.audio_features import AUDIO_VERSION, ACOUSTIC_FIELDS, bundles_from_record, pool_bundles

FEATURE_VERSIONS = {"text": "e5-base-chunk650-v1", "audio": AUDIO_VERSION + "+acoustic5-v2",
                    "text_audio": "e5-base-chunk650-v1+" + AUDIO_VERSION + "+acoustic6-v2"}
FEATURE_BLOCKS = {"text": [("text", 768)], "audio": [("speech", 2048), ("acoustics", 5)],
                  "text_audio": [("text", 768), ("speech", 2048), ("acoustics", 6)]}


async def feature_matrix(records, modality="text", cache_dir=None):
    if modality not in FEATURE_VERSIONS:
        raise ValueError("未知模态")
    cache_dir = Path(cache_dir or runtime_dir() / "feature-cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    vectors = []
    for row in records:
        vector = []
        # Fixed extractor version and input hash are part of the cache key.
        if modality != "audio":
            cache = cache_dir / (text_hash("e5-base-chunk650-v1:" + row["transcript"]) + ".json")
            if cache.exists():
                embedding = json.loads(cache.read_text())["vector"]
            else:
                result = await worker_call("/embed", {"texts": [row["transcript"]]})
                embedding = result["vectors"][0]
                cache.write_text(json.dumps({"model": result["model"], "vector": embedding}), encoding="utf-8")
            if len(embedding) != 768 or not np.isfinite(embedding).all():
                raise ValueError("文本编码维度或数值错误")
            vector.extend(embedding)
        if modality in {"audio", "text_audio"}:
            pooled = pool_bundles(bundles_from_record(row), "" if modality == "audio" else row["transcript"])
            vector.extend(pooled["vector"])
            fields = ACOUSTIC_FIELDS[:-1] if modality == "audio" else ACOUSTIC_FIELDS
            acoustic = pooled["acoustics"]
            vector.extend(float(acoustic[k]) if acoustic.get(k) is not None else np.nan for k in fields)
        vectors.append(vector)
    return np.asarray(vectors, dtype=np.float64)


def metrics(y, pred, participant_ids=None):
    error = pred.sum(axis=1) - y.sum(axis=1)
    output = {"records": len(y), "total_mae": float(np.abs(error).mean()),
              "total_rmse": float(np.sqrt((error ** 2).mean())), "total_bias": float(error.mean()),
              "item_mae": np.abs(pred - y).mean(axis=0).tolist()}
    if participant_ids:
        grouped = {}
        for person, e in zip(participant_ids, error):
            grouped.setdefault(person, []).append(abs(float(e)))
        person_errors = np.array([np.mean(v) for v in grouped.values()])
        rng = np.random.default_rng(20260908)
        draws = rng.choice(person_errors, size=(1000, len(person_errors)), replace=True).mean(axis=1)
        output["participants"] = len(grouped)
        output["participant_mean_mae"] = float(person_errors.mean())
        output["participant_bootstrap_mae_95_ci"] = np.quantile(draws, [0.025, 0.975]).tolist()
    return output


def conformal_quantile(residuals, coverage=0.9):
    residuals = np.asarray(residuals, dtype=float)
    if not 0 < coverage < 1 or not len(residuals) or not np.isfinite(residuals).all():
        raise ValueError("校准残差或覆盖率无效")
    rank = math.ceil((len(residuals) + 1) * coverage)
    if rank > len(residuals):
        raise ValueError("校准样本不足以构造该覆盖率的有限 split-conformal 区间")
    return float(np.sort(residuals)[rank - 1])


def unit_block(X):
    return X / np.sqrt(max(1, X.shape[1]))


def block_preprocessor(blocks):
    branches, start = [], 0
    for name, dimension in blocks:
        pipeline = Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True)),
                             ("scaler", StandardScaler()), ("block_scale", FunctionTransformer(unit_block))])
        branches.append((name, pipeline, list(range(start, start + dimension))))
        start += dimension
    return ColumnTransformer(branches, remainder="drop")


def fit_regression(records, X, coverage=0.9, feature_blocks=None):
    scale = records[0]["scale"]
    item_ids, maxima = SCALES[scale]
    y = np.array([r["item_scores"] for r in records], dtype=float)
    idx = {split: np.array([i for i, r in enumerate(records) if r["split"] == split], dtype=int)
           for split in ("train", "dev", "calibration", "test")}
    if any(len(v) == 0 for v in idx.values()):
        raise ValueError("需要 train/dev/calibration/test 四个独立分区")
    train_people = Counter(records[i]["participant_id"] for i in idx["train"])
    weights = np.array([1 / train_people[records[i]["participant_id"]] for i in idx["train"]])
    weights *= len(weights) / weights.sum()
    candidates = []
    for alpha in (0.1, 1.0, 10.0, 100.0):
        model = Pipeline([("features", block_preprocessor(feature_blocks or [("all", X.shape[1])])),
                          ("ridge", Ridge(alpha=alpha))])
        model.fit(X[idx["train"]], y[idx["train"]], ridge__sample_weight=weights)
        pred = np.clip(model.predict(X[idx["dev"]]), 0, maxima)
        dev_mae = float(np.abs(pred.sum(1) - y[idx["dev"]].sum(1)).mean())
        candidates.append((dev_mae, alpha, model))
    dev_mae, alpha, model = min(candidates, key=lambda t: (t[0], t[1]))
    cal_pred = np.clip(model.predict(X[idx["calibration"]]), 0, maxima)
    cal_resid = np.abs(cal_pred.sum(1) - y[idx["calibration"]].sum(1))
    q = conformal_quantile(cal_resid, coverage)
    test_pred = np.clip(model.predict(X[idx["test"]]), 0, maxima)
    truth = y[idx["test"]].sum(1)
    lower = np.maximum(0, test_pred.sum(1) - q)
    upper = np.minimum(sum(maxima), test_pred.sum(1) + q)
    evaluation = metrics(y[idx["test"]], test_pred, [records[i]["participant_id"] for i in idx["test"]])
    evaluation.update({"observed_interval_coverage": float(((truth >= lower) & (truth <= upper)).mean()),
                       "mean_interval_width": float((upper - lower).mean()), "nominal_coverage": coverage,
                       "calibration_participants": len(idx["calibration"])})
    # Fixed training-mean predictor provides an essential non-LLM baseline.
    mean_pred = np.tile(np.average(y[idx["train"]], axis=0, weights=weights), (len(idx["test"]), 1))
    return {"model": model, "scale": scale, "item_ids": item_ids, "maxima": maxima, "q": q,
            "coverage": coverage, "selected_alpha": alpha, "dev_mae": dev_mae,
            "test_metrics": evaluation, "training_mean_baseline": metrics(y[idx["test"]], mean_pred),
            "validation_status": "synthetic_software_check" if any(r.get("synthetic") for r in records) else "retrospective_research",
            "clinical_use_validated": False,
            "interval_assumptions": "exchangeable independent calibration participants and target population; no subgroup or drift guarantee"}


async def train(args):
    records, audit = load_manifest(args.manifest, allow_synthetic=args.allow_synthetic)
    out = Path(args.output)
    if out.exists() and any(out.iterdir()):
        raise ValueError("输出目录非空，请为每次实验指定新的目录。")
    signatures, seen_audio = set(), {}
    if args.modality != "text":
        for row in records:
            for bundle in bundles_from_record(row):
                signatures.add(bundle["weights_sha256"])
                source = bundle["source_sha256"]
                if source in seen_audio and seen_audio[source] != row["split"]:
                    raise ValueError("实际波形 SHA256 跨数据分区，存在泄漏")
                seen_audio[source] = row["split"]
        if len(signatures) != 1:
            raise ValueError("一次训练必须使用同一版本语音编码器")
    X = await feature_matrix(records, args.modality)
    artifact = fit_regression(records, X, args.coverage, FEATURE_BLOCKS[args.modality])
    artifact["modality"] = args.modality
    artifact["dataset_audit"] = audit
    artifact["feature_version"] = FEATURE_VERSIONS[args.modality]
    artifact["feature_blocks"] = FEATURE_BLOCKS[args.modality]
    artifact["audio_weights_sha256"] = next(iter(signatures)) if signatures else None
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, out / "model.joblib")
    report = {k: v for k, v in artifact.items() if k != "model"}
    report["artifact_sha256"] = hashlib.sha256((out / "model.joblib").read_bytes()).hexdigest()
    (out / "evaluation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest")
    parser.add_argument("--output", required=True)
    parser.add_argument("--modality", choices=list(FEATURE_VERSIONS), default="text_audio")
    parser.add_argument("--coverage", type=float, default=0.9)
    parser.add_argument("--allow-synthetic", action="store_true")
    asyncio.run(train(parser.parse_args()))


if __name__ == "__main__":
    cli()
