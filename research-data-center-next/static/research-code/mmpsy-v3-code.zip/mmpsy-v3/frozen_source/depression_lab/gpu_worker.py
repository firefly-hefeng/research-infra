"""Small local GPU service. Reuses a verified CUDA interpreter read-only."""
import argparse
import gc
import hashlib
import json
import os
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from depression_lab.config import runtime_dir, settings  # noqa: E402
from depression_lab.gpu_reservation import active_training  # noqa: E402

vendor = runtime_dir().parent / "worker-packages"
if vendor.exists():
    sys.path.insert(0, str(vendor))
# Transformers caches optional backend availability at its first import. Omni's
# processor dependencies must be visible before ASR/chat import Transformers.
training_packages = runtime_dir().parent / "training-packages"
if training_packages.exists():
    sys.path.insert(0, str(training_packages))
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"


class Engine:
    def __init__(self):
        self.lock = threading.Lock()
        self.text_model = self.tokenizer = self.asr = self.asr_processor = None
        self.embed_model = self.embed_tokenizer = None
        self.speech_encoder = None
        self.unified = None
        self.state = "idle"
        self.last_error = None

    def load_text(self):
        if self.text_model is not None:
            return
        if self.unified is not None:
            self.unload()
        self.state = "loading_text"
        import torch
        from transformers import AutoTokenizer, Qwen2_5_VLForConditionalGeneration
        torch.set_num_threads(4)
        if not torch.cuda.is_available():
            raise RuntimeError("GPU worker requires a CUDA-enabled PyTorch environment")
        free, _ = torch.cuda.mem_get_info()
        if free < 18 * 1024 ** 3:
            raise RuntimeError("空闲显存不足 18 GB；请结束不需要的显卡任务后重试。不会停止其他进程。")
        path = settings()["text_model_path"]
        self.tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
        self.text_model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            path, torch_dtype=torch.bfloat16, attn_implementation="sdpa", local_files_only=True,
            low_cpu_mem_usage=False,
        ).to("cuda").eval()
        self.state = "ready"

    def generate(self, request: dict):
        import torch
        self.load_text()
        self.state = "generating"
        messages = request["messages"]
        prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(prompt, return_tensors="pt").to("cuda")
        if inputs["input_ids"].shape[1] > 10000:
            raise ValueError("对话超过当前上下文上限，请导出后开始新的会话。")
        started = time.perf_counter()
        with torch.inference_mode():
            output = self.text_model.generate(**inputs, max_new_tokens=min(request.get("max_new_tokens", 2200), 3500),
                                             do_sample=False, use_cache=True)
        generated = output[0, inputs["input_ids"].shape[1]:]
        result = {"text": self.tokenizer.decode(generated, skip_special_tokens=True),
                  "tokens": len(generated), "seconds": round(time.perf_counter() - started, 3),
                  "model": "local/Qwen2.5-VL-7B-Instruct", "clinical_finetuned": False}
        self.state = "ready"
        return result

    def transcribe(self, request: dict):
        import torch
        from transformers import WhisperForConditionalGeneration, WhisperProcessor
        from depression_lab.audio import acoustic_features, decode_audio
        if self.unified is not None:
            self.unload()
        path = Path(request["path"]).resolve()
        upload_root = (runtime_dir() / "uploads").resolve()
        if not path.is_relative_to(upload_root) or not path.is_file():
            raise ValueError("Invalid upload path")
        self.state = "transcribing"
        raw_audio = path.read_bytes()
        audio = decode_audio(raw_audio, max_seconds=settings()["max_audio_seconds"])
        measured = acoustic_features(audio)
        if not measured["usable_for_asr"]:
            self.state = "ready" if self.text_model else "idle"
            return {"text": "", "segments": [], "acoustics": measured, "model": "Whisper-large-v3-turbo", "needs_review": True}
        if self.asr is None:
            model_path = settings()["asr_model_path"]
            self.asr_processor = WhisperProcessor.from_pretrained(model_path, local_files_only=True)
            self.asr = WhisperForConditionalGeneration.from_pretrained(
                model_path, torch_dtype=torch.float16, local_files_only=True, low_cpu_mem_usage=False
            ).to("cuda").eval()
        segments = []
        chunk_samples = 28 * 16000
        for start in range(0, len(audio), chunk_samples):
            chunk = audio[start:start + chunk_samples]
            # Do not run the decoder on silent chunks: Whisper can hallucinate on silence.
            if float((chunk ** 2).mean()) < 2.5e-7:
                continue
            inputs = self.asr_processor(chunk, sampling_rate=16000, return_tensors="pt")
            with torch.inference_mode():
                tokens = self.asr.generate(inputs.input_features.to("cuda", dtype=torch.float16),
                                           language="zh", task="transcribe", max_new_tokens=440,
                                           condition_on_prev_tokens=False)
            text = self.asr_processor.batch_decode(tokens, skip_special_tokens=True)[0].strip()
            if text:
                segments.append({"start": round(start / 16000, 2), "end": round((start + len(chunk)) / 16000, 2), "text": text})
        transcript = "".join(x["text"] for x in segments)
        measured = acoustic_features(audio, transcript=transcript)
        encoded = self.encode_waveform(audio, hashlib.sha256(raw_audio).hexdigest(), measured)
        self.state = "ready" if self.text_model else "idle"
        return {"text": transcript, "segments": segments, "acoustics": measured,
                "audio_features_id": encoded["audio_features_id"],
                "audio_encoding": {"dimension": 2048, "version": encoded["bundle"]["version"],
                                   "model": encoded["bundle"]["model"], "source": "original_waveform",
                                   "cache_hit": encoded["cache_hit"]},
                "model": "local/Whisper-large-v3-turbo", "needs_review": True,
                "timestamp_precision": "28-second chunk boundaries, not word alignment"}

    def encode_waveform(self, audio, source_sha256, measured):
        from depression_lab.speech_encoder import SpeechEncoder
        self.state = "encoding_audio"
        if self.speech_encoder is None:
            self.speech_encoder = SpeechEncoder()
        return self.speech_encoder.encode(audio, source_sha256, measured)

    def encode_audio(self, request):
        from depression_lab.audio import acoustic_features, decode_audio
        from depression_lab.audio_features import summary
        path = Path(request["path"]).resolve()
        if not path.is_relative_to((runtime_dir() / "uploads").resolve()) or not path.is_file():
            raise ValueError("Invalid upload path")
        raw = path.read_bytes()
        audio = decode_audio(raw, max_seconds=settings()["max_audio_seconds"])
        result = self.encode_waveform(audio, hashlib.sha256(raw).hexdigest(), acoustic_features(audio))
        self.state = "ready" if self.text_model else "idle"
        return {"audio_features_id": result["audio_features_id"], "audio_encoding": summary(result["bundle"])}

    def embed(self, request: dict):
        import torch
        from transformers import AutoModel, AutoTokenizer
        texts = request.get("texts", [])
        if not texts or len(texts) > 64:
            raise ValueError("Provide 1–64 texts")
        if self.embed_model is None:
            path = settings()["embedding_model_path"]
            self.embed_tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
            # CPU keeps the main GPU available; these compact representations are cached by callers.
            self.embed_model = AutoModel.from_pretrained(path, local_files_only=True).eval()
        vectors = []
        for text in texts:
            chunks = [text[i:i + 650] for i in range(0, len(text), 650)] or [""]
            encoded = self.embed_tokenizer(["passage: " + c for c in chunks], padding=True,
                                          truncation=True, max_length=512, return_tensors="pt")
            with torch.inference_mode():
                hidden = self.embed_model(**encoded).last_hidden_state
                mask = encoded["attention_mask"].unsqueeze(-1)
                pooled = (hidden * mask).sum(1) / mask.sum(1).clamp(min=1)
                vector = torch.nn.functional.normalize(pooled.mean(0), dim=0)
            vectors.append(vector.tolist())
        return {"vectors": vectors, "model": "local/multilingual-e5-base", "dimension": len(vectors[0])}

    def unload(self):
        import torch
        self.text_model = self.tokenizer = self.asr = self.asr_processor = None
        self.embed_model = self.embed_tokenizer = None
        self.speech_encoder = None
        self.unified = None
        gc.collect()
        torch.cuda.empty_cache()
        self.state = "idle"
        return {"unloaded": True}

    def unified_score(self, request):
        artifact = settings().get("unified_artifact_path")
        if not artifact:
            raise ValueError("尚未配置统一评分模型")
        if self.unified is None:
            self.unload()
            self.state = "loading_unified"
            packages = runtime_dir().parent / "training-packages"
            if packages.exists():
                sys.path.insert(0, str(packages))
            manifest_path = Path(artifact) / "manifest.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf8")) if manifest_path.exists() else {}
            if manifest.get("engine") == "mmpsy-evidence-v2":
                from depression_lab.mmpsy_runtime import MMPsyRuntime
                self.unified = MMPsyRuntime(artifact)
            else:
                from depression_lab.unified_runtime import UnifiedRuntime
                self.unified = UnifiedRuntime(artifact)
        self.state = "scoring"
        record = request["record"]
        # Only session-owned audio resolved by the API is accepted by this worker.
        owned = (runtime_dir() / "session-audio").resolve()
        for path in record.get("audio_paths", []):
            if not Path(path).resolve().is_relative_to(owned):
                raise ValueError("Invalid session audio path")
        result = self.unified.predict(record)
        self.state = "ready"
        return result


engine = Engine()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Never write transcript or request contents to logs.
        print(f"worker {self.command} {self.path} {args[1] if len(args) > 1 else ''}", flush=True)

    def respond(self, code: int, value: dict):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        token_path = runtime_dir() / "worker.token"
        return token_path.exists() and self.headers.get("Authorization") == "Bearer " + token_path.read_text().strip()

    def do_GET(self):
        if self.path != "/health":
            return self.respond(404, {"error": "not_found"})
        self.respond(200, {"status": "training" if active_training() else engine.state, "text_loaded": engine.text_model is not None,
                           "asr_loaded": engine.asr is not None, "unified_loaded": engine.unified is not None,
                           "last_error": engine.last_error})

    def do_POST(self):
        if not self.authorized():
            return self.respond(401, {"error": "unauthorized"})
        if active_training() and self.path != "/unload":
            return self.respond(409, {"error": "本项目正在使用显卡训练或评测，完成后恢复聊天与评分。"})
        length = int(self.headers.get("Content-Length", 0))
        if length < 1 or length > 3_000_000:
            return self.respond(413, {"error": "request_too_large"})
        if not engine.lock.acquire(blocking=False):
            return self.respond(409, {"error": "GPU 正在处理另一项任务，请稍后重试。"})
        try:
            request = json.loads(self.rfile.read(length))
            operations = {"/generate": engine.generate, "/transcribe": engine.transcribe,
                          "/unified-score": engine.unified_score,
                          "/embed": engine.embed, "/encode-audio": engine.encode_audio, "/unload": lambda _: engine.unload(),
                          "/warmup": lambda _: (engine.load_text() or {"ready": True})}
            if self.path not in operations:
                return self.respond(404, {"error": "not_found"})
            result = operations[self.path](request)
            engine.last_error = None
            self.respond(200, result)
        except Exception as exc:
            engine.last_error = type(exc).__name__
            engine.state = "error"
            traceback.print_exc()
            self.respond(500, {"error": str(exc)[:500], "type": type(exc).__name__})
        finally:
            engine.lock.release()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=settings()["worker_port"])
    args = parser.parse_args()
    print(f"Local GPU worker starting on 127.0.0.1:{args.port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
