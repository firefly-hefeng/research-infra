"""Conservative display of the selected evidence when trained prose is unavailable."""

from depression_lab.evidence import cot_target


def evidence_record_explanation(bundle, slots=None):
    value = cot_target(bundle, slots)
    wording = {
        "unknown": "现有证据不足以确定该症状状态。",
        "present": "所列原话被选为该症状的支持证据；未说明的信息保持未知。",
        "absent": "所列原话被选为该症状的否认证据；未说明的信息保持未知。",
    }
    for observation in value["observations"]:
        observation["explanation"] = wording[observation["presence"]]
    return value
