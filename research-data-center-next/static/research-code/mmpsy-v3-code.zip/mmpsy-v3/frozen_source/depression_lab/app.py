import os
import uuid
from pathlib import Path

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from depression_lab import storage
from depression_lab.config import ROOT, runtime_dir, settings
from depression_lab.schemas import AnalyzeRequest, ChatRequest, SessionCreate, Turn
from depression_lab.service import analyze, worker_call
from depression_lab.audio_features import load_bundle
from depression_lab.multimodal import attach_multimodal, paired_inputs
from depression_lab import raw_audio
from depression_lab.unified_service import from_legacy, input_record

app = FastAPI(title="语声 · 本地症状评分研究", version="0.1.0")
busy_sessions: set[str] = set()


@app.middleware("http")
async def local_origin_only(request: Request, call_next):
    # The local service is not intended for LAN/cloud exposure or arbitrary website requests.
    if request.url.hostname not in {"127.0.0.1", "localhost", "testserver"}:
        return JSONResponse(status_code=403, content={"detail": "仅允许本机访问"})
    origin = request.headers.get("origin")
    allowed = {f"http://127.0.0.1:{settings()['port']}", f"http://localhost:{settings()['port']}"}
    if origin and origin not in allowed:
        return JSONResponse(status_code=403, content={"detail": "不允许跨站请求"})
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; media-src 'self' blob:; frame-ancestors 'none'"
    return response


@app.exception_handler(RuntimeError)
async def runtime_error(request, exc):
    return JSONResponse(status_code=503, content={"detail": str(exc)[:500]})


@app.exception_handler(ValueError)
async def invalid_input(request, exc):
    return JSONResponse(status_code=400, content={"detail": str(exc)[:500]})


@app.exception_handler(httpx.HTTPError)
async def connection_error(request, exc):
    return JSONResponse(status_code=503, content={"detail": "本地 GPU 服务无法连接或超时，请检查 start.ps1 和模型状态。"})


@app.get("/")
async def index():
    return FileResponse(ROOT / "web" / "index.html")


@app.get("/api/health")
async def health():
    gpu = {"status": "offline"}
    try:
        async with httpx.AsyncClient(timeout=2, trust_env=False) as client:
            response = await client.get(settings()["worker_url"] + "/health")
            gpu = response.json()
    except (httpx.HTTPError, ValueError):
        pass
    artifact = settings().get("unified_artifact_path")
    weights_present = bool(artifact) and (Path(artifact) / "heads.pt").is_file() and (Path(artifact) / "adapter/adapter_model.safetensors").is_file()
    return {"status": "ok", "gpu": gpu, "local_only": True, "score_definition": "eatd-severity-index-v1",
            "clinical_validation": "not_validated", "trained_severity_available": weights_present and gpu.get("status") not in {"offline", "error", "training"},
            "severity_artifact_configured": bool(settings().get("severity_artifact_path")),
            "unified_artifact_configured": bool(settings().get("unified_artifact_path")), "busy_sessions": list(busy_sessions)}


@app.get("/api/sessions")
async def sessions():
    return storage.list_sessions()


@app.post("/api/sessions")
async def create_session(payload: SessionCreate):
    session = storage.create(payload.title)
    if payload.synthetic:
        session["synthetic"] = True
        storage.save(session)
    return session


def require_session(session_id):
    session = storage.get(session_id)
    if session is None:
        raise HTTPException(404, "会话不存在")
    return session


@app.get("/api/sessions/{session_id}")
async def read_session(session_id: str):
    return require_session(session_id)


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    if session_id in busy_sessions:
        raise HTTPException(409, "会话正在分析，请结束后删除。")
    require_session(session_id)
    raw_audio.remove_session(session_id)
    storage.delete(session_id)
    return {"deleted": True}


@app.get("/api/sessions/{session_id}/export")
async def export_session(session_id: str):
    return JSONResponse(require_session(session_id), headers={"Content-Disposition": f'attachment; filename="session-{session_id[:8]}.json"'})


async def analyze_session(session_id: str, extra_text=None, synthetic=False):
    if session_id in busy_sessions:
        raise HTTPException(409, "当前会话正在处理，请稍候。")
    busy_sessions.add(session_id)
    try:
        session = require_session(session_id)
        if synthetic:
            session["synthetic"] = True
            session["title"] = "虚构示例 · 功能体验"
        if extra_text:
            session["turns"].append({"id": "u_" + uuid.uuid4().hex[:12], "role": "user", "text": extra_text})
            if session["title"] == "新的对话":
                session["title"] = extra_text[:22]
        if not any(t["role"] == "user" for t in session["turns"]):
            raise HTTPException(400, "请先说一些最近的情况。")
        storage.archive_report(session)
        session["report"] = None
        storage.save(session)
        report, reply = await analyze([Turn.model_validate(t) for t in session["turns"]])
        report = from_legacy(report, session["turns"], has_audio=any(a.get("raw_audio_id") for a in session.get("audio", [])))
        session["report"] = report
        session["turns"].append({"id": "a_" + uuid.uuid4().hex[:12], "role": "assistant", "text": reply})
        storage.save(session)
        return session
    finally:
        busy_sessions.discard(session_id)


@app.post("/api/sessions/{session_id}/messages")
async def message(session_id: str, payload: ChatRequest):
    if not payload.text.strip():
        raise HTTPException(400, "消息不能为空白。")
    return await analyze_session(session_id, payload.text.strip(), payload.synthetic)


@app.post("/api/sessions/{session_id}/analyze")
async def reanalyze(session_id: str):
    return await analyze_session(session_id)


@app.post("/api/analyze")
async def analyze_stateless(payload: AnalyzeRequest):
    session = {"turns": [t.model_dump() for t in payload.turns],
               "audio": [a.model_dump() for a in payload.audio_inputs]}
    paired_inputs(session)
    report, reply = await analyze(payload.turns)
    if payload.audio_inputs:
        report = await attach_multimodal(report, session)
    return {"report": report, "reply": reply}


@app.post("/api/analyze-multimodal")
async def analyze_multimodal(payload: AnalyzeRequest):
    if not payload.audio_inputs:
        raise HTTPException(400, "联合分析需要原始语音编码引用 audio_inputs。")
    return await analyze_stateless(payload)


@app.post("/api/transcribe")
async def transcribe(file: UploadFile = File(...), session_id: str | None = Form(None)):
    if session_id:
        require_session(session_id)
    upload_root = runtime_dir() / "uploads"
    upload_root.mkdir(exist_ok=True)
    suffix = Path(file.filename or "audio.wav").suffix.lower()
    if suffix not in {".wav", ".mp3", ".flac", ".webm", ".m4a", ".ogg", ".mp4"}:
        raise HTTPException(400, "请选择 WAV、MP3、FLAC、WEBM 或 M4A 音频。")
    path = upload_root / (uuid.uuid4().hex + suffix)
    limit = settings()["max_upload_mb"] * 1024 * 1024
    count = 0
    if session_id:
        if session_id in busy_sessions:
            raise HTTPException(409, "会话正在处理，请稍候再导入录音。")
        busy_sessions.add(session_id)
    try:
        with path.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                count += len(chunk)
                if count > limit:
                    raise HTTPException(413, "音频不能超过50MB。")
                out.write(chunk)
        if count == 0:
            raise HTTPException(400, "音频文件为空。")
        result = await worker_call("/transcribe", {"path": str(path)})
        if session_id and result.get("audio_features_id"):
            bundle = load_bundle(result["audio_features_id"])
            meta = raw_audio.retain(session_id, path, bundle["source_sha256"], result.get("segments", []))
            result["raw_audio_id"] = meta["id"]
            result["raw_audio_retained"] = True
        return result
    finally:
        path.unlink(missing_ok=True)
        await file.close()
        if session_id:
            busy_sessions.discard(session_id)


@app.post("/api/sessions/{session_id}/score")
async def score_conversation(session_id: str):
    if session_id in busy_sessions:
        raise HTTPException(409, "请等当前这一轮聊完后再整理结果。")
    busy_sessions.add(session_id)
    try:
        session = require_session(session_id)
        if not any(t["role"] == "user" for t in session["turns"]):
            return session
        report, _ = await analyze([Turn.model_validate(t) for t in session["turns"]])
        legacy = report
        row = input_record(session)
        storage.archive_report(session)
        pending = from_legacy(legacy, session["turns"], has_audio=bool(row["audio_paths"]))
        pending["status"] = "scoring"
        session["report"] = pending
        storage.save(session)
        if row["audio_paths"] and settings().get("unified_artifact_path"):
            try:
                report = await worker_call("/unified-score", {"record": row})
            except (RuntimeError, ValueError, httpx.HTTPError) as error:
                pending["status"] = "failed"
                pending["defer_reasons"].append("联合模型评分失败，原始结果未更新。")
                pending["model_error"] = str(error)[:500]
                storage.save(session)
                raise
            report["risk"] = legacy["risk"]
        else:
            report = from_legacy(legacy, session["turns"], has_audio=bool(row["audio_paths"]))
            report["status"] = "deferred"
            if not settings().get("unified_artifact_path"):
                report["defer_reasons"].append("评分模型尚未就绪")
        session["report"] = report
        storage.save(session)
        return session
    finally:
        busy_sessions.discard(session_id)


@app.post("/api/sessions/{session_id}/audio-message")
async def audio_message(session_id: str, payload: dict):
    # Read encoded waveform from the server store, not client-supplied descriptors.
    text = str(payload.get("text", "")).strip()
    if not text or len(text) > 12000:
        raise HTTPException(400, "请确认转录内容，长度应在1–12000字之间。")
    if session_id in busy_sessions:
        raise HTTPException(409, "会话正在处理。")
    identifier = payload.get("audio_features_id")
    if not identifier:
        raise HTTPException(400, "缺少原录音的编码引用，请重新导入录音后发送。")
    bundle = load_bundle(identifier)
    session = require_session(session_id)
    raw_identifier = payload.get("raw_audio_id")
    verified_segments = []
    if raw_identifier:
        _, meta = raw_audio.resolve(session_id, raw_identifier)
        if meta["sha256"] != bundle["source_sha256"]:
            raise ValueError("录音与转录编码不匹配")
        verified_segments = meta.get("asr_segments", [])
    turn_id = "u_" + uuid.uuid4().hex[:12]
    session["turns"].append({"id": turn_id, "role": "user", "text": text,
                             "audio_segments": verified_segments,
                             "transcript_reviewed_by_user": True})
    session["audio"].append({"turn_id": turn_id, "acoustics": bundle["acoustics"],
                             "audio_features_id": identifier, "audio_sha256": bundle["source_sha256"],
                             "provenance": "server_waveform_encoder", "raw_audio_retained": bool(raw_identifier),
                             "raw_audio_id": raw_identifier})
    paired_inputs(session)
    if session["title"] == "新的对话":
        session["title"] = text[:22]
    storage.save(session)
    return await analyze_session(session_id)


@app.get("/api/sessions/{session_id}/audio/{audio_id}")
async def retained_audio(session_id: str, audio_id: str):
    require_session(session_id)
    path, _ = raw_audio.resolve(session_id, audio_id)
    return FileResponse(path)


@app.delete("/api/sessions/{session_id}/audio-drafts/{audio_id}")
async def discard_audio(session_id: str, audio_id: str):
    session = require_session(session_id)
    if any(a.get("raw_audio_id") == audio_id for a in session.get("audio", [])):
        raise HTTPException(409, "录音已经属于会话发言，请删除整个会话。")
    raw_audio.remove(session_id, audio_id)
    return {"deleted": True}


@app.post("/api/models/warmup")
async def warmup():
    return await worker_call("/warmup", {})


@app.post("/api/severity/predict")
async def predict_severity(payload: dict):
    path = settings().get("severity_artifact_path")
    if not path:
        raise HTTPException(409, "尚未配置真实标签训练的连续评分工件。先完成训练和评测，再设置 severity_artifact_path。")
    # Model paths are operator-configured, never accepted from an HTTP request.
    from depression_lab.predict import load_artifact, predict_record
    return await predict_record(load_artifact(path), payload)


@app.post("/api/models/unload")
async def unload():
    if busy_sessions:
        raise HTTPException(409, "请等待当前分析结束。")
    return await worker_call("/unload", {})


app.mount("/static", StaticFiles(directory=ROOT / "web", check_dir=False), name="static")


if __name__ == "__main__":
    import uvicorn
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    uvicorn.run(app, host="127.0.0.1", port=settings()["port"])
