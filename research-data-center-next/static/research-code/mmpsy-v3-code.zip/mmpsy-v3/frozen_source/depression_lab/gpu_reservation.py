"""Read-only check for this project's live Windows training process."""

import ctypes
import json
import os
from ctypes import wintypes

from depression_lab.config import runtime_dir


def active_training():
    path = runtime_dir() / "training-owner.json"
    if not path.exists():
        return False
    try:
        owner = json.loads(path.read_text(encoding="utf-8-sig"))
        if os.name != "nt":
            return False
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        handle = kernel.OpenProcess(0x1000, False, int(owner["pid"]))
        if not handle:
            return False
        try:
            code = wintypes.DWORD()
            times = [wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value != 259:
                return False
            if not kernel.GetProcessTimes(handle, *(ctypes.byref(t) for t in times)):
                return False
            created = (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
            return abs(created - int(owner["creation_filetime"])) < 10000
        finally:
            kernel.CloseHandle(handle)
    except (ValueError, KeyError, TypeError, OSError):
        return False
