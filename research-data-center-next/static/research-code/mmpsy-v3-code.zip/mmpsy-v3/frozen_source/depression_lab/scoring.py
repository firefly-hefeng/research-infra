"""Verify evidence before a deterministic PHQ-9 frequency mapping.

This is a research baseline, not a clinically trained severity predictor.
"""
import re

from depression_lab.scales import FOLLOWUPS, FREQUENCY_NAMES, FREQUENCY_SCORES, PHQ9_IDS, PHQ9_ITEMS
from depression_lab.schemas import Evidence, ModelAssessment, Turn

PERIOD_PATTERN = re.compile(r"两周|二周|2\s*周|14\s*天|十四天|两个星期|2\s*个?星期")
FREQUENCY_PATTERNS = {
    "not_at_all": r"没|无|不|正常|很好|挺好|还好|良好|都好|都挺|充沛|开心|一样|没有",
    "several_days": r"几天|有时|偶尔|偶然|一两天|两三天|三四天|四五天|[1-6]\s*天|[一二三四五六]\s*天",
    "more_than_half": r"一半|大半|多数|大部分|[89]\s*天|1[012]\s*天|八天|九天|十天|十一天|十二天",
    "nearly_every_day": r"每天|天天|每一天|几乎每日|13\s*天|14\s*天|十三天|十四天",
}


def valid_evidence(evidence: Evidence, by_id: dict[str, Turn], user_only=True) -> bool:
    turn = by_id.get(evidence.turn_id)
    return bool(turn and (not user_only or turn.role == "user") and evidence.quote.strip()
                and evidence.quote in turn.text)


def evidence_payload(evidence: Evidence, by_id: dict[str, Turn]) -> dict:
    data = evidence.model_dump()
    data["literal_match_verified"] = True
    data["audio_segments"] = [s for s in by_id[evidence.turn_id].audio_segments
                              if evidence.quote in s.get("text", "") or s.get("text", "") in evidence.quote]
    return data


def current_risk_evidence(evidence, by_id, observations):
    if not valid_evidence(evidence, by_id):
        return False
    for obs in observations:
        if (obs.scope in {"other_person", "hypothetical"} or obs.period == "other"
                or (obs.item_id == "self_harm" and obs.status == "absent")):
            if any(e.turn_id == evidence.turn_id and (e.quote in evidence.quote or evidence.quote in e.quote)
                   for e in obs.evidence):
                return False
    # Reject explicit quoted fictional/third-party evidence; this is not a general risk classifier.
    return not re.search(r"主角|小说人物|角色|他(?:说|想死)|她(?:说|想死)|例如|假如|几年前", evidence.quote)


def score_assessment(model: ModelAssessment, turns: list[Turn]) -> dict:
    if len({t.id for t in turns}) != len(turns):
        raise ValueError("对话 turn_id 必须唯一")
    by_id = {t.id: t for t in turns}
    accepted = {}
    audit = []
    for obs in model.observations:
        if obs.item_id not in PHQ9_IDS:
            audit.append({"code": "unknown_item", "item_id": obs.item_id})
            continue
        if not obs.evidence or not all(valid_evidence(e, by_id) for e in obs.evidence):
            audit.append({"code": "unverifiable_evidence", "item_id": obs.item_id})
            continue
        if obs.scope != "self":
            audit.append({"code": "not_current_self_report", "item_id": obs.item_id})
            continue
        if obs.item_id in accepted:
            # Multiple contradictory outputs cannot overwrite earlier data silently.
            accepted[obs.item_id]["score"] = None
            accepted[obs.item_id]["status"] = "needs_clarification"
            accepted[obs.item_id]["missing"] = ["模型输出了重复条目，需要核对。"]
            continue
        missing = []
        evidence_text = " ".join(e.quote for e in obs.evidence)
        period_ok = (obs.period == "past_two_weeks" and bool(obs.period_evidence)
                     and all(valid_evidence(e, by_id, user_only=False) for e in obs.period_evidence)
                     and any(PERIOD_PATTERN.search(e.quote) for e in obs.period_evidence))
        if not period_ok:
            missing.append("最近两周的时间范围")
        if obs.frequency == "unknown" or not re.search(FREQUENCY_PATTERNS.get(obs.frequency, r"(?!)"), evidence_text):
            missing.append("明确的发生频率")
        if obs.status == "uncertain" or obs.conflicting:
            missing.append("症状是否存在或前后矛盾")
        if (obs.status == "present" and obs.frequency == "not_at_all") or (obs.status == "absent" and obs.frequency not in {"not_at_all", "unknown"}):
            missing.append("症状与频率不一致")
        score = FREQUENCY_SCORES.get(obs.frequency) if not missing else None
        accepted[obs.item_id] = {
            "score": score, "status": "mapped" if score is not None else "needs_clarification",
            "presence": obs.status, "frequency": obs.frequency,
            "frequency_label": FREQUENCY_NAMES[obs.frequency], "period": obs.period,
            "evidence": [evidence_payload(e, by_id) for e in obs.evidence],
            "period_evidence": [evidence_payload(e, by_id) for e in obs.period_evidence
                                if valid_evidence(e, by_id, user_only=False)],
            "rationale": obs.rationale, "rationale_status": "model_draft_not_clinician_verified",
            "missing": missing,
        }
    items = []
    for item_id, title, definition in PHQ9_ITEMS:
        item = {"id": item_id, "title": title, "definition": definition, "max_score": 3}
        item.update(accepted.get(item_id, {"score": None, "status": "not_observed", "presence": "unknown",
                                          "frequency": "unknown", "frequency_label": "尚未涉及",
                                          "period": "unknown", "evidence": [], "rationale": "对话未提供足够信息。",
                                          "missing": ["症状、时间范围与频率"]}))
        items.append(item)
    complete = [item for item in items if item["score"] is not None]
    subtotal = sum(item["score"] for item in complete)
    unknown_count = len(items) - len(complete)
    risk_quotes = [evidence_payload(e, by_id) for e in model.risk_evidence
                   if current_risk_evidence(e, by_id, model.observations)]
    self_harm = next(x for x in items if x["id"] == "self_harm")
    if self_harm.get("presence") == "present" and self_harm.get("period") != "other":
        risk_quotes.extend(self_harm["evidence"])
    # Additional high-recall safety check, never interpreted as a diagnosis or absence of danger.
    for turn in turns:
        if turn.role != "user":
            continue
        for match in re.finditer(r"不想活了|我想死|我要自杀|我想自杀|我准备.{0,5}(?:跳楼|自杀)|我.{0,5}伤害自己", turn.text):
            prefix = turn.text[max(0, match.start() - 6):match.start()]
            candidate = Evidence(turn_id=turn.id, quote=match.group())
            if (not re.search(r"没有|并不|不会|不再|他说|她说|例如|假如|小说|角色", prefix)
                    and current_risk_evidence(candidate, by_id, model.observations)):
                risk_quotes.append({"turn_id": turn.id, "quote": match.group(), "literal_match_verified": True})
    followup = None
    if unknown_count:
        priority = sorted([x for x in items if x["score"] is None], key=lambda x: (x["status"] == "not_observed", PHQ9_IDS.index(x["id"])))
        next_item = priority[0]
        followup = {"item_id": next_item["id"], "question": FOLLOWUPS[next_item["id"]]}
    total = subtotal if unknown_count == 0 else None
    return {
        "scale": "PHQ-9", "score_kind": "semantic_frequency_mapping",
        "clinical_validation": "not_validated", "clinical_finetuned": False,
        "total_score": total, "observed_subtotal": subtotal, "answered_items": len(complete), "total_items": 9,
        "possible_total_range": [subtotal, subtotal + unknown_count * 3],
        "range_kind": "arithmetic_missing_items_not_prediction_interval", "prediction_interval": None,
        "items": items, "audit": audit, "followup": followup,
        "risk": {"status": "needs_immediate_check" if risk_quotes else "not_established",
                 "evidence": risk_quotes, "independent_of_total": True,
                 "message": "你现在是否有马上伤害自己的打算，或已经采取了行动？如果有立即危险，请联系当地急救，并让可信任的人陪在身边。" if risk_quotes else "本次对话不能排除风险。"},
        "trained_severity": {"available": False, "reason": "尚未载入经独立临床数据训练和评测的模型。"},
        "limitations": ["此结果是通用模型辅助的量表语义映射，尚未验证诊断或治疗决策效果。",
                        "引用逐字匹配仅证明文本存在，概念与评分解释仍可能出错。"],
    }


def build_reply(model: ModelAssessment, report: dict) -> str:
    if report["risk"]["status"] == "needs_immediate_check":
        return "谢谢你愿意告诉我这些，这些感受值得被认真对待。" + report["risk"]["message"]
    reply = model.empathetic_reply.strip() or "谢谢你愿意说说最近的情况。"
    if re.search(r"(?:必须|需要|应该|建议).{0,8}(?:吃药|服药|停药|减药)|确诊|你(?:有|患有|得了)抑郁症|(?:轻度|中度|重度).{0,4}抑郁|(?:分数|得分|评分|患病概率|PHQ|SDS).{0,20}\d", reply):
        reply = "谢谢你愿意说说最近的情况。"
    if report["followup"]:
        reply += "\n\n" + report["followup"]["question"]
    elif report["total_score"] is not None:
        reply += "\n\n这次已收集到九项的频率信息，你可以在右侧核对原话和分项。"
    return reply
