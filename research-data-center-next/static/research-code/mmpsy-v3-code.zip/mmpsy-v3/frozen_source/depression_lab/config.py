import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def settings() -> dict:
    values = json.loads((ROOT / "settings.example.json").read_text(encoding="utf-8"))
    local = ROOT / "settings.local.json"
    if local.exists():
        values.update(json.loads(local.read_text(encoding="utf-8")))
    if os.environ.get("DEPRESSION_RUNTIME"):
        values["runtime_dir"] = os.environ["DEPRESSION_RUNTIME"]
    return values


def runtime_dir() -> Path:
    path = Path(settings()["runtime_dir"])
    path.mkdir(parents=True, exist_ok=True)
    return path
