"""Local waveform + source-grounded semantics, trained severity and short rationale."""
import gc
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from depression_lab.audio import decode_audio
from depression_lab.evidence import ACOUSTICS, FORBIDDEN, public_report
from depression_lab.evidence_entailment import candidates, bundle_from_actions
from depression_lab.evidence_report_text import evidence_record_explanation
from depression_lab.finite_evidence_policy import FiniteEvidencePolicy
from depression_lab.mmpsy_audio import measurements
from depression_lab.mmpsy_scorer import MMPsyScorer
from depression_lab.unified_model import OmniEncoder, measure_record
from depression_lab.omni_evidence_policy import OmniEvidencePolicy
from depression_lab.unified_runtime import attach_recording_locations


def source_segments(turns):
    import re
    result = []
    for turn in turns:
        if turn.get('role', 'user') != 'user':
            continue
        for match in re.finditer(r'[^。！？\n]+[。！？\n]?', turn['text']):
            for offset in range(0, len(match[0]), 160):
                text = match[0][offset:offset+160]
                if text.strip():
                    result.append({'turn_id': turn['id'], 'start': match.start()+offset,
                                   'end': match.start()+offset+len(text), 'text': text})
    return result


class MMPsyRuntime:
    def __init__(self, artifact):
        self.scorer = MMPsyScorer(artifact)
        self.path = self.scorer.path
        self.manifest = self.scorer.manifest
        self.policy = self.encoder = self.text_model = None
        self.mode = None
        cal = self.path / 'calibration.json'
        self.calibration = json.loads(cal.read_text(encoding='utf8')) if cal.exists() else None
        if self.calibration and self.calibration['scorer_sha256'] != self.scorer.weights_sha256:
            raise ValueError('Calibration/model mismatch')
        status = self.path / 'research_validation.json'
        self.research = json.loads(status.read_text(encoding='utf8')) if status.exists() else {'prediction_criterion': 'pending'}
        if self.research.get('scorer_sha256', self.scorer.weights_sha256) != self.scorer.weights_sha256:
            raise ValueError('Research validation/model mismatch')

    def unload(self):
        self.policy = self.encoder = self.text_model = None
        self.mode = None
        gc.collect()
        torch.cuda.empty_cache()

    def load_extractor(self):
        if self.mode == 'evidence':
            return
        self.unload()
        from transformers import AutoTokenizer, Qwen2_5_VLForConditionalGeneration
        path = 'D:/speech-cognition-4090/models/Qwen2.5-VL-7B-Instruct'
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, padding_side='left')
        self.text_model = Qwen2_5_VLForConditionalGeneration.from_pretrained(path, local_files_only=True,
            torch_dtype=torch.bfloat16, attn_implementation='sdpa').to('cuda').eval()
        self.policy = FiniteEvidencePolicy(self.text_model, tokenizer)
        self.mode = 'evidence'

    def load_reasoner(self):
        if self.mode == 'rationale':
            return
        self.unload()
        adapter = Path(self.manifest['explanation_adapter'])
        if hashlib.sha256((adapter / 'adapter_model.safetensors').read_bytes()).hexdigest() != self.manifest['explanation_adapter_sha256']:
            raise ValueError('Explanation adapter mismatch')
        self.encoder = OmniEncoder('D:/depression-lab/models/Qwen2.5-Omni-3B', str(adapter))
        self.encoder.model.eval()
        self.policy = OmniEvidencePolicy(self.encoder)
        self.mode = 'rationale'

    def predict(self, row, explain=True):
        if (FORBIDDEN | {'target_0_100', 'source_label'}) & set(row):
            raise ValueError('Inference must not contain target labels')
        if not row.get('audio_paths') or not row.get('turns'):
            raise ValueError('需要原始录音和对应发言')
        expected_text = ''.join(t['text'] for t in row['turns'] if t.get('role', 'user') == 'user')
        if ''.join(expected_text.split()) != ''.join(row.get('transcript', '').split()):
            raise ValueError('Transcript and turns disagree')
        hashes = [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in row['audio_paths']]
        if hashes != row.get('audio_sha256') or len(set(hashes)) != len(hashes):
            raise ValueError('Original audio provenance mismatch or duplicate waveform')
        original_values, original_measures = measure_record({**row, 'transcript': row.get('audio_transcript', row['transcript'])})
        usable = any(m.get('usable_for_asr') for m in original_measures)
        spectral = None
        if usable:
            waves = [decode_audio(Path(p).read_bytes(), max_seconds=1200) for p in row['audio_paths']]
            spectral = measurements(np.concatenate(waves), hashes)
        source = source_segments(row['turns'])
        pointers = candidates(source)
        self.load_extractor()
        actions = self.policy.classify([(concept, source[sid]['text']) for sid, concept in pointers])
        decisions = [(sid, concept, action) for (sid, concept), action in zip(pointers, actions, strict=True)]
        bundle = attach_recording_locations(bundle_from_actions(decisions, source, row['turns']), row)
        # Context evidence keeps its own literal sources and recording locations.
        extra = attach_recording_locations({'observations': bundle['context']}, row)
        bundle['context'] = extra['observations']
        prediction = self.scorer.predict(bundle, spectral['values']) if spectral else None
        interval = None
        if prediction and self.calibration:
            score, radius = prediction['score_0_100'], self.calibration['radius_0_100']
            interval = {'lower': max(0, score-radius), 'upper': min(100, score+radius),
                        'coverage_target': .9, 'method': 'split_conformal_absolute_residual',
                        'calibration_n': self.calibration['n'], 'population': self.manifest['interval_population'],
                        'free_chat_coverage_validated': False}
        model_info = {'route': 'B', 'artifact': self.path.name, 'version': self.manifest['model_version'],
                      'head_sha256': self.scorer.weights_sha256, 'adapter_sha256': self.manifest['explanation_adapter_sha256'],
                      'extractor': self.manifest['extractor'], 'research_validation': self.research}
        report = public_report(bundle, probabilities=prediction['distribution'] if prediction else None,
                               has_audio=usable, model=model_info, interval=interval,
                               explanation=evidence_record_explanation(bundle))
        report['score_definition'] = self.manifest['score_definition']
        report['score_definition_note'] = 'MMPsy 独立标签监督的研究指数，与旧 SDS 版本不可直接比较。'
        report['context_evidence'] = bundle['context']
        report['context_concepts_are_clinical_symptoms'] = False
        report['scoring_evidence'] = {'source_sha256': hashes, 'slots': prediction['slots'] if prediction else None,
                                      'context': bundle['context'], 'spectral_measurements': spectral,
                                      'acoustics': dict(zip(ACOUSTICS, original_values, strict=True)),
                                      'acoustic_aggregation_note': 'duration totals and duration-weighted summaries; model uses all participant mel frames',
                                      'recording_measurements': original_measures, 'no_hidden_score_bypass': True}
        report['explanation_status'] = 'source_bound_record; trained_rationale_not_requested'
        if explain and report['status'] == 'scored':
            # Keep one deterministic source per observed concept to bound report
            # prose length. Every source still enters score features above.
            jobs, action_values, seen = [], [], set()
            for sid, concept, action in decisions:
                if action == 'A' or concept in seen:
                    continue
                seen.add(concept)
                jobs.append((concept, source[sid]['text']))
                action_values.append(action)
            if jobs:
                self.load_reasoner()
                reports = self.policy.explanations(jobs, action_values)
                report['trained_rationales'] = [r['parsed'] for r in reports if r['structural_source_agreement']]
                report['rationale_audit'] = {'generated': len(reports), 'accepted': len(report['trained_rationales']),
                                           'identity_fields_bound_by_program': True, 'natural_language_faithfulness_expert_verified': False}
                report['explanation_status'] = 'trained_short_rationales_with_program_bound_evidence'
        return report
