from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Turn(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    role: Literal["user", "assistant"]
    text: str = Field(min_length=1, max_length=16000)
    audio_segments: list[dict] = Field(default_factory=list)


class Evidence(BaseModel):
    model_config = ConfigDict(extra="forbid")
    turn_id: str
    quote: str = Field(min_length=1, max_length=2000)


class Observation(BaseModel):
    item_id: str
    status: Literal["present", "absent", "uncertain"] = "uncertain"
    frequency: Literal["not_at_all", "several_days", "more_than_half", "nearly_every_day", "unknown"] = "unknown"
    period: Literal["past_two_weeks", "other", "unknown"] = "unknown"
    scope: Literal["self", "other_person", "hypothetical", "unknown"] = "unknown"
    evidence: list[Evidence] = Field(default_factory=list)
    period_evidence: list[Evidence] = Field(default_factory=list)
    rationale: str = Field(default="", max_length=700)
    conflicting: bool = False


class ModelAssessment(BaseModel):
    observations: list[Observation] = Field(default_factory=list, max_length=30)
    risk_evidence: list[Evidence] = Field(default_factory=list)
    empathetic_reply: str = Field(default="", max_length=800)
    format_repairs: list[str] = Field(default_factory=list)


class ChatRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)
    synthetic: bool = False


class AudioInput(BaseModel):
    turn_id: str
    audio_features_id: str = Field(pattern=r"^[0-9a-f]{64}$")


class AnalyzeRequest(BaseModel):
    turns: list[Turn] = Field(min_length=1, max_length=80)
    audio_inputs: list[AudioInput] = Field(default_factory=list, max_length=80)


class SessionCreate(BaseModel):
    title: str = Field(default="新的对话", max_length=80)
    synthetic: bool = False
