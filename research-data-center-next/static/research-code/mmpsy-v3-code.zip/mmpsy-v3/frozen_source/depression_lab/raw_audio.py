"""Session-owned original audio. No implicit enrollment into training data."""

import hashlib
import json
import re
import uuid
from pathlib import Path

from depression_lab.config import runtime_dir


def _id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{32}", value):
        raise ValueError("Invalid audio/session identifier")
    return value


def directory(session_id):
    root = (runtime_dir() / "session-audio").resolve()
    result = (root / _id(session_id)).resolve()
    if not result.is_relative_to(root):
        raise ValueError("Invalid audio ownership")
    return result


def retain(session_id, source, source_sha256, asr_segments=None):
    data = Path(source).read_bytes()
    if hashlib.sha256(data).hexdigest() != source_sha256:
        raise ValueError("Original audio does not match waveform feature source")
    target = directory(session_id)
    target.mkdir(parents=True, exist_ok=True)
    identifier = uuid.uuid4().hex
    suffix = Path(source).suffix.lower()
    path = target / (identifier + suffix)
    path.write_bytes(data)
    meta = {
        "id": identifier,
        "session_id": session_id,
        "suffix": suffix,
        "sha256": source_sha256,
        "bytes": len(data),
        "retention": "until_session_deleted",
        "training_enrolled": False,
        "asr_segments": asr_segments or [],
        "timestamp_precision": "ASR chunk boundaries, not word alignment",
    }
    (target / (identifier + ".json")).write_text(json.dumps(meta), encoding="utf-8")
    return meta


def resolve(session_id, identifier):
    target = directory(session_id)
    metadata = target / (_id(identifier) + ".json")
    if not metadata.is_file():
        raise ValueError("原始录音不存在或不属于该会话")
    meta = json.loads(metadata.read_text(encoding="utf-8"))
    if meta.get("session_id") != session_id or meta.get("id") != identifier:
        raise ValueError("Audio ownership mismatch")
    path = (target / (identifier + meta["suffix"])).resolve()
    if not path.is_relative_to(target.resolve()) or not path.is_file():
        raise ValueError("Invalid retained audio path")
    if hashlib.sha256(path.read_bytes()).hexdigest() != meta["sha256"]:
        raise ValueError("原始录音校验失败")
    return path, meta


def remove(session_id, identifier):
    path, _ = resolve(session_id, identifier)
    path.unlink()
    (directory(session_id) / (identifier + ".json")).unlink()


def remove_session(session_id):
    target = directory(session_id)
    if target.exists():
        # Only direct files created by this store, no recursive computed deletion.
        for path in target.iterdir():
            if path.is_symlink() or not path.is_file():
                raise ValueError("Unexpected object in owned audio store")
            path.unlink()
        target.rmdir()
