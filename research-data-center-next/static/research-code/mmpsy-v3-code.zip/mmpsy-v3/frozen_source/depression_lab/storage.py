import json
import sqlite3
import uuid
import copy
from datetime import datetime, timezone

from depression_lab.config import runtime_dir


def connect():
    connection = sqlite3.connect(runtime_dir() / "sessions.sqlite3", timeout=10)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, title TEXT, updated_at TEXT, body TEXT)")
    return connection


def create(title="新的对话"):
    session = {"id": uuid.uuid4().hex, "title": title, "turns": [], "report": None, "audio": []}
    save(session)
    return session


def save(session):
    session["updated_at"] = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute("INSERT OR REPLACE INTO sessions VALUES (?, ?, ?, ?)",
                   (session["id"], session["title"], session["updated_at"], json.dumps(session, ensure_ascii=False)))


def get(session_id):
    with connect() as db:
        row = db.execute("SELECT body FROM sessions WHERE id=?", (session_id,)).fetchone()
    return json.loads(row[0]) if row else None


def archive_report(session):
    """Keep the original report type and values before a new chat/score run."""
    report = session.get("report")
    if not report:
        return
    history = session.setdefault("report_history", [])
    if not history or history[-1]["report"] != report:
        history.append({"created_at": session.get("updated_at"), "report": copy.deepcopy(report)})


def list_sessions():
    with connect() as db:
        rows = db.execute("SELECT id,title,updated_at FROM sessions ORDER BY updated_at DESC LIMIT 100").fetchall()
    return [dict(zip(["id", "title", "updated_at"], row)) for row in rows]


def delete(session_id):
    with connect() as db:
        db.execute("DELETE FROM sessions WHERE id=?", (session_id,))
