"""Label-free inference for one versioned evidence/score model artifact."""

import hashlib
import json
import re
from pathlib import Path

import torch

from depression_lab.evidence import (
    CONCEPTS,
    FORBIDDEN,
    cot_target,
    digest,
    parse_json,
    public_report,
    slots_from_evidence,
    validate_evidence,
)
from depression_lab.unified_model import OmniEncoder, acoustic_tensor, load_heads, measure_record
from depression_lab.evidence_report_text import evidence_record_explanation
from depression_lab.research_status import load_research_status


def explanation_check(value, bundle, slots):
    """Structural agreement only, never reported as expert semantic validation."""
    if not isinstance(value, dict) or not isinstance(value.get("observations"), list):
        return False
    if set(value) != {"observations", "counterevidence_ids", "missing", "conflicts"}:
        return False
    expected = cot_target(bundle, slots)
    states = ["unknown", "present", "absent"]
    seen = set()
    for obs in value["observations"]:
        if not isinstance(obs, dict) or set(obs) != {"concept", "presence", "evidence_ids", "explanation"}:
            return False
        if obs.get("concept") not in CONCEPTS or obs["concept"] in seen:
            return False
        seen.add(obs["concept"])
        index = CONCEPTS.index(obs["concept"])
        if obs.get("presence") != states[slots[index][0]]:
            return False
        refs = obs.get("evidence_ids")
        permitted = {o["id"] for o in bundle["observations"] if o["concept"] == obs["concept"]}
        if not isinstance(refs, list) or not all(isinstance(x, str) for x in refs) or set(refs) != permitted:
            return False
        if re.search(
            r"(?:轻度|中度|重度)抑郁|确诊|(?:必须|应该|需要|建议|考虑).{0,8}(?:吃药|服药|用药|停药|减药)|患病概率|(?:得分|分数|评分|严重度).{0,8}\d",
            str(obs.get("explanation", "")),
        ):
            return False
    try:
        if set(value["counterevidence_ids"]) != set(expected["counterevidence_ids"]):
            return False
        actual_missing = {(x["concept"], tuple(sorted(x["fields"]))) for x in value["missing"]}
        wanted_missing = {(x["concept"], tuple(sorted(x["fields"]))) for x in expected["missing"]}
        if actual_missing != wanted_missing or value["conflicts"] != expected["conflicts"]:
            return False
    except (KeyError, TypeError):
        return False
    return len(seen) == len(CONCEPTS)


def attach_recording_locations(bundle, row):
    """Attach supplied alignment only; whole-recording labels stay coarse."""
    for observation in bundle["observations"]:
        if observation.get("audio_segments"):
            continue
        observation["audio_segments"] = [
            {
                "path": segment["path"],
                "start": segment["start"],
                "end": segment["end"],
                "precision": segment.get("precision", "provided_recording_interval"),
            }
            for segment in row.get("aligned_segments", [])
            if observation["quote"] in segment.get("text", "")
        ]
    return bundle


class UnifiedRuntime:
    def __init__(self, artifact):
        self.path = Path(artifact).resolve()
        if (
            not (self.path / "heads.pt").is_file()
            or not (self.path / "adapter/adapter_config.json").is_file()
        ):
            raise ValueError("统一评分工件不完整")
        self.heads, self.metadata = load_heads(self.path, "cuda")
        if self.metadata["route"] not in {"A", "B"}:
            raise ValueError("直接预测对照仅用于精度实验，不能作为证据瓶颈产品模型")
        self.encoder = OmniEncoder("D:/depression-lab/models/Qwen2.5-Omni-3B", str(self.path / "adapter"))
        self.encoder.model.eval()
        self.heads.eval()
        self.model_info = {
            "route": self.metadata["route"],
            "artifact": self.path.name,
            "head_sha256": hashlib.sha256((self.path / "heads.pt").read_bytes()).hexdigest(),
            "adapter_sha256": hashlib.sha256(
                (self.path / "adapter/adapter_model.safetensors").read_bytes()
            ).hexdigest(),
        }
        self.model_info["research_validation"] = load_research_status(self.path, self.model_info)
        calibration = self.path / "calibration.json"
        self.calibration = (
            json.loads(calibration.read_text(encoding="utf-8")) if calibration.exists() else None
        )
        if self.calibration and (
            self.calibration.get("selected_model_head_sha256") != self.model_info["head_sha256"]
            or self.calibration.get("selected_model_adapter_sha256") != self.model_info["adapter_sha256"]
        ):
            raise ValueError("校准工件与当前模型不匹配")

    def propose(self, row):
        if len(row["transcript"]) <= 6000:
            return attach_recording_locations(self.encoder.propose(row), row)
        observations, audits = [], []
        for turn in row["turns"]:
            if turn.get("role") != "user":
                continue
            for start in range(0, len(turn["text"]), 3000):
                window = {**turn, "text": turn["text"][start : start + 3000]}
                partial = self.encoder.propose({"turns": [window]})
                observations.extend(partial["observations"])
                audits.extend(partial["audit"])
        result = validate_evidence({"observations": observations}, row["turns"])
        result["audit"].extend(audits)
        return attach_recording_locations(result, row)

    def predict(self, row, explain=True):
        if (FORBIDDEN | {"target_0_100", "source_label"}) & set(row):
            raise ValueError("Inference input must not contain labels")
        if not row.get("audio_paths") or not row.get("turns"):
            raise ValueError("需要原始录音和对应发言")
        transcript = "".join(t["text"] for t in row["turns"] if t.get("role", "user") == "user")
        if "".join(transcript.split()) != "".join(row.get("transcript", "").split()):
            raise ValueError("汇总转写与用户发言不一致")
        if any(s.get("path") not in row["audio_paths"] for s in row.get("aligned_segments", [])):
            raise ValueError("时间段引用了未提供的录音")
        actual_hashes = [hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in row["audio_paths"]]
        if row.get("audio_sha256"):
            if len(row["audio_paths"]) != len(row["audio_sha256"]):
                raise ValueError("Audio provenance mismatch")
            for actual, expected in zip(actual_hashes, row["audio_sha256"], strict=True):
                if actual != expected:
                    raise ValueError("原始录音校验失败")
        row = {**row, "audio_sha256": actual_hashes}
        values, measurements = measure_record(
            {**row, "transcript": row.get("audio_transcript", row["transcript"])}
        )
        has_audio = any(m.get("usable_for_asr", False) for m in measurements)
        with torch.no_grad():
            bundle = self.propose(row)
            source_slots, conflicts = slots_from_evidence(bundle)
            h = self.encoder.hidden(row)
            result = self.heads(h, acoustic_tensor(values, self.metadata["normalizer"], "cuda"), source_slots)
            p = result["p"].cpu().tolist()
            slots = result["slots"].cpu().tolist()
        score = sum(i * value for i, value in enumerate(p))
        interval = None
        if self.calibration:
            q = self.calibration["absolute_residual_quantile"]
            interval = {
                "lower": max(0.0, score - q),
                "upper": min(100.0, score + q),
                "nominal_coverage": self.calibration["nominal_coverage"],
                "calibration_n": self.calibration["calibration_n"],
                "scope": "EATD held-out participants; free-chat coverage unverified",
            }
        report = public_report(
            bundle,
            slots,
            p,
            model=self.model_info,
            has_audio=has_audio,
            interval=interval,
            conflicts=conflicts,
        )
        report["scoring_evidence"] = {
            "slots": slots,
            "acoustics": dict(
                zip(
                    [
                        "duration_seconds",
                        "rms_dbfs",
                        "energy_activity_fraction",
                        "f0_median_hz",
                        "f0_iqr_hz",
                        "transcribed_characters_per_second",
                    ],
                    [x if x == x else None for x in values],
                    strict=True,
                )
            ),
            "source_sha256": row.get("audio_sha256", []),
            "confidence_values_used": False,
        }
        report["evidence_fingerprint"] = digest(
            {"evidence": bundle, "scoring_evidence": report["scoring_evidence"]}
        )
        report["audio_observations"] = [
            {"recording_index": i, "sha256": actual_hashes[i], "measurements": measurements[i]}
            for i in range(len(measurements))
        ]
        report["calibration"] = {
            "distribution_calibrated": False,
            "interval_method": "split_conformal_absolute_residual" if self.calibration else None,
            "calibration_n": self.calibration["calibration_n"] if self.calibration else 0,
            "population": "EATD participant split",
            "free_chat_coverage_validated": False,
        }
        report["explanation"] = evidence_record_explanation(bundle, slots)
        report["explanation_status"] = "selected_evidence_record_not_generated_CoT"
        if explain and report["status"] == "scored":
            raw = self.encoder.generate_cot({**row, "evidence": bundle, "selected_slots": slots})
            try:
                explanation = parse_json(raw)
            except (ValueError, TypeError):
                explanation = None
            report["research"]["generated_explanation"] = raw
            if explanation_check(explanation, bundle, slots):
                report["explanation"] = explanation
                report["explanation_status"] = "trained_CoT_structural_agreement_only"
            else:
                report["status"] = "deferred"
                report["score_0_100"] = report["distribution"] = report["interval"] = None
                report["defer_reasons"].append("生成的解释尚未通过与评分证据的一致性核验")
                report["explanation"] = evidence_record_explanation(bundle, slots)
                report["explanation_status"] = "generated_CoT_rejected_showing_evidence_record"
                report["followup"] = {"question": "能补充说明这些情况是什么时候开始、对生活有什么影响吗？"}
        return report
