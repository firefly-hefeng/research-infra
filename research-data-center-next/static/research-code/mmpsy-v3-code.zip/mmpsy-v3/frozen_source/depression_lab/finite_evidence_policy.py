"""Text-only Qwen entailment with an immutable shared system-prefix KV cache."""
from depression_lab.evidence_entailment import SYSTEM, prompt


class FiniteEvidencePolicy:
    def __init__(self, model, tokenizer):
        import torch
        self.model, self.tokenizer = model, tokenizer
        self.device = next(model.parameters()).device
        ids = [tokenizer.encode(c, add_special_tokens=False) for c in 'ABCDEF']
        if any(len(x) != 1 for x in ids):
            raise ValueError('Finite actions must be single tokens')
        self.action_ids = torch.tensor([x[0] for x in ids], device=self.device)
        prefix = tokenizer.apply_chat_template([{'role': 'system', 'content': SYSTEM}],
                                               tokenize=False, add_generation_prompt=False) + '<|im_start|>user\n'
        self.prefix_ids = tokenizer.encode(prefix, add_special_tokens=False)
        with torch.inference_mode():
            encoded = torch.tensor([self.prefix_ids], device=self.device)
            result = model.model(input_ids=encoded, attention_mask=torch.ones_like(encoded), use_cache=True)
            self.prefix_cache = result.past_key_values.to_legacy_cache()

    def encoded(self, text, concept):
        full = self.tokenizer.apply_chat_template([{'role': 'system', 'content': SYSTEM},
            {'role': 'user', 'content': prompt(text, concept)}], tokenize=True, add_generation_prompt=True)
        if full[:len(self.prefix_ids)] != self.prefix_ids:
            raise ValueError('Prompt prefix tokenization mismatch')
        return full

    def logits(self, jobs, cached=True):
        import torch
        from transformers import DynamicCache
        full = [self.encoded(text, concept) for concept, text in jobs]
        length = len(self.prefix_ids) if cached else 0
        suffix = [ids[length:] for ids in full]
        width = max(map(len, suffix))
        inputs = torch.full((len(jobs), width), self.tokenizer.pad_token_id, device=self.device, dtype=torch.long)
        mask = torch.zeros_like(inputs)
        for i, ids in enumerate(suffix):
            inputs[i, :len(ids)] = torch.tensor(ids, device=self.device)
            mask[i, :len(ids)] = 1
        attention = torch.cat([torch.ones((len(jobs), length), dtype=torch.long, device=self.device), mask], dim=1)
        position = (attention.cumsum(-1) - 1)[:, length:].masked_fill(mask == 0, 1)
        kwargs = {'input_ids': inputs, 'attention_mask': attention, 'position_ids': position[None].expand(3, -1, -1),
                  'use_cache': cached, 'return_dict': True}
        if cached:
            # DynamicCache.update replaces its tensors. New cache per call prevents
            # user suffixes contaminating the immutable system-only reference.
            kwargs['past_key_values'] = DynamicCache.from_legacy_cache(tuple(
                (key.expand(len(jobs), -1, -1, -1), value.expand(len(jobs), -1, -1, -1))
                for key, value in self.prefix_cache))
            kwargs['cache_position'] = torch.arange(length, length + width, device=self.device)
        with torch.inference_mode():
            hidden = self.model.model(**kwargs).last_hidden_state
            final = hidden[torch.arange(len(jobs), device=self.device), mask.sum(-1) - 1]
            # Only the six actually sampled token logits are needed; avoid the
            # old Transformers wrapper's full sequence x 152k vocabulary allocation.
            logits = torch.nn.functional.linear(final, self.model.lm_head.weight[self.action_ids]).float()
        return logits

    def classify(self, jobs, batch_size=16):
        results = []
        for start in range(0, len(jobs), batch_size):
            logits = self.logits(jobs[start:start+batch_size])
            results.extend('ABCDEF'[i] for i in logits.argmax(-1).cpu().tolist())
        return results
