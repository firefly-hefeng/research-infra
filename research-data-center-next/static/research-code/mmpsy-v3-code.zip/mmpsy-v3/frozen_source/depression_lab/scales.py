PHQ9_ITEMS = [
    ("interest", "兴趣或乐趣减退", "做事情的兴趣、乐趣减少"),
    ("mood", "情绪低落", "心情低落、沮丧或绝望"),
    ("sleep", "睡眠问题", "入睡困难、睡不踏实或睡得过多"),
    ("energy", "疲劳或精力不足", "疲倦或缺乏精力"),
    ("appetite", "食欲变化", "食欲不振或吃得过多"),
    ("self_worth", "自责或自我否定", "觉得自己不好、失败或让自己家人失望"),
    ("concentration", "注意力困难", "难以集中注意力"),
    ("psychomotor", "动作或言语变化", "动作说话缓慢到别人注意，或明显烦躁坐立不安"),
    ("self_harm", "死亡或自伤想法", "觉得死了更好或有伤害自己的想法"),
]
PHQ9_IDS = [x[0] for x in PHQ9_ITEMS]
FREQUENCY_SCORES = {"not_at_all": 0, "several_days": 1, "more_than_half": 2, "nearly_every_day": 3}
FREQUENCY_NAMES = {"not_at_all": "完全没有", "several_days": "有几天", "more_than_half": "超过一半天数", "nearly_every_day": "几乎每天", "unknown": "频率待确认"}
FOLLOWUPS = {
    "interest": "最近两周，以前喜欢的事情还能让你觉得有意思吗？如果有变化，大约有多少天？",
    "mood": "最近两周，低落、沮丧或没希望的感觉大约出现了多少天？",
    "sleep": "最近两周睡得怎么样？睡不着、容易醒或睡得太多的情况，大约有多少天？",
    "energy": "最近两周，你的精力怎么样？觉得疲倦或没力气大约有多少天？",
    "appetite": "最近两周食欲有没有明显变化，比如吃不下或吃得更多？大约有多少天？",
    "self_worth": "最近两周，有没有觉得自己很失败、很自责，或让家人失望？大约有多少天？",
    "concentration": "最近两周，看书、看节目或做事时，注意力难以集中大约有多少天？",
    "psychomotor": "最近两周，有没有动作或说话慢到别人注意到，或者明显坐立不安？大约有多少天？",
    "self_harm": "最近两周，你有没有觉得不如死了，或者有伤害自己的想法？如果有，大约出现了多少天？",
}

# Canonical HAMD-17 order. Do not use the modified HAMD-13 subset as HAMD-17.
HAMD17_IDS = ["depressed_mood", "guilt", "suicide", "insomnia_initial", "insomnia_middle", "insomnia_late", "work_interests", "retardation", "agitation", "psychic_anxiety", "somatic_anxiety", "gastrointestinal", "general_somatic", "genital", "hypochondriasis", "weight_loss", "insight"]
HAMD17_MAX = [4, 4, 4, 2, 2, 2, 4, 4, 4, 4, 4, 2, 2, 2, 4, 2, 2]
SCALES = {"PHQ-9": (PHQ9_IDS, [3] * 9), "HAMD-17": (HAMD17_IDS, HAMD17_MAX)}
