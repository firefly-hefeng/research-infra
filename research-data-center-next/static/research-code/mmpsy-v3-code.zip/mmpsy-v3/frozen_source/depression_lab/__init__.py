"""Local depression screening research tools."""
