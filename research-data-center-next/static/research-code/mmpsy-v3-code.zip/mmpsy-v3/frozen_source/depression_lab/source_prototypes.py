"""Small deterministic source-prototype clustering without OpenMP nested loops."""
import numpy as np


class SourcePrototypes:
    def __init__(self, n_clusters, seed=20260909, iterations=20):
        self.n_clusters, self.seed, self.iterations = n_clusters, seed, iterations

    def predict(self, vectors):
        return (np.square(self.cluster_centers_).sum(1)[None] - 2 * vectors @ self.cluster_centers_.T).argmin(1)

    def fit(self, vectors):
        rng = np.random.default_rng(self.seed)
        self.cluster_centers_ = vectors[rng.choice(len(vectors), self.n_clusters, replace=False)].copy()
        for _ in range(self.iterations):
            assignment = self.predict(vectors)
            updated = self.cluster_centers_.copy()
            for c in range(self.n_clusters):
                if np.any(assignment == c):
                    updated[c] = vectors[assignment == c].mean(0)
            self.cluster_centers_ = updated
        return self
