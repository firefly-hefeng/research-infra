"""Export verified concept/rationale supervision. No teacher-created clinical labels."""
import argparse
import json
from pathlib import Path

from depression_lab.dataset import load_manifest
from depression_lab.scales import SCALES


def export_sft(manifest, output, ablation="both", split="train"):
    records, audit = load_manifest(manifest)
    if split not in {"train", "dev"}:
        raise ValueError("测试集和校准集不能导出用于SFT")
    exported = []
    for row in records:
        if row["split"] != split:
            continue
        if row.get("human_verified") is not True:
            raise ValueError(f"{row['session_id']} 尚无人审，不能将模型草稿当作正式监督")
        answer = {"scale": row["scale"], "item_scores": row["item_scores"], "total_score": sum(row["item_scores"])}
        if ablation in {"concepts", "both"}:
            concepts = row.get("concepts")
            if not isinstance(concepts, list) or not concepts:
                raise ValueError("概念监督需要concepts列表")
            allowed_items = SCALES[row["scale"]][0]
            for concept in concepts:
                if concept.get("item_id") not in allowed_items:
                    raise ValueError("概念的item_id不属于当前量表")
                quote = concept.get("evidence_quote", "")
                if not quote or quote not in row["transcript"]:
                    raise ValueError("概念证据必须逐字存在于转录")
            answer["concepts"] = concepts
        if ablation in {"rationale", "both"}:
            rationale = row.get("rationale_summary")
            if not isinstance(rationale, str) or not rationale.strip():
                raise ValueError("解释监督需要人审后的rationale_summary")
            answer["rationale_summary"] = rationale
        exported.append({"participant_id": row["participant_id"], "session_id": row["session_id"],
                         "human_verified": True, "synthetic": False, "split": split,
                         "messages": [{"role": "system", "content": "根据访谈提取症状证据，输出量表分项及简短评分依据。只输出JSON。"},
                                      {"role": "user", "content": row["transcript"]},
                                      {"role": "assistant", "content": json.dumps(answer, ensure_ascii=False)}]})
    if not exported:
        raise ValueError("没有可导出的已核验样本")
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in exported) + "\n", encoding="utf-8")
    return {"records": len(exported), "ablation": ablation, "split": split, "dataset_audit": audit}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest")
    parser.add_argument("output")
    parser.add_argument("--ablation", choices=["score", "concepts", "rationale", "both"], default="both")
    parser.add_argument("--split", choices=["train", "dev"], default="train")
    args = parser.parse_args()
    print(json.dumps(export_sft(args.manifest, args.output, args.ablation, args.split), ensure_ascii=False, indent=2))
