"""Fine-tuned finite evidence decisions and source-bound short rationales."""
import json
import re
import torch
from depression_lab.cot_batch import left_pad_prompts
from scripts.train_mmpsy_reasoner import training_prompt, KINDS


class OmniEvidencePolicy:
    def __init__(self, encoder):
        self.encoder = encoder
        self.tokenizer = encoder.processor.tokenizer
        self.action_ids = [self.tokenizer.encode(c, add_special_tokens=False)[0] for c in 'ABCDEF']

    def prompts(self, jobs):
        return [self.encoder.batch(training_prompt(text, concept))[0] for concept, text in jobs]

    def logits(self, jobs, gradients=False):
        batch = left_pad_prompts(self.prompts(jobs), self.tokenizer.pad_token_id)
        model = self.encoder.model
        handle = model.base_model.model.lm_head.register_forward_pre_hook(lambda module, inputs: (inputs[0][:, -1:, :],))
        try:
            model.base_model.model.rope_deltas = None
            with torch.set_grad_enabled(gradients):
                return model(**batch, use_cache=False).logits[:, -1, self.action_ids].float()
        finally:
            handle.remove()

    def classify(self, jobs, batch_size=16):
        output = []
        for start in range(0, len(jobs), batch_size):
            output.extend('ABCDEF'[i] for i in self.logits(jobs[start:start+batch_size]).argmax(-1).cpu().tolist())
        return output

    def explanations(self, jobs, actions, batch_size=4):
        output = []
        for start in range(0, len(jobs), batch_size):
            selected_jobs = jobs[start:start+batch_size]
            selected_actions = actions[start:start+batch_size]
            prompts = self.prompts(selected_jobs)
            bound_prefixes = []
            for p, action, (concept, source) in zip(prompts, selected_actions, selected_jobs, strict=True):
                # IDs, relation and verbatim source are trusted program bindings.
                # The trained model supplies only its short rationale, never a
                # second concept identity, source quote, clinical state or score.
                fixed = json.dumps({'concept': concept, 'relation': KINDS[action], 'source_quote': source},
                                   ensure_ascii=False, separators=(',', ':'))[:-1] + ',"reason":"'
                bound_prefixes.append(fixed)
                tokens = self.tokenizer.encode(action+'\n'+fixed, add_special_tokens=False)
                p['input_ids'] = torch.cat([p['input_ids'], torch.tensor([tokens], device='cuda')], dim=1)
                p['attention_mask'] = torch.ones_like(p['input_ids'])
            batch = left_pad_prompts(prompts, self.tokenizer.pad_token_id)
            model = self.encoder.model
            handle = model.base_model.model.lm_head.register_forward_pre_hook(lambda module, inputs: (inputs[0][:, -1:, :],))
            try:
                model.base_model.model.rope_deltas = None
                with torch.no_grad():
                    generated = model.generate(**batch, max_new_tokens=360, do_sample=False, use_cache=True,
                        pad_token_id=self.tokenizer.pad_token_id, eos_token_id=self.tokenizer.eos_token_id)
            finally:
                handle.remove()
            texts = self.tokenizer.batch_decode(generated[:, batch['input_ids'].shape[1]:], skip_special_tokens=True)
            for (concept, source), action, text, fixed in zip(selected_jobs, selected_actions, texts, bound_prefixes, strict=True):
                text = fixed + text
                try:
                    value = json.loads(text)
                    valid = (set(value) == {'concept', 'relation', 'source_quote', 'reason'} and value['concept'] == concept
                             and value['relation'] == KINDS[action] and value['source_quote'] == source
                             and isinstance(value['reason'], str)
                             and not re.search(r'(?:轻度|中度|重度)抑郁|确诊|(?:必须|应该|需要|建议|考虑).{0,8}(?:吃药|服药|用药|停药|减药)|患病概率|分数|得分|评分|严重度.{0,8}\d', value['reason']))
                except (ValueError, TypeError):
                    value, valid = None, False
                output.append({'raw': text, 'parsed': value, 'structural_source_agreement': valid,
                               'identity_relation_and_source_bound_by_program': True,
                               'clinical_semantic_validation': False})
        return output
