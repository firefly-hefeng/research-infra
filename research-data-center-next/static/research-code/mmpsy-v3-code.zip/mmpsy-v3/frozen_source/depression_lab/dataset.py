import hashlib
import json
from collections import Counter
from pathlib import Path

from depression_lab.scales import SCALES

SPLITS = {"train", "dev", "calibration", "test"}


def text_hash(text):
    return hashlib.sha256(" ".join(text.split()).encode("utf-8")).hexdigest()


def load_manifest(path: str | Path, allow_synthetic=False) -> tuple[list[dict], dict]:
    records = [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    if not records:
        raise ValueError("数据清单为空")
    scales = {r.get("scale") for r in records}
    if len(scales) != 1 or next(iter(scales)) not in SCALES:
        raise ValueError("一次训练只能使用 PHQ-9 或完整 HAMD-17，不能混合量表")
    scale = next(iter(scales))
    ids, maxima = SCALES[scale]
    subjects, texts, audio_hashes, sessions = {}, {}, {}, set()
    calibration_people = set()
    for i, row in enumerate(records):
        prefix = f"第{i + 1}行"
        for field in ("participant_id", "session_id", "transcript", "split", "label_source", "usage_permission"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise ValueError(f"{prefix}缺少 {field}")
        if row["split"] not in SPLITS:
            raise ValueError(f"{prefix} split必须为 train/dev/calibration/test")
        if row["session_id"] in sessions:
            raise ValueError(f"{prefix} session_id重复")
        sessions.add(row["session_id"])
        if row.get("synthetic") and not allow_synthetic:
            raise ValueError("合成标签不能用于临床训练；软件自测需显式 --allow-synthetic")
        source = row["label_source"]
        if source not in {"clinician", "independent_self_report"} and not (allow_synthetic and row.get("synthetic")):
            raise ValueError(f"{prefix}需要独立临床或独立自评标签，不接受 LLM 伪标签")
        if scale == "HAMD-17" and source != "clinician" and not (allow_synthetic and row.get("synthetic")):
            raise ValueError("HAMD-17必须是医生评分")
        labels = row.get("item_scores")
        if not isinstance(labels, list) or len(labels) != len(ids):
            raise ValueError(f"{prefix}需要完整的 {len(ids)} 项标签")
        if any(type(v) is not int or v < 0 or v > upper for v, upper in zip(labels, maxima)):
            raise ValueError(f"{prefix}条目分数超出范围或不是整数")
        if row.get("total_score", sum(labels)) != sum(labels):
            raise ValueError(f"{prefix}总分与条目之和不一致")
        for seen, key, name in ((subjects, row["participant_id"], "同一参与者"),
                                (texts, text_hash(row["transcript"]), "相同转录"),
                                (audio_hashes, row.get("audio_sha256"), "相同音频")):
            if key:
                if key in seen and seen[key] != row["split"]:
                    raise ValueError(f"{prefix}{name}跨数据分区，存在泄漏")
                seen[key] = row["split"]
        if row["split"] == "calibration":
            if row["participant_id"] in calibration_people:
                raise ValueError("当前区间校准协议要求每位校准参与者仅一次评估；重复随访需独立分组协议")
            calibration_people.add(row["participant_id"])
    audit = {"scale": scale, "records": len(records), "participants": len(subjects),
             "split_records": dict(Counter(r["split"] for r in records)),
             "synthetic": any(r.get("synthetic", False) for r in records),
             "source_sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
             "leakage_checks": "participant + normalized transcript + provided audio SHA256",
             "identity_limit": "provided participant IDs and audio hashes require source verification"}
    return records, audit
