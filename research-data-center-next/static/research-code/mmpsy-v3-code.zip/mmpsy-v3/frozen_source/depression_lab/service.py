import json
import re

import httpx

from depression_lab.config import runtime_dir, settings
from depression_lab.prompts import VERSION, messages
from depression_lab.schemas import ModelAssessment, Turn
from depression_lab.scoring import build_reply, score_assessment
from depression_lab.scoring import FREQUENCY_PATTERNS


async def worker_call(endpoint: str, payload: dict) -> dict:
    token_file = runtime_dir() / "worker.token"
    if not token_file.exists():
        raise RuntimeError("本地 GPU 服务尚未启动，请运行 start.ps1。")
    async with httpx.AsyncClient(timeout=300, trust_env=False) as client:
        response = await client.post(settings()["worker_url"] + endpoint, json=payload,
                                     headers={"Authorization": "Bearer " + token_file.read_text().strip()})
    if not response.is_success:
        try:
            detail = response.json().get("error", "GPU 服务失败")
        except ValueError:
            detail = "GPU 服务返回了无法读取的响应"
        raise RuntimeError(detail)
    return response.json()


def parse_model_json(text: str, turns: list[Turn] | None = None) -> ModelAssessment:
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text).strip()
    starts = [i for i in (text.find("{"), text.find("[")) if i >= 0]
    if not starts:
        raise ValueError("模型未输出 JSON")
    start = min(starts)
    data, end = json.JSONDecoder().raw_decode(text[start:])
    if text[start + end:].strip():
        raise ValueError("模型 JSON 后有额外输出")
    repairs = []
    if isinstance(data, list) and all(isinstance(x, dict) and "item_id" in x for x in data):
        data = {"observations": data}
        repairs.append("observation_array_wrapped")
    if not isinstance(data, dict):
        raise ValueError("模型JSON顶层结构错误")
    if "item_id" in data:
        data = {"observations": [data]}
        repairs.append("single_observation_wrapped")
    # Compact extraction predicts frequency once; presence is derived from it.
    for observation in data.get("observations", []):
        if "quote" in observation:
            quote = observation.pop("quote")
            source_id = observation.pop("turn_id", "")
            observation["evidence"] = [{"turn_id": source_id, "quote": quote}] if quote else []
            time_quote = observation.pop("time_quote", "")
            time_id = observation.pop("time_turn_id", "")
            observation["period_evidence"] = [{"turn_id": time_id, "quote": time_quote}] if time_quote else []
            freq = observation.get("frequency", "unknown")
            observation["status"] = "absent" if freq == "not_at_all" else "uncertain" if freq == "unknown" else "present"
    # A bare period quote may be safely repaired ONLY when its source is unique.
    # No quote text, symptom, frequency or score is synthesized by this repair.
    if turns:
        by_id = {t.id: t for t in turns}
        for observation in data.get("observations", []):
            for entry in observation.get("evidence", []):
                if isinstance(entry, dict) and entry.get("turn_id") not in by_id and entry.get("quote"):
                    matches = [t for t in turns if t.role == "user" and entry["quote"] in t.text]
                    if len(matches) == 1:
                        entry["turn_id"] = matches[0].id
                        repairs.append("symptom_id_unique_literal_source")
            period_refs = []
            for entry in observation.get("period_evidence", []):
                if isinstance(entry, str):
                    matches = [t for t in turns if entry and entry in t.text]
                    if len(matches) == 1:
                        entry = {"turn_id": matches[0].id, "quote": entry}
                        repairs.append("period_quote_unique_literal_source")
                elif isinstance(entry, dict) and entry.get("turn_id") not in by_id and entry.get("quote"):
                    matches = [t for t in turns if entry["quote"] in t.text]
                    if len(matches) == 1:
                        entry = {"turn_id": matches[0].id, "quote": entry["quote"]}
                        repairs.append("period_id_unique_literal_source")
                period_refs.append(entry)
            observation["period_evidence"] = period_refs
            # Resolve an omitted time citation only when the model already selected
            # this period and its cited user turn starts with an explicit time anchor.
            # Historical/mixed timeframes cannot use this structural completion.
            if not period_refs and observation.get("period") == "past_two_weeks":
                anchors = []
                for ref in observation.get("evidence", []):
                    source = by_id.get(ref.get("turn_id"))
                    if not source or source.role != "user" or ref.get("quote", "") not in source.text:
                        continue
                    match = re.match(r"^(?:在|就)?(?:最近|过去|这)(?:两周|两个星期|14天|十四天)", source.text)
                    if match and not re.search(r"去年|曾经|几年前|上个月|但现在|然而现在", source.text):
                        anchors.append({"turn_id": source.id, "quote": match.group()})
                if len(anchors) == 1:
                    observation["period_evidence"] = anchors
                    repairs.append("explicit_same_turn_time_anchor_cited")
            # Include the containing clause when the model truncated away its
            # already-selected frequency. Never cross punctuation or contrast words.
            freq = observation.get("frequency", "unknown")
            pattern = FREQUENCY_PATTERNS.get(freq)
            if pattern and not any(re.search(pattern, r.get("quote", "")) for r in observation.get("evidence", [])):
                for ref in list(observation.get("evidence", [])):
                    source = by_id.get(ref.get("turn_id"))
                    if not source or source.role != "user" or not ref.get("quote"):
                        continue
                    clauses = re.split(r"[，,。！？!?；;\n]|但是|不过|然而|但", source.text)
                    matches = [c for c in clauses if ref["quote"] in c and re.search(pattern, c) and len(c) <= 250]
                    if len(matches) == 1:
                        observation["evidence"].append({"turn_id": source.id, "quote": matches[0]})
                        repairs.append("containing_clause_frequency_cited")
    data["format_repairs"] = repairs
    return ModelAssessment.model_validate(data)


async def analyze(turns: list[Turn]) -> tuple[dict, str]:
    if sum(len(t.text) for t in turns) > settings()["max_context_characters"]:
        raise ValueError("当前会话已达到长度上限。请导出并开始新会话，避免截断导致证据遗漏。")
    transcript = [{"id": t.id, "role": t.role, "text": t.text} for t in turns]
    prompt = messages(transcript)
    total_seconds = 0
    for attempt in range(2):
        result = await worker_call("/generate", {"messages": prompt, "max_new_tokens": 3200})
        total_seconds += result["seconds"]
        try:
            model = parse_model_json(result["text"], turns)
            break
        except (ValueError, TypeError, AttributeError) as exc:
            if attempt:
                raise RuntimeError("模型输出格式不完整，本次未生成分数；可以重试分析。") from exc
            prompt = prompt + [{"role": "assistant", "content": result["text"]},
                               {"role": "user", "content": "上一次JSON无法解析。请根据同一访谈重新输出完整合法JSON，检查引号、逗号和所有字段。不改变证据，不添加原文没有的症状。"}]
    report = score_assessment(model, turns)
    report["provenance"] = {"prompt_version": VERSION, "model": result["model"],
                            "tokens": result["tokens"], "inference_seconds": round(total_seconds, 3),
                            "format_retry_count": attempt, "presence_derivation": "frequency_mapping",
                            "data_location": "local_only", "labels_used_at_inference": False,
                            "format_repairs": model.format_repairs}
    return report, build_reply(model, report)
