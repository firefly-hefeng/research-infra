"""Frozen waveform encoder, not an emotion or depression classifier."""
import hashlib
import json
import time
from pathlib import Path

import numpy as np

from depression_lab.audio_features import AUDIO_VERSION, feature_id, feature_path, load_bundle, save_bundle
from depression_lab.config import settings


class SpeechEncoder:
    def __init__(self):
        self.model = self.processor = None
        self.weights_sha256 = None

    def signature(self):
        if self.weights_sha256 is None:
            directory = Path(settings()["audio_encoder_path"])
            weights = directory / "pytorch_model.bin"
            with weights.open("rb") as source:
                self.weights_sha256 = hashlib.file_digest(source, "sha256").hexdigest()
            verification = directory / "download_verification.json"
            if verification.exists():
                expected = json.loads(verification.read_text(encoding="utf-8"))["sha256"]
                if self.weights_sha256 != expected:
                    self.weights_sha256 = None
                    raise ValueError("本机 XLS-R 权重校验失败")
        return self.weights_sha256

    def load(self):
        if self.model is not None:
            return
        import torch
        from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model
        torch.set_num_threads(4)
        if not torch.cuda.is_available() or torch.cuda.mem_get_info()[0] < 2 * 1024 ** 3:
            raise RuntimeError("语音编码需要至少2GB空闲显存，请释放本项目不需要的模型后重试。")
        path = settings()["audio_encoder_path"]
        self.processor = Wav2Vec2FeatureExtractor.from_pretrained(path, local_files_only=True)
        model, info = Wav2Vec2Model.from_pretrained(path, local_files_only=True, output_loading_info=True,
                                                  low_cpu_mem_usage=False, attn_implementation="sdpa")
        if info["missing_keys"] or info.get("mismatched_keys"):
            raise RuntimeError("XLS-R 编码器存在未加载权重，拒绝使用随机参数提取特征。")
        self.model = model.to(device="cuda", dtype=torch.bfloat16).eval()

    def encode(self, audio, source_sha256, acoustics):
        import torch
        signature = self.signature()
        identifier = feature_id(source_sha256, signature)
        if feature_path(identifier).exists():
            return {"audio_features_id": identifier, "bundle": load_bundle(identifier), "cache_hit": True}
        if not acoustics.get("usable_for_asr"):
            raise ValueError("录音有效活动不足，不能生成联合评分输入")
        self.load()
        started = time.perf_counter()
        count = 0
        total = np.zeros(1024, dtype=np.float64)
        squared = np.zeros(1024, dtype=np.float64)
        for start in range(0, len(audio), 8 * 16000):
            chunk = audio[start:start + 8 * 16000]
            if len(chunk) < 400:
                chunk = np.pad(chunk, (0, 400 - len(chunk)))
            inputs = self.processor(chunk, sampling_rate=16000, return_tensors="pt")
            with torch.inference_mode():
                hidden = self.model(input_values=inputs.input_values.to(device="cuda", dtype=torch.bfloat16)).last_hidden_state[0]
            values = hidden.float().cpu().numpy().astype(np.float64)
            total += values.sum(axis=0)
            squared += (values ** 2).sum(axis=0)
            count += len(values)
        mean = total / count
        vector = np.concatenate([mean, np.sqrt(np.maximum(squared / count - mean ** 2, 0))])
        bundle = {"version": AUDIO_VERSION, "model": "facebook/wav2vec2-xls-r-300m", "weights_sha256": signature,
                  "source_sha256": source_sha256, "vector": vector.tolist(), "frames": count,
                  "duration_seconds": len(audio) / 16000, "acoustics": acoustics,
                  "encoding_seconds": round(time.perf_counter() - started, 3), "clinical_finetuned": False,
                  "provenance": "original_waveform_not_transcript", "pooling": "last-layer frame mean and population standard deviation; nonoverlapping 8s chunks"}
        identifier = save_bundle(bundle)
        return {"audio_features_id": identifier, "bundle": bundle, "cache_hit": False}
