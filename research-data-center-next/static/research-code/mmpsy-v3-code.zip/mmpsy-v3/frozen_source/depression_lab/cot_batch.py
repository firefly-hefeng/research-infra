"""Batch independent CoT candidates; retain unpadded per-candidate PPO inputs."""

import torch
from torch.nn import functional as F


def left_pad_prompts(prompts, pad_id):
    if not prompts or any(set(p) != {"input_ids", "attention_mask"} for p in prompts):
        raise ValueError("Batched CoT accepts text-only tokenized prompts")
    width = max(p["input_ids"].shape[1] for p in prompts)
    return {
        "input_ids": torch.cat([F.pad(p["input_ids"], (width - p["input_ids"].shape[1], 0), value=pad_id) for p in prompts]),
        "attention_mask": torch.cat([F.pad(p["attention_mask"], (width - p["input_ids"].shape[1], 0), value=0) for p in prompts]),
    }


def unpad_rollout(prompt, completion, eos_id):
    eos = torch.nonzero(completion == eos_id).flatten()
    if len(eos):
        completion = completion[:int(eos[0]) + 1]
    prefix = prompt["input_ids"].shape[1]
    ids = torch.cat([prompt["input_ids"], completion[None]], dim=1)
    return {
        "batch": {"input_ids": ids, "attention_mask": torch.ones_like(ids)},
        "prefix_length": prefix,
        "terminated": bool(len(eos)),
        "completion_tokens": completion,
    }


def cot_rollouts(encoder, rows, max_tokens=1536, sample=True):
    prompts = [encoder.batch(encoder.cot_prompt(row))[0] for row in rows]
    tokenizer = encoder.processor.tokenizer
    batch = left_pad_prompts(prompts, tokenizer.pad_token_id)
    prefix = batch["input_ids"].shape[1]
    if prefix + max_tokens > 16384:
        raise ValueError("Batched evidence report too long; no silent truncation")
    hook = encoder.model.base_model.model.lm_head.register_forward_pre_hook(
        lambda module, inputs: (inputs[0][:, -1:, :],)
    )
    try:
        encoder.model.base_model.model.rope_deltas = None
        with torch.no_grad():
            output = encoder.model.generate(
                **batch, max_new_tokens=max_tokens, do_sample=sample,
                temperature=1.0 if sample else None, top_p=1.0 if sample else None,
                top_k=0 if sample else None, use_cache=True,
                eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.pad_token_id,
            )
    finally:
        hook.remove()
    results = []
    for prompt, tokens in zip(prompts, output[:, prefix:], strict=True):
        result = unpad_rollout(prompt, tokens, tokenizer.eos_token_id)
        result["text"] = tokenizer.decode(result.pop("completion_tokens"), skip_special_tokens=True)
        results.append(result)
    return results
